/*
 * eap_md5.c  EAP MD5 functionality.
 *
 * Version:     $Id: 436c235537368590d6d1f6b21d8c7dc5193263c1 $
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2001,2006  The FreeRADIUS server project
 * Copyright 2001  hereUare Communications, Inc. <raghud@hereuare.com>
 */

/*
 *
 *  MD5 Packet Format in EAP Type-Data
 *  --- ------ ------ -- --- ---------
 *  0                   1                   2                   3
 *  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |  Value-Size   |  Value ...
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |  Name ...
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 */

#include <freeradius-devel/ident.h>
RCSID("$Id: 436c235537368590d6d1f6b21d8c7dc5193263c1 $")

#include <stdio.h>
#include <stdlib.h>
#include <uuid/uuid.h>

#include "eap.h"
//#include "base64.h"
#include "eap_md5.h"
#include <nacstd/c_json.h>

//the data to send to auth_center
const int VERSION = 1;
const int REQUEST_TYPE = 0;
//const int SOURCE_TYPE = 0;  //if 0, it is 802.1x

#define NAC_HEADER_LEN 		4

#ifndef FREE_PTR
#define FREE_PTR(P) if(P) free(P); (P)=NULL;
#endif 

/*
 *      Allocate a new MD5_PACKET
 */
MD5_PACKET *eapmd5_alloc(void)
{
	MD5_PACKET   *rp;

	if ((rp = malloc(sizeof(MD5_PACKET))) == NULL) {
		radlog(L_ERR, "rlm_eap_md5: out of memory");
		return NULL;
	}
	memset(rp, 0, sizeof(MD5_PACKET));
	return rp;
}

/*
 *      Free MD5_PACKET
 */
void eapmd5_free(MD5_PACKET **md5_packet_ptr)
{
	MD5_PACKET *md5_packet;

	if (!md5_packet_ptr) return;
	md5_packet = *md5_packet_ptr;
	if (md5_packet == NULL) return;

	if (md5_packet->value) free(md5_packet->value);
	if (md5_packet->name) free(md5_packet->name);

	free(md5_packet);

	*md5_packet_ptr = NULL;
}

/*
 *	We expect only RESPONSE for which SUCCESS or FAILURE is sent back
 */
MD5_PACKET *eapmd5_extract(EAP_DS *eap_ds)
{
	md5_packet_t	*data;
	MD5_PACKET	*packet;
	unsigned short	name_len;

	/*
	 *	We need a response, of type EAP-MD5, with at least
	 *	one byte of type data (EAP-MD5) following the 4-byte
	 *	EAP-Packet header.
	 */
	if (!eap_ds 					 ||
		!eap_ds->response 				 ||
		(eap_ds->response->code != PW_MD5_RESPONSE)	 ||
		//eap_ds->response->type.type != PW_EAP_MD5	 ||
		!eap_ds->response->type.data 		 ||
		(eap_ds->response->length <= MD5_HEADER_LEN) ||
		(eap_ds->response->type.data[0] <= 0)) {
		radlog(L_ERR, "rlm_eap_md5: corrupted data");
		return NULL;
	}

	packet = eapmd5_alloc();
	if (!packet) return NULL;

	/*
	 *	Code & id for MD5 & EAP are same
	 *
	 *	but md5_length = length of the EAP-MD5 data, which
	 *	doesn't include the EAP header, or the octet saying
	 *	EAP-MD5.
	 */
	packet->code = eap_ds->response->code;
	packet->id = eap_ds->response->id;
	packet->length = eap_ds->response->length - (MD5_HEADER_LEN + 1);

	/*
	 *	Sanity check the EAP-MD5 packet sent to us
	 *	by the client.
	 */
	data = (md5_packet_t *)eap_ds->response->type.data;

	/*
	 *	Already checked the size above.
	 */
	packet->value_size = data->value_size;

	/*
	 *	Allocate room for the data, and copy over the data.
	 */
	packet->value = malloc(packet->value_size);
	if (packet->value == NULL) {
		radlog(L_ERR, "rlm_eap_md5: out of memory");
		eapmd5_free(&packet);
		return NULL;
	}
	memcpy(packet->value, data->value_name, packet->value_size);

	/*
	 *	Name is optional and is present after Value, but we
	 *	need to check for it, as eapmd5_compose()
	 */
	name_len =  packet->length - (packet->value_size + 1);
	if (name_len) {
		packet->name = malloc(name_len + 1);
		if (!packet->name) {
			radlog(L_ERR, "rlm_eap_md5: out of memory");
			eapmd5_free(&packet);
			return NULL;
		}
		memcpy(packet->name, data->value_name + packet->value_size,
			   name_len);
		packet->name[name_len] = 0;
	}

	return packet;
}


/*
 * verify = MD5(id+password+challenge_sent)
 */
int eapmd5_verify(MD5_PACKET *packet, VALUE_PAIR* password,
		  uint8_t *challenge)
{
	char	*ptr;
	char	string[1 + MAX_STRING_LEN*2];
	unsigned char output[MAX_STRING_LEN];
	unsigned short len;

	/*
	 *	Sanity check it.
	 */
	if (packet->value_size != 16) {
		radlog(L_ERR, "rlm_eap_md5: Expected 16 bytes of response to challenge, got %d", packet->value_size);
		return 0;
	}

	len = 0;
	ptr = string;

	/*
	 *	This is really rad_chap_pwencode()...
	 */
	*ptr++ = packet->id;
	len++;
	memcpy(ptr, password->vp_strvalue, password->length);
	ptr += password->length;
	len += password->length;

	/*
	 *	The challenge size is hard-coded.
	 */
	memcpy(ptr, challenge, MD5_CHALLENGE_LEN);
	len += MD5_CHALLENGE_LEN;

	fr_md5_calc((u_char *)output, (u_char *)string, len);

	/*
	 *	The length of the response is always 16 for MD5.
	 */
	if (memcmp(output, packet->value, 16) != 0) {
		return 0;
	}
	return 1;
}

/*
 *	Compose the portions of the reply packet specific to the
 *	EAP-MD5 protocol, in the EAP reply typedata
 */
int eapmd5_compose(EAP_DS *eap_ds, MD5_PACKET *reply)
{
	uint8_t *ptr;
	unsigned short name_len;

	/*
	 *	We really only send Challenge (EAP-Identity),
	 *	and EAP-Success, and EAP-Failure.
	 */
	if (reply->code < 3) {
		eap_ds->request->type.type = PW_EAP_MD5;

		rad_assert(reply->length > 0);

		eap_ds->request->type.data = malloc(reply->length);
		if (eap_ds->request->type.data == NULL) {
			eapmd5_free(&reply);
			radlog(L_ERR, "rlm_eap_md5: out of memory");
			return 0;
		}
		ptr = eap_ds->request->type.data;
		*ptr++ = (uint8_t)(reply->value_size & 0xFF);
		memcpy(ptr, reply->value, reply->value_size);

		/* Just the Challenge length */
		eap_ds->request->type.length = reply->value_size + 1;

		/*
		 *	Return the name, if necessary.
		 *
		 *	Don't see why this is *ever* necessary...
		 */
		name_len = reply->length - (reply->value_size + 1);
		if (name_len && reply->name) {
			ptr += reply->value_size;
			memcpy(ptr, reply->name, name_len);
			/* Challenge length + Name length */
			eap_ds->request->type.length += name_len;
		}
	} else {
		eap_ds->request->type.length = 0;
		/* TODO: In future we might add message here wrt rfc1994 */
	}
	eap_ds->request->code = reply->code;

	eapmd5_free(&reply);

	return 1;
}

int gen_uuid(char *res_uuid)
{
	uuid_t uuid;
	uuid_generate(uuid);
	uuid_unparse(uuid, res_uuid);

	return 0;
}

int package_request_stage2(EAP_HANDLER *handler, request_packet_t* request_packet) 
{
	VALUE_PAIR *vp_nas_ip_addr=NULL;
	VALUE_PAIR *vp_ssid=NULL;
	VALUE_PAIR *vp_nas_port=NULL;
	VALUE_PAIR *vp_nas_port_id=NULL;
	VALUE_PAIR *vp_nas_port_type=NULL;
	VALUE_PAIR *vp_nas_identifier=NULL;
	VALUE_PAIR *vp_service_type=NULL;
	VALUE_PAIR *vp_mac=NULL;
	VALUE_PAIR *vp_user_name=NULL;
	VALUE_PAIR *vp_nas_ipv6_addr=NULL;
	DICT_ATTR *da=NULL;

	if (NULL == handler){
		radlog(L_ERR, "[%s-%d-%s]: parameter error.", __FILE__, __LINE__, __FUNCTION__);
		return -1;
	}
	nac_data *pdata=handler->opaque;
	uint8_t *resp_data = handler->eap_ds->response->type.data;
	//packet id
	request_packet->packet_id = 1;	
	
	 //generate session_id
	gen_uuid(request_packet->session_id);
	request_packet->session_id[36] = '\0';
	 
	request_packet->version = VERSION;
	request_packet->request_type = REQUEST_TYPE;
	request_packet->source_type = RADIUS;
	
	//NAS-IP-Address
	char* nas_ip_address = NULL;
	char ipv4_buf[16] = {0};
	if((da=dict_attrbyname("NAS-IP-Address"))){
		if ((vp_nas_ip_addr=pairfind(handler->request->packet->vps,  da->attr))) {
			nas_ip_address=inet_ntoa(vp_nas_ip_addr->data.ipaddr);
			if (NULL == nas_ip_address || strncmp(nas_ip_address,"0.0.0.0",7) == 0) {
				nas_ip_address = inet_ntop(AF_INET, &handler->request->packet->src_ipaddr.ipaddr, ipv4_buf, sizeof(ipv4_buf));
			}
		} else {
			if (handler->request->packet->src_ipaddr.af == AF_INET)
				nas_ip_address = inet_ntop(AF_INET, &handler->request->packet->src_ipaddr.ipaddr, ipv4_buf, sizeof(ipv4_buf));

		} 
		
	}
	if ((nas_ip_address  != NULL) && (strncmp(nas_ip_address, "127.0.0.1", 9) != 0)){
		strlcpy(request_packet->nas_ip_addr, nas_ip_address, sizeof(request_packet->nas_ip_addr));
	}

	//NAS-IPv6-Address
	char *nas_ipv6_address = NULL;
	char ipv6_buf[48] = {0};
	if((da=dict_attrbyname("NAS-IPv6-Address"))){
		if ((vp_nas_ipv6_addr= pairfind(handler->request->packet->vps,  da->attr))) {
			nas_ipv6_address = inet_ntop(AF_INET6, (void *)&vp_nas_ipv6_addr->data.ipv6addr, ipv6_buf ,INET6_ADDRSTRLEN);
		} else {
			if (handler->request->packet->src_ipaddr.af == AF_INET6)
				nas_ipv6_address = inet_ntop(AF_INET6, &handler->request->packet->src_ipaddr.ipaddr, ipv6_buf, sizeof(ipv6_buf));	
		}

	}
	if (NULL != nas_ipv6_address){
		strlcpy(request_packet->nas_ipv6_addr, nas_ipv6_address, sizeof(request_packet->nas_ipv6_addr));
	}
	char* ssid = NULL;
	if((da=dict_attrbyname("Called-Station-Id"))){
		if ((vp_ssid=pairfind(handler->request->packet->vps,	da->attr))) {
			ssid=vp_ssid->data.strvalue;
		}
	}

	if (NULL != ssid){
		strlcpy(request_packet->ssid, ssid, sizeof(request_packet->ssid));
	}
	
	//NAS-Port
	int nas_port = 0;
	if((da=dict_attrbyname("NAS-Port"))){
		if ((vp_nas_port=pairfind(handler->request->packet->vps,  da->attr))) {
			nas_port=vp_nas_port->lvalue;
		}
	}
	request_packet->nas_port = nas_port;
	
	//NAS-Port-Id
	char* nas_port_id =NULL;
	if((da=dict_attrbyname("NAS-Port-Id"))){
		if ((vp_nas_port_id=pairfind(handler->request->packet->vps,  da->attr))) {
			nas_port_id=vp_nas_port_id->data.strvalue;
		}
	}
	//may be i can not take this value
	if (NULL != nas_port_id){
		strlcpy(request_packet->nas_port_id, nas_port_id, sizeof(request_packet->nas_port_id));
	}

	//NAS-Port-Type
	char* nas_port_type = NULL;
	if((da=dict_attrbyname("NAS-Port-Type"))){
		if ((vp_nas_port_type=pairfind(handler->request->packet->vps,	da->attr))) {
			nas_port_type=vp_nas_port_type->data.strvalue;
		}
	}
	if (NULL != nas_port_type){
		strlcpy(request_packet->nas_port_type, nas_port_type, sizeof(request_packet->nas_port_type));
	}
	
	//NAS-Identifier
	char* nas_identifier = NULL;
	if((da=dict_attrbyname("NAS-Identifier"))){
		if ((vp_nas_identifier=pairfind(handler->request->packet->vps,	da->attr))) {
			nas_identifier=vp_nas_identifier->data.strvalue;
		}
	}
	if (NULL != nas_identifier){
		strlcpy(request_packet->nas_identifier, nas_identifier, sizeof(request_packet->nas_identifier));
	}
	//Service-Type
	char* service_type = NULL;
	if((da=dict_attrbyname("Service-Type"))){
		if ((vp_service_type=pairfind(handler->request->packet->vps,	da->attr))) {
			service_type=vp_service_type->data.strvalue;
		}
	}

	if ( NULL != service_type ){
		strlcpy(request_packet->service_type, service_type, sizeof(request_packet->service_type));
	}
	
	//Framed-Protocol 1 PPP
	int framed_protocol = 1; //if 1, PPP
	request_packet->framed_protocol = framed_protocol;
	
	//MAC
	char *req_mac = NULL;
	if((da=dict_attrbyname("Calling-Station-Id"))){
		if ((vp_mac=pairfind(handler->request->packet->vps,  da->attr))) {
			req_mac=vp_mac->data.strvalue;
		}
	}
	if ( NULL != req_mac){
		strlcpy(request_packet->mac, req_mac, sizeof(request_packet->mac));
	}
	
	//User-Name
	char *user_name = NULL;
	if((da=dict_attrbyname("User-Name"))){
		if ((vp_user_name=pairfind(handler->request->packet->vps,  da->attr))) {
			user_name=vp_user_name->data.strvalue;
		}
	}
	if (NULL != user_name){
		strlcpy(request_packet->user_name, user_name, sizeof(request_packet->user_name));
	}
	
	request_packet->auth_mode = THIRDPARTYCERT_AUTH;
	radlog(L_DBG, "[%s-%d-%s]: big cert file recover data", __FILE__, __LINE__, __FUNCTION__);
	strlcpy(request_packet->mid, pdata->client_mid, sizeof(request_packet->mid));
	request_packet->authenticate_type = pdata->authenticate_type;
	strlcpy(request_packet->server_key, pdata->server_key, sizeof(request_packet->server_key));
	request_packet->sccheckcode = pdata->sccheckcode;
	strlcpy(request_packet->system_account, pdata->system_account, sizeof(request_packet->system_account));
	strlcpy(request_packet->os_version, pdata->os_version, sizeof(request_packet->os_version));
	strlcpy(request_packet->host_name, pdata->host_name, sizeof(request_packet->host_name));
	strlcpy(request_packet->server_key, pdata->server_key, sizeof(request_packet->server_key));
	int raw_data_length = handler->eap_ds->response->length - NAC_HEADER_LEN-2;
	radlog(L_DBG, "[%s-%d-%s]: big cert file stage 2: eap_ds->response->length=%d", __FILE__,
				__LINE__, __FUNCTION__, handler->eap_ds->response->length);
	radlog(L_DBG, "[%s-%d-%s]: big cert file stage 2: part1_len=%d, part2_length=%d, total=%d", __FILE__,
				__LINE__, __FUNCTION__, pdata->cert_file_length, raw_data_length, pdata->cert_file_length+raw_data_length);
	radlog(L_DBG, "[%s-%d-%s]: big cert file stage 2: 0x%x %x %x %x %x", __FILE__,
				__LINE__, __FUNCTION__, resp_data[0], resp_data[1],resp_data[2],resp_data[3],resp_data[4]);
	memcpy(request_packet->cert_file, pdata->cert_file, pdata->cert_file_length);
	memcpy(request_packet->cert_file+pdata->cert_file_length, resp_data+1, raw_data_length);
	request_packet->cert_file_length = pdata->cert_file_length+raw_data_length;
}


int package_request(int mode, EAP_HANDLER *handler, MD5_PACKET	 *packet, request_packet_t* request_packet)
{
	if (NULL == handler){
		radlog(L_ERR, "[%s-%d-%s]: parameter error.", __FILE__, __LINE__, __FUNCTION__);
		return -1;
	}	

	VALUE_PAIR *vp_nas_ip_addr=NULL;
	VALUE_PAIR *vp_ssid=NULL;
	VALUE_PAIR *vp_nas_port=NULL;
	VALUE_PAIR *vp_nas_port_id=NULL;
	VALUE_PAIR *vp_nas_port_type=NULL;
	VALUE_PAIR *vp_nas_identifier=NULL;
	VALUE_PAIR *vp_service_type=NULL;
	VALUE_PAIR *vp_mac=NULL;
	VALUE_PAIR *vp_user_name=NULL;
	VALUE_PAIR *vp_nas_ipv6_addr=NULL;
	VALUE_PAIR *vp_frame_ip_addr=NULL;
	DICT_ATTR *da=NULL;

	//packet id
	request_packet->packet_id = packet->id;	
	
	 //generate session_id
	gen_uuid(request_packet->session_id);
	request_packet->session_id[36] = '\0';
	 
	request_packet->version = VERSION;
	request_packet->request_type = REQUEST_TYPE;
	request_packet->source_type = RADIUS;
	
	//NAS-IP-Address
	char* nas_ip_address = NULL;
	char ipv4_buf[64] = {0};
	if((da=dict_attrbyname("NAS-IP-Address"))){
		if ((vp_nas_ip_addr=pairfind(handler->request->packet->vps,  da->attr))) {
			nas_ip_address=inet_ntoa(vp_nas_ip_addr->data.ipaddr);
			if (NULL == nas_ip_address || strncmp(nas_ip_address,"0.0.0.0",7) == 0) {
				nas_ip_address = inet_ntop(AF_INET, &handler->request->packet->src_ipaddr.ipaddr, ipv4_buf, sizeof(ipv4_buf));
			}
			
		} else {
			if (handler->request->packet->src_ipaddr.af == AF_INET)
				nas_ip_address = inet_ntop(AF_INET, &handler->request->packet->src_ipaddr.ipaddr, ipv4_buf, sizeof(ipv4_buf));

		}
	}
	if ((nas_ip_address  != NULL) && (strncmp(nas_ip_address, "127.0.0.1", 9) != 0)) {
		strlcpy(request_packet->nas_ip_addr, nas_ip_address, sizeof(request_packet->nas_ip_addr));
	}

	char *nas_ipv6_address = NULL;
	char ipv6_buf[48] = {0};
	if((da=dict_attrbyname("NAS-IPv6-Address"))){
		if ((vp_nas_ipv6_addr= pairfind(handler->request->packet->vps,  da->attr))) {
			nas_ipv6_address = inet_ntop(AF_INET6, (void *)&vp_nas_ipv6_addr->data.ipv6addr, ipv6_buf ,INET6_ADDRSTRLEN );
		} else {
			if (handler->request->packet->src_ipaddr.af == AF_INET6)
				nas_ipv6_address = inet_ntop(AF_INET6, &handler->request->packet->src_ipaddr.ipaddr, ipv6_buf, sizeof(ipv6_buf));
		}
		

	}
	if (NULL != nas_ipv6_address){
		strlcpy(request_packet->nas_ipv6_addr, nas_ipv6_address, sizeof(request_packet->nas_ipv6_addr));
	}

	char* ssid = NULL;
	if((da=dict_attrbyname("Called-Station-Id"))){
		if ((vp_ssid=pairfind(handler->request->packet->vps,	da->attr))) {
			ssid=vp_ssid->data.strvalue;
		}
	}

	if (NULL != ssid){
		strlcpy(request_packet->ssid, ssid, sizeof(request_packet->ssid));
	}
	
	//NAS-Port
	int nas_port = 0;
	if((da=dict_attrbyname("NAS-Port"))){
		if ((vp_nas_port=pairfind(handler->request->packet->vps,  da->attr))) {
			nas_port=vp_nas_port->lvalue;
		}
	}
	request_packet->nas_port = nas_port;
	
	//NAS-Port-Id
	char* nas_port_id =NULL;
	if((da=dict_attrbyname("NAS-Port-Id"))){
		if ((vp_nas_port_id=pairfind(handler->request->packet->vps,  da->attr))) {
			nas_port_id=vp_nas_port_id->data.strvalue;
		}
	}
	//may be i can not take this value
	if (NULL != nas_port_id){
		strlcpy(request_packet->nas_port_id, nas_port_id, sizeof(request_packet->nas_port_id));
	}

	//NAS-Port-Type
	char* nas_port_type = NULL;
	if((da=dict_attrbyname("NAS-Port-Type"))){
		if ((vp_nas_port_type=pairfind(handler->request->packet->vps,	da->attr))) {
			nas_port_type=vp_nas_port_type->data.strvalue;
		}
	}
	if (NULL != nas_port_type){
		strlcpy(request_packet->nas_port_type, nas_port_type, sizeof(request_packet->nas_port_type));
	}
	
	//NAS-Identifier
	char* nas_identifier = NULL;
	if((da=dict_attrbyname("NAS-Identifier"))){
		if ((vp_nas_identifier=pairfind(handler->request->packet->vps,	da->attr))) {
			nas_identifier=vp_nas_identifier->data.strvalue;
		}
	}
	if (NULL != nas_identifier){
		strlcpy(request_packet->nas_identifier, nas_identifier, sizeof(request_packet->nas_identifier));
	}
	//Service-Type
	char* service_type = NULL;
	if((da=dict_attrbyname("Service-Type"))){
		if ((vp_service_type=pairfind(handler->request->packet->vps,	da->attr))) {
			service_type=vp_service_type->data.strvalue;
		}
	}

	if ( NULL != service_type ){
		strlcpy(request_packet->service_type, service_type, sizeof(request_packet->service_type));
	}
	
	//Framed-Protocol 1 PPP
	int framed_protocol = 1; //if 1, PPP
	request_packet->framed_protocol = framed_protocol;
	
	//MAC
	char *req_mac = NULL;
	if((da=dict_attrbyname("Calling-Station-Id"))){
		if ((vp_mac=pairfind(handler->request->packet->vps,  da->attr))) {
			req_mac=vp_mac->data.strvalue;
		}
	}
	if ( NULL != req_mac){
		strlcpy(request_packet->mac, req_mac, sizeof(request_packet->mac));
	}
	
	//User-Name
	char *user_name = NULL;
	if((da=dict_attrbyname("User-Name"))){
		if ((vp_user_name=pairfind(handler->request->packet->vps,  da->attr))) {
			user_name=vp_user_name->data.strvalue;
		}
	}
	if (NULL != user_name){
		strlcpy(request_packet->user_name, user_name, sizeof(request_packet->user_name));
	}
	
	//Framed-IP-Address
	char* frame_ip_addr = NULL;
	if((da=dict_attrbyname("Framed-IP-Address"))){
		if ((vp_frame_ip_addr=pairfind(handler->request->packet->vps,  da->attr))) {
			frame_ip_addr=inet_ntoa(vp_frame_ip_addr->data.ipaddr);
			if (NULL != frame_ip_addr && strncmp(frame_ip_addr,"0.0.0.0",7) != 0) {
				strlcpy(request_packet->client_ip, frame_ip_addr, sizeof(request_packet->client_ip));
				radlog(L_DBG, "[%s-%d-%s]: Framed-IP-Address:", __FILE__, __LINE__, __FUNCTION__, request_packet->client_ip);
			}
		} 
	}
	
	nac_data *pdata=handler->opaque;
	
	if (MODE_COMP_NAC == mode){
		//mode
		request_packet->auth_mode = EAP_NAC_COMP;

		//mid
		int raw_data_length = handler->eap_ds->response->length - NAC_HEADER_LEN-1;
		unsigned char* raw_data=handler->eap_ds->response->type.data;
		if (raw_data_length>17){
			memcpy(request_packet->mid,raw_data+17,raw_data_length-17);
		}

		//pwd
		int pwd_len = packet->value_size;
		unsigned char* pwd = packet->value;
		request_packet->pass_word.type = 1; //if 1, it is MD5

		char* out_pwd_challenge = NULL;
		size_t pwd_challeng_len = fr_base64_encode_alloc (pdata->opaque, 16, &out_pwd_challenge);

		char* out_pwd_content = NULL;
		size_t pwd_content_len = fr_base64_encode_alloc (pwd, pwd_len, &out_pwd_content);

		memcpy(request_packet->pass_word.challenge, out_pwd_challenge, pwd_challeng_len);
		memcpy(request_packet->pass_word.content, out_pwd_content, pwd_content_len);

		FREE_PTR(out_pwd_challenge);			
		FREE_PTR(out_pwd_content);	

	}else if(MODE_NAC == mode){
		//0x00(1)+authmode(1)+secucheckcode(1)+reserver(4)+pwdtype(1)+pwdlen(1)+pwdcontent(pwdlen)+midlen(1)+mid(midlen)
		uint8_t *resp_data = handler->eap_ds->response->type.data;
		unsigned char auth_mode = resp_data[1];
		if (0 == auth_mode) {
			request_packet->auth_mode = EAP_NAC;//username and password auth
		} else if (1 == auth_mode) {
			request_packet->auth_mode = HOST_AUTH;//host auth
		} else if (2 == auth_mode) {
			request_packet->auth_mode = FAST_AUTH;//fast auth
		} else if (3 == auth_mode) {
			request_packet->auth_mode = CHUANGYUAN_AUTH;
		} else if (4 == auth_mode) {
			request_packet->auth_mode = CERT_AUTH;
		} else if (5 == auth_mode) {
			request_packet->auth_mode = THIRDPARTYCERT_AUTH;//表示非base64编码的第三方证书认证
		} else if (6 == auth_mode) {
			//auth_mode=6表示证书文件过大，分两次请求传输
			radlog(L_DBG, "[%s-%d-%s]: big cert file auth stage 1 start", __FILE__, __LINE__, __FUNCTION__);
			request_packet->auth_mode = THIRDPARTYCERT_AUTH;
			pdata->auth_mode = auth_mode;
		}  else if (8 == auth_mode) {
			request_packet->auth_mode = MULTI_CHUANGYUAN;//用户名密码+创源双因素认证 

		}  else {
			request_packet->auth_mode = INVAILD_AUTH;
		}
		
		unsigned char secucheckcode = resp_data[2] ;
		request_packet->sccheckcode= secucheckcode;
		
		unsigned char pwd_type =  resp_data[7] ; //if 0, it is rc4
		request_packet->pass_word.type = pwd_type;
		
		unsigned char pwd_len = resp_data[8];
		char encrypted_pwd[256] = {0};
		memcpy(encrypted_pwd, resp_data+9, pwd_len);
		
		//decrypted the password
		init_rc4_key_string((uint8_t *)(pdata->opaque) , 16, pdata);
		
		char decrypted_pwd[256] = {0};
		RC4(&(pdata->rc4_key), pwd_len, encrypted_pwd, decrypted_pwd);	

		if (pwd_type == 1){

			char* out_pwd_challenge = NULL;
			size_t pwd_challeng_len = fr_base64_encode_alloc (pdata->opaque, 16, &out_pwd_challenge);

			char* out_pwd_content = NULL;
			size_t pwd_content_len = fr_base64_encode_alloc (decrypted_pwd, pwd_len, &out_pwd_content);

			memcpy(request_packet->pass_word.challenge, out_pwd_challenge, pwd_challeng_len);
			memcpy(request_packet->pass_word.content, out_pwd_content, pwd_content_len);

			FREE_PTR(out_pwd_challenge);			
			FREE_PTR(out_pwd_content);	
		
		}else{
			memcpy(request_packet->pass_word.challenge, pdata->opaque, 16);
			memcpy(request_packet->pass_word.content, decrypted_pwd, pwd_len);
		}
		
		unsigned char midlen =resp_data[9+pwd_len];
		char mid[256] = {0};
		memcpy(mid, resp_data+9+pwd_len+1, midlen);
		memcpy(request_packet->mid, mid, midlen);

		//authenticate_type 0 - ~{o?=o?=o?=o?=o?=o?=V$~} 1-~{o?=o?=o?=o?=o?=o?=V$~} ~{D,o?=o?=N*o?=o?=o?=o?=o?=o?=V$~}
		request_packet->authenticate_type = 1;
		radlog(L_DBG, "[%s-%d-%s]: request_packet->authenticate_type[%d]", __FILE__, __LINE__, __FUNCTION__, request_packet->authenticate_type);

		if (resp_data[3] == 0x01) {
			/* means we have more data to parse in tlv format */
			radlog(L_DBG, "[%s-%d-%s]: more tlv data to parse", __FILE__, __LINE__, __FUNCTION__);
			uint8_t type = 0;
			unsigned short len = 0; // length of cert file longer than upperbound of uint8, type of len needs to be changed
			unsigned int true_len = 0;
			int offset = 10 + pwd_len + midlen;
			int total = handler->eap_ds->response->length - (NAC_HEADER_LEN +1) - offset;
			int i = 0;
			radlog(L_DBG, "[%s-%d-%s]: tlv total length=%d, offset=%d", __FILE__, __LINE__, __FUNCTION__, total, offset);
			while (i < total) {
				type = resp_data[offset+i];
				len = resp_data[offset+i+1];
				switch (type) {
					case TLV_TYPE_VM_ID:
						len = (len > (sizeof(request_packet->vm_id)-1)) ? (sizeof(request_packet->vm_id)-1) : len;
						memcpy(request_packet->vm_id, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->vm_id=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->vm_id,type, len);
						break;
					case TLV_TYPE_VM_MAC:
						len = (len > (sizeof(request_packet->vm_mac)-1)) ? (sizeof(request_packet->vm_mac)-1) : len;
						memcpy(request_packet->vm_mac, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->vm_mac=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->vm_mac,type, len);
						break;
					case TLV_TYPE_VM_ENTITIE:
						len = (len > (sizeof(request_packet->vm_entitle_name)-1)) ? (sizeof(request_packet->vm_entitle_name)-1) : len;
						memcpy(request_packet->vm_entitle_name, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->vm_entitle_name=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->vm_entitle_name,type, len);
						break;
					case TLV_TYPE_SERVER_KEY:
						len = (len > (sizeof(request_packet->server_key)-1)) ? (sizeof(request_packet->server_key)-1) : len;
						memcpy(request_packet->server_key, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->server_key=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->server_key,
																									type, len);
						break;
					case TLV_TYPE_SYSTEM_ACCOUNT:
						len = (len > (sizeof(request_packet->system_account)-1)) ? (sizeof(request_packet->system_account)-1) : len;
						memcpy(request_packet->system_account, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->system_account=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->system_account,
																									type, len);
						break;
					case TLV_TYPE_OS_VERSION:
						len = (len > (sizeof(request_packet->os_version)-1)) ? (sizeof(request_packet->os_version)-1) : len;
						memcpy(request_packet->os_version, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->os_version=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->os_version,
																									type, len);
						break;
					case TLV_TYPE_CLIENT_IP:
						if( sizeof(request_packet->client_ip) > 0 )
						{
							radlog(L_DBG, "[%s-%d-%s]: request_packet->client_ip %s replace by custom client ip ", __FILE__, __LINE__, __FUNCTION__, request_packet->client_ip);
							memset(request_packet->client_ip, 0, sizeof(request_packet->client_ip));
						}
						len = (len > (sizeof(request_packet->client_ip)-1)) ? (sizeof(request_packet->client_ip)-1) : len;
						memcpy(request_packet->client_ip, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->client_ip=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->client_ip,
																									type, len);
						break;
					case TLV_TYPE_AUTHENTICATE_TYPE:
						len = (len > (sizeof(request_packet->authenticate_type) - 1)) ? (sizeof(request_packet->authenticate_type) - 1) : len;
						unsigned char authType = resp_data[offset + i + 2];
						request_packet->authenticate_type = authType;
						radlog(L_DBG, "[%s-%d-%s]: request_packet->authenticate_type=%d (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->authenticate_type, type, len);
						break;
					case TLV_TYPE_HOST_NAME:
						len = (len > (sizeof(request_packet->host_name) - 1)) ? (sizeof(request_packet->host_name) - 1) : len;
						memcpy(request_packet->host_name, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->host_name=%d (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->host_name, type, len);
						break;
					case TLV_TYPE_CERT_FILE:
						true_len = ((unsigned int)(resp_data[offset+i+2])) * 256;
						true_len += len;
						radlog(L_DBG, "[%s-%d-%s]: cert_file: byte1=%u, byte2=%d", __FILE__, __LINE__, __FUNCTION__, len, resp_data[offset+i+2]);
						true_len = (true_len > (sizeof(request_packet->cert_file) - 1)) ? (sizeof(request_packet->cert_file) - 1) : true_len;
						memcpy(request_packet->cert_file, resp_data+offset+i+3, true_len);
						request_packet->cert_file_length = true_len;
						len = true_len + 1; // 2 bytes L, offset +1
						radlog(L_DBG, "[%s-%d-%s]: request_packet->cert_file(true_len=%d)=0x%x%x%x%x%x", __FILE__, __LINE__, __FUNCTION__, request_packet->cert_file_length, 
							request_packet->cert_file[0],request_packet->cert_file[1],request_packet->cert_file[2],request_packet->cert_file[3],request_packet->cert_file[4]);
						break;
					case TLV_TYPE_ORIGINAL_TEXT:
						len = (len > (sizeof(request_packet->original_text) - 1)) ? (sizeof(request_packet->original_text) - 1) : len;
						memcpy(request_packet->original_text, resp_data+offset+i+3, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->original_text=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->original_text, type, len);
						len += 1; // 2 bytes L, offset +1
						break;
					case TLV_TYPE_SIGNER:
						len = (len > (sizeof(request_packet->signer) - 1)) ? (sizeof(request_packet->signer) - 1) : len;
						memcpy(request_packet->signer, resp_data+offset+i+3, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->signer=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->signer, type, len);
						len += 1; // 2 bytes L, offset +1
						break;
					case TLV_TYPE_MFACTOR:
						len = (len > (sizeof(request_packet->verify_code) - 1)) ? (sizeof(request_packet->verify_code) - 1) : len;
						memcpy(request_packet->verify_code, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->verify_code=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->verify_code, type, len);
						break;
					case TLV_TYPE_ASSET_OID:
						len = (len > (sizeof(request_packet->asset_oid) - 1)) ? (sizeof(request_packet->asset_oid) - 1) : len;
						memcpy(request_packet->asset_oid, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->asset_oid=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->asset_oid, type, len);
						break;
					case TLV_TYPE_ASSET_ID:
						len = (len > (sizeof(request_packet->asset_id) - 1)) ? (sizeof(request_packet->asset_id) - 1) : len;
						memcpy(request_packet->asset_id, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->asset_id=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->asset_id, type, len);
						break;
					case TLV_TYPE_TOEKN:
						len = (len > (sizeof(request_packet->token) - 1)) ? (sizeof(request_packet->token) - 1) : len;
						memcpy(request_packet->token, resp_data+offset+i+2, len);
						radlog(L_DBG, "[%s-%d-%s]: request_packet->token=%s (type=%d len=%d)", __FILE__, __LINE__, __FUNCTION__, request_packet->token, type, len);
						break;
					default:
						radlog(L_ERR, "[%s-%d-%s]: unknown tlv type: %d", __FILE__, __LINE__, __FUNCTION__, type);
						i = total; /* break while loop */
						break;
				}
				i += len+2;
			}
		}
		//如果是auth_mode=6,需要把请求信息缓存
		if (auth_mode == 6) {
			radlog(L_DBG, "[%s-%d-%s]: big cert file save data", __FILE__, __LINE__, __FUNCTION__);
			memcpy(pdata->client_mid, mid, midlen);
			pdata->authenticate_type = request_packet->authenticate_type;
			strlcpy(pdata->server_key, request_packet->server_key, sizeof(pdata->server_key));
			pdata->sccheckcode = request_packet->sccheckcode;
			strlcpy(pdata->system_account, request_packet->system_account, sizeof(pdata->system_account));
			strlcpy(pdata->os_version, request_packet->os_version, sizeof(pdata->os_version));
			strlcpy(pdata->host_name, request_packet->host_name, sizeof(pdata->host_name));
			memcpy(pdata->cert_file, request_packet->cert_file, request_packet->cert_file_length);
			pdata->cert_file_length = request_packet->cert_file_length;
		}
	}else if (MODE_MD5 == mode){
	
		char tmpName[256] = {0};
		char tmpMac[256] = {0};
		char userName[256] = {0};
		char mac[256] = {0};
		replace(user_name, ':', tmpName);
		replace(tmpName, '-', userName);

		if (req_mac != NULL) {
			replace(req_mac, ':', tmpMac);
			replace(tmpMac, '-', mac);
		}	
		DEBUG("USER_NAME=[%s], len=[%d], MAC=[%s], len=[%d]\n", userName, strlen(userName), mac, strlen(mac));
		if (0 == strncasecmp(userName, mac, 12))
		{
			request_packet->auth_mode = MAC_BASE;

			request_packet->pass_word.type = 0; //if 1, it is MD5
			memcpy(request_packet->pass_word.challenge, " ", 1);
			memcpy(request_packet->pass_word.content, " ", 1);
		}
		else
		{
			request_packet->auth_mode = EAP_MD5;

			//pwd
			int pwd_len = packet->value_size;
			unsigned char* pwd = packet->value;
			request_packet->pass_word.type = 1; //if 1, it is MD5
			
			//char* base64_challenge = base64_encode(pdata->opaque, 16);

			char* out_pwd_challenge = NULL;
			size_t pwd_challeng_len = fr_base64_encode_alloc (pdata->opaque, 16, &out_pwd_challenge);

			char* out_pwd_content = NULL;
			size_t pwd_content_len = fr_base64_encode_alloc (pwd, pwd_len, &out_pwd_content);

			memcpy(request_packet->pass_word.challenge, out_pwd_challenge, pwd_challeng_len);
			FREE_PTR(out_pwd_challenge);	
			
			memcpy(request_packet->pass_word.content, out_pwd_content, pwd_content_len);		
			FREE_PTR(out_pwd_content);		
		
		}
		
		strcpy(request_packet->mid, "");
	}

}


int nac_package_request(int mode, EAP_HANDLER *handler, NAC_PACKET	 *packet, request_packet_t* request_packet)
{
	return package_request(mode, handler, (MD5_PACKET*)packet,request_packet);
}

int package_to_json(request_packet_t packet, char* result)
{
	if (NULL == result){
		radlog(L_ERR, "[%s-%d-%s]: parameter error.", __FILE__, __LINE__, __FUNCTION__);
		return -1;
	}

	cJSON *root = cJSON_CreateObject();
	cJSON_AddNumberToObject(root, "packet_id",       packet.packet_id);
	cJSON_AddStringToObject(root, "session_id",      packet.session_id);
	cJSON_AddNumberToObject(root, "version",         packet.version);
	cJSON_AddNumberToObject(root, "request_type",    packet.request_type);
	cJSON_AddNumberToObject(root, "source_type",     packet.source_type);
	

	if (strstr(packet.user_name,"REQAX|") != NULL)		
		cJSON_AddStringToObject(root, "user_name", packet.user_name+6);
	else 
		cJSON_AddStringToObject(root, "user_name", packet.user_name);		
	

	cJSON *pass_word = NULL;
	cJSON_AddItemToObject(root, "pass_word", pass_word=cJSON_CreateObject());
	cJSON_AddNumberToObject(pass_word, "type",      packet.pass_word.type);
	cJSON_AddStringToObject(pass_word, "challenge", packet.pass_word.challenge);
	cJSON_AddStringToObject(pass_word, "content",   packet.pass_word.content);
	cJSON_AddStringToObject(root, "nas_ip_addr",     packet.nas_ip_addr);
	cJSON_AddStringToObject(root, "nas_ipv6_addr",     packet.nas_ipv6_addr);

	if(packet.nas_port/10000==5){
		packet.nas_port=packet.nas_port%50000;
	}
	else{ 
		if (packet.nas_port >= 4096)
		{
			packet.nas_port = (packet.nas_port >> 12) & (0xff);
		}
	}
	
	cJSON_AddNumberToObject(root, "nas_port",        packet.nas_port);	
	cJSON_AddStringToObject(root, "nas_port_id",     packet.nas_port_id);
	cJSON_AddStringToObject(root, "nas_port_type",   packet.nas_port_type);
	cJSON_AddStringToObject(root, "nas_identifier",  packet.nas_identifier);
	cJSON_AddStringToObject(root, "service_type",    packet.service_type);
	cJSON_AddNumberToObject(root, "framed_protocol", packet.framed_protocol);
	cJSON_AddNumberToObject(root, "auth_mode",       packet.auth_mode);
	cJSON_AddStringToObject(root, "mid",             packet.mid);
	cJSON_AddStringToObject(root, "mac",             packet.mac);
	cJSON_AddNumberToObject(root, "sccheckcode",       packet.sccheckcode);

	if (strlen(packet.vm_id) > 0) {
		cJSON_AddStringToObject(root, "vm_id",        packet.vm_id);
	}
	if (strlen(packet.vm_mac) > 0) {
		cJSON_AddStringToObject(root, "vm_mac",        packet.vm_mac);
	}
	if (strlen(packet.vm_entitle_name) > 0) {
		cJSON_AddStringToObject(root, "vm_entitle_name", packet.vm_entitle_name);
	}

	if (strlen(packet.server_key) > 0) {
		cJSON_AddStringToObject(root, "server_key", packet.server_key);
	}

	if (strlen(packet.client_ip) > 0) {
		cJSON_AddStringToObject(root, "client_ip", packet.client_ip);
	}

	if (strlen(packet.system_account) > 0) {
		cJSON_AddStringToObject(root, "system_account", packet.system_account);
	}

	if (strlen(packet.os_version) > 0) {
		cJSON_AddStringToObject(root, "os_version", packet.os_version);
	}

	if (strlen(packet.ssid) > 0) {
		cJSON_AddStringToObject(root, "ssid", packet.ssid);
	}

	if (strlen(packet.host_name) > 0) {
		cJSON_AddStringToObject(root, "host_name", packet.host_name);
	}
	cJSON_AddNumberToObject(root, "authenticate_type", packet.authenticate_type);
	if ((packet.cert_file_length > 0) && (packet.auth_mode == THIRDPARTYCERT_AUTH)) {
		char* buf = NULL;
		fr_base64_encode_alloc(packet.cert_file, packet.cert_file_length, &buf);
		cJSON_AddStringToObject(root, "cert_file", buf);
		radlog(L_ERR, "[%s-%d-%s]: base64 encoded cert_file=%s", __FILE__, __LINE__, __FUNCTION__, buf);
		FREE_PTR(buf);
	} else if (packet.cert_file_length > 0) {
		cJSON_AddStringToObject(root, "cert_file", packet.cert_file);
	}
	if (strlen(packet.original_text) > 0) {
		cJSON_AddStringToObject(root, "original_text", packet.original_text);
	}
	if (strlen(packet.signer) > 0) {
		cJSON_AddStringToObject(root, "signer", packet.signer);
	}
	if (strlen(packet.verify_code) > 0) {
		cJSON_AddStringToObject(root, "v_code", packet.verify_code);
	}
	if (strlen(packet.asset_id) > 0) {
		cJSON_AddStringToObject(root, "asset_id", packet.asset_id);
	}
	if (strlen(packet.asset_oid) > 0) {
		cJSON_AddStringToObject(root, "asset_oid", packet.asset_oid);
	}

	if (strlen(packet.token) > 0) {
		cJSON_AddStringToObject(root, "token", packet.token);
	}
	char* res =  cJSON_PrintUnformatted(root);
	memcpy(result, res, strlen(res));
	FREE_PTR(res);	

	cJSON_Delete(root);

	return 0;
}


int package_json(request_packet_t packet, char*** result)
{
	if (NULL == result){
		radlog(L_ERR, "[%s-%d-%s]: parameter error.", __FILE__, __LINE__, __FUNCTION__);
		return -1;
	}

	cJSON *root = cJSON_CreateObject();
	cJSON_AddNumberToObject(root, "packet_id",       packet.packet_id);
	cJSON_AddStringToObject(root, "session_id",      packet.session_id);
	cJSON_AddNumberToObject(root, "version",         packet.version);
	cJSON_AddNumberToObject(root, "request_type",    packet.request_type);
	cJSON_AddNumberToObject(root, "source_type",     packet.source_type);


	cJSON_AddStringToObject(root, "user_name",       packet.user_name);

	cJSON *pass_word = NULL;
	cJSON_AddItemToObject(root, "pass_word", pass_word=cJSON_CreateObject());
	cJSON_AddNumberToObject(pass_word, "type",      packet.pass_word.type);
	cJSON_AddStringToObject(pass_word, "challenge", packet.pass_word.challenge);
	cJSON_AddStringToObject(pass_word, "content",   packet.pass_word.content);
	cJSON_AddStringToObject(root, "nas_ip_addr",     packet.nas_ip_addr);

	if(packet.nas_port/10000==5){
		packet.nas_port=packet.nas_port%50000;
	}
	else{ 
		if (packet.nas_port >= 4096)
		{
			packet.nas_port = (packet.nas_port >> 12) & (0xff);
		}
	}
	
	cJSON_AddNumberToObject(root, "nas_port",        packet.nas_port);	
	cJSON_AddStringToObject(root, "nas_port_id",     packet.nas_port_id);
	cJSON_AddStringToObject(root, "nas_port_type",   packet.nas_port_type);
	cJSON_AddStringToObject(root, "nas_identifier",  packet.nas_identifier);
	cJSON_AddStringToObject(root, "service_type",    packet.service_type);
	cJSON_AddNumberToObject(root, "framed_protocol", packet.framed_protocol);
	cJSON_AddNumberToObject(root, "auth_mode",       packet.auth_mode);
	cJSON_AddStringToObject(root, "mid",             packet.mid);
	cJSON_AddStringToObject(root, "mac",             packet.mac);
	
	char* res =  cJSON_PrintUnformatted(root);
	memcpy(**result, res, strlen(res));
	FREE_PTR(res);	

	cJSON_Delete(root);

	return 0;
}

int decode_recv_data(const char* data, response_packet_t* response)
{
	if (!data)
	{
		radlog(L_ERR, "[%s-%d-%s]: parameter error.", __FILE__, __LINE__, __FUNCTION__);
		return -1;
	}

	cJSON *json = NULL;
	json = cJSON_Parse(data);
	if (!json || data[0] != '{') //cJson Bug??
	{
		if (json) {
			cJSON_Delete(json);
		}
		radlog(L_ERR, "[%s-%d-%s]: cJSON_Parse error [%s].", __FILE__, __LINE__, __FUNCTION__, cJSON_GetErrorPtr());
		return -1;
	}

	response->acl = strdup(cJSON_GetObjectItem(json, "acl")->valuestring);
	
//	response->acl =  cJSON_Print(cJSON_GetObjectItem(json, "acl"));
	char* error_code = cJSON_Print(cJSON_GetObjectItem(json, "error_code"));
	if (error_code)
	{
		response->error_code = atoi(error_code);

		free(error_code);
		error_code = NULL;
	}
	else
	{
		response->error_code = 0;
	}

	//response->error_msg = (cJSON_GetObjectItem(json, "error_msg")->valuestring);
	response->error_msg = cJSON_Print(cJSON_GetObjectItem(json, "error_msg"));
	response->filter_id = cJSON_Print(cJSON_GetObjectItem(json, "filter_id"));
	response->msresponse = cJSON_Print(cJSON_GetObjectItem(json, "msresponse"));
	response->chappwd = cJSON_Print(cJSON_GetObjectItem(json, "chappwd"));
	
	char* reject_code = cJSON_Print(cJSON_GetObjectItem(json, "reject_code"));
	if (reject_code)
	{
		response->reject_code = atoi(reject_code);

		free(reject_code);
		reject_code = NULL;
	}
	else
	{
		response->reject_code = 0;
	}

	char* reject_code1 = cJSON_Print(cJSON_GetObjectItem(json, "reject_code1"));
	if (reject_code1) {
		response->reject_code1 = atoi(reject_code1);
		free(reject_code1);
		reject_code1 = NULL;
	}
	else {
		response->reject_code1 = 0;
	}

	char* expire_day = cJSON_Print(cJSON_GetObjectItem(json, "expire_day"));
	if (expire_day) {
		response->expire_day = atoi(expire_day);
		free(expire_day);
		expire_day = NULL;
	}
	else {
		response->expire_day = 0;
	}

	char* is_roam = cJSON_Print(cJSON_GetObjectItem(json, "is_roam"));
	if (is_roam) {
		response->is_roam = atoi(is_roam);
		free(is_roam);
		is_roam = NULL;
	}
	else {
		response->is_roam = 0;
	}

	response->ap_list = cJSON_Print(cJSON_GetObjectItem(json, "ap_list"));
	
	char* response_type = cJSON_Print(cJSON_GetObjectItem(json, "response_type"));
	if (response_type)
	{
		response->response_type = atoi(response_type);

		free(response_type);
		response_type = NULL;
	}
	else
	{
		response->response_type = 0;
	}

	char* result = cJSON_Print(cJSON_GetObjectItem(json, "result"));
	if (result)
	{
		response->result = atoi(result);

		free(result);
		result = NULL;
	}
	else
	{
		response->result = 0;
	}

	char* sess = cJSON_GetObjectItem(json, "session_id")->valuestring;
	response->session_id = strdup(sess);
	
	//response->session_id = cJSON_Print(cJSON_GetObjectItem(json, "session_id"));

	char* session_timeout = cJSON_Print(cJSON_GetObjectItem(json, "session_timeout"));
	if (session_timeout)
	{
		response->session_timeout = atoi(session_timeout);

		free(session_timeout);
		session_timeout = NULL;
	}
	else
	{
		response->session_timeout = 0;
	}

	response->vlan_id = strdup(cJSON_GetObjectItem(json, "vlan_id")->valuestring);

	
	char* device_type = cJSON_Print(cJSON_GetObjectItem(json, "device_type"));
	if (device_type)
	{
		response->device_type = atoi(device_type);

		free(device_type);
		device_type = NULL;
	}
	else
	{
		response->device_type = 0;
	}

	char* tianqing_auth_flag = cJSON_Print(cJSON_GetObjectItem(json, "tianqing_auth_flag"));
        if (tianqing_auth_flag)
        {
                response->tianqing_auth_flag = atoi(tianqing_auth_flag);

                free(tianqing_auth_flag);
                tianqing_auth_flag = NULL;
        }
        else
        {
                response->tianqing_auth_flag = 0;
        }	

	cJSON_Delete(json);

	return 0;
	
}


int set_vlan_id(EAP_HANDLER *handler, char * vlan_number)
{
	DICT_ATTR *da=NULL;
	VALUE_PAIR * pair_vlan=NULL;

	if (vlan_number == NULL) {
		return 0;
	}
	
	if(strlen(vlan_number) == 0){  //do not divide vlan
		if((da=dict_attrbyname("Tunnel-Type"))){
			pairdelete(&handler->request->reply->vps, da->attr);
		}
		if((da=dict_attrbyname("Tunnel-Medium-Type"))){
			pairdelete(&handler->request->reply->vps, da->attr);
		}
		if((da=dict_attrbyname("Tunnel-Private-Group-ID"))){
			pairdelete(&handler->request->reply->vps, da->attr);
		}
		if((da=dict_attrbyname("Autelan-Type"))){
			pairdelete(&handler->request->reply->vps, da->attr);
		}

	}else{

		if((da=dict_attrbyname("Tunnel-Type"))){
			if(!pairfind(handler->request->reply->vps, da->attr)){
				pairadd(&handler->request->reply->vps,
						pairmake("Tunnel-Type", "VLAN", T_OP_SET));
			}
		}
		if((da=dict_attrbyname("Tunnel-Medium-Type"))){
			if(!pairfind(handler->request->reply->vps, da->attr)){
				pairadd(&handler->request->reply->vps,
						pairmake("Tunnel-Medium-Type", "IEEE-802", T_OP_SET));
			}
		}
		if((da=dict_attrbyname("Tunnel-Private-Group-ID"))){
			if(!(pair_vlan=pairfind(handler->request->reply->vps, da->attr))){
				pairadd(&handler->request->reply->vps,
						pairmake("Tunnel-Private-Group-ID", vlan_number, T_OP_SET));
			}
			else if((strcmp(pair_vlan->vp_strvalue," ")==0)){
				pairreplace(&handler->request->reply->vps,
						pairmake("Tunnel-Private-Group-ID", vlan_number, T_OP_SET));
			}
		}
		
	}

	return 0;
	
}

int set_session_timeout(EAP_HANDLER *handler, int session_timeout)
{
	DICT_ATTR *da=NULL;
	
	char sessionTimeout[10] = {0};
	if (session_timeout == 0){
		radlog(L_ERR, "[%s-%d-%s]: session_timeout=%d", __FILE__, __LINE__, __FUNCTION__, session_timeout);
		session_timeout = 86400;
		
	}

	sprintf(sessionTimeout, "%d", session_timeout);

	if((da=dict_attrbyname("Session-Timeout"))){
			if(!pairfind(handler->request->reply->vps, da->attr)){
				pairadd(&handler->request->reply->vps,
						pairmake("Session-Timeout", sessionTimeout, T_OP_SET));
			}
		}
	
	return 0;
}

int set_voip(EAP_HANDLER *handler)
{
	DICT_ATTR *da=NULL;

	if((da=dict_attrbyname("device-traffic-class"))){
			if(!pairfind(handler->request->reply->vps, da->attr)){
				pairadd(&handler->request->reply->vps,
						pairmake("device-traffic-class", "voice", T_OP_SET));
			}
		}
	
	return 0;
	
}

int set_filter_id(EAP_HANDLER *handler, char *filter_id)
{
	radlog(L_DBG, "[%s-%d-%s]: filter_id=%s", __FILE__, __LINE__, __FUNCTION__,filter_id);
	DICT_ATTR *da=NULL;
	char *pf = strtok(filter_id, ",");
	if ((da = dict_attrbyname("Filter-Id"))) {
		if (!pairfind(handler->request->reply->vps, da->attr)) {
			while (pf != NULL) {
				pairadd(&handler->request->reply->vps, pairmake("Filter-Id", pf, T_OP_SET));
				pf = strtok(NULL, ",");
			}
		}
	}
	return 0;
}

int set_acl(EAP_HANDLER *handler, char *acl_value)
{
	DICT_ATTR *da=NULL;
	char acl[512] = {0};
	char *tok = NULL;
	
	if ((acl_value == NULL) || (strlen(acl_value) == 0)) {
		return 0;
	}
	strncpy(acl, acl_value, sizeof(acl)-1);
	char *end = acl + strlen(acl);
	tok = strchr(acl, ';');
	if (tok == NULL) {
		if ((da = dict_attrbyname("Cisco-AVPair"))) {
			if (!pairfind(handler->request->reply->vps, da->attr)) {
				pairadd(&handler->request->reply->vps, pairmake("Cisco-AVPair", acl, T_OP_SET));
			}
		}
	}
	else {
		*tok = 0;
		if ((da = dict_attrbyname("Cisco-AVPair"))) {
			if (!pairfind(handler->request->reply->vps, da->attr)) {
				pairadd(&handler->request->reply->vps, pairmake("Cisco-AVPair", acl, T_OP_SET));
			}
		}
		char *p = tok + 1;
		while (p < end) {
			tok = strchr(p, ';');
			if (tok != NULL) {
				*tok = 0;
			}
			if ((da = dict_attrbyname("Cisco-AVPair"))) {
				pairadd(&handler->request->reply->vps, pairmake("Cisco-AVPair", p, T_OP_ADD));
			}
			radlog(L_DBG, "acl part: %s\n", p);
			if (tok == NULL) break;
			p = tok + 1;
		}
	}
	
	return 0;
}
int init_rc4_key_string(unsigned char*key,int length,nac_data *pdata)
{
	char    string[ MAX_STRING_LEN]="";
	unsigned char output[MAX_STRING_LEN]="";
	unsigned short len;

	len = 0;
	memcpy(string, key, length);
	len = length;

	fr_md5_calc((u_char *)output, (u_char *)string, len);

	RC4_set_key(&(pdata->rc4_key),16,output);
	memcpy(&(pdata->rc4_key_bk),&(pdata->rc4_key),sizeof(pdata->rc4_key));
	return 0;
}


