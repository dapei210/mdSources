/*
 * eap_md5.c  EAP MD5 functionality.
 *
 * Version:     $Id: 1e6231bb369f5565d7841f33766f835dd19d18ac $
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2001,2006  The FreeRADIUS server project
 * Copyright 2001  hereUare Communications, Inc. <raghud@hereuare.com>
 */

/*
 *
 *  MD5 Packet Format in EAP Type-Data
 *  --- ------ ------ -- --- ---------
 *  0                   1                   2                   3
 *  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |  Value-Size   |  Value ...
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |  Name ...
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 */

#include <freeradius-devel/ident.h>
RCSID("$Id: 1e6231bb369f5565d7841f33766f835dd19d18ac $")

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/mman.h>
//#include <nac_monitor/nac_dot1x_online.h>
#include "eap.h"

#include "eap_nac.h"

#ifndef FREE_PTR
#define FREE_PTR(P) if(P) free(P); (P)=NULL;
#endif 


void nac_data_free(void *data)
{
	nac_data *pdata=(nac_data*)data;
	if(pdata){
		FREE_PTR(pdata->opaque);
		FREE_PTR(pdata->mid);
		FREE_PTR(pdata->user_data);
		
		pdata->data_length=0;
		pdata->buf_length=0;
		pdata->cur_length=0;
		pdata->p_send_data=NULL;
		pdata->p_recv_data=NULL;
		free(pdata);
	}
}

int nac_policy_load(nac_data **pdata,char*policy_name)
{
	FILE *f=NULL;
	long len=0;
	len=strlen(policy_name);
	if((len>1)&&(policy_name[len-1]==' ')){
		policy_name[len-1]='\0';
	}
	
	if((f=fopen(policy_name,"rb"))){

		fseek(f,0,SEEK_END);
		len=ftell(f);
		fseek(f,0,SEEK_SET);

		(*pdata)->user_data=calloc(len+1,1);
		fread((*pdata)->user_data,1,len,f);
		fclose(f);

		(*pdata)->buf_length=len+1;
		(*pdata)->data_length=len;
		(*pdata)->cur_length=len;
		
		(*pdata)->p_send_data=(*pdata)->user_data;
		(*pdata)->p_recv_data=NULL;
	}
	return 0;

}

int nac_comm_load(char **out,int *length,char*file_name)
{
        FILE *f=NULL;
        long len=0;
        len=strlen(file_name);
		*length=0;
        if((len>1)&&(file_name[len-1]==' ')){
                file_name[len-1]='\0';
        }

        if((f=fopen(file_name,"rb"))){

                fseek(f,0,SEEK_END);
                len=ftell(f);
                fseek(f,0,SEEK_SET);

                (*out)=calloc(len+1,1);
                fread((*out),1,len,f);
                fclose(f);
                *length=len;
        }
		//if(*out[len-1]=='\r'||out[len-1]=='\n'){
		//	*out[len-1]='\0';
		//}
        return 0;

}



/*
 *      Allocate a new NAC_PACKET
 */
NAC_PACKET *eapnac_alloc(void)
{
	NAC_PACKET   *rp;

	if ((rp = malloc(sizeof(NAC_PACKET))) == NULL) {
		radlog(L_ERR, "rlm_eap_md5: out of memory");
		return NULL;
	}
	memset(rp, 0, sizeof(NAC_PACKET));
	return rp;
}

/*
 *      Free NAC_PACKET
 */
void eapnac_free(NAC_PACKET **md5_packet_ptr)
{
	NAC_PACKET *md5_packet;

	if (!md5_packet_ptr) return;
	md5_packet = *md5_packet_ptr;
	if (md5_packet == NULL) return;

	if (md5_packet->value) {
		free(md5_packet->value);
		md5_packet->value=NULL;
	}
	if (md5_packet->name) {
		free(md5_packet->name);
		md5_packet->name=NULL;
	}

	free(md5_packet);
	md5_packet=NULL;

	*md5_packet_ptr = NULL;
}

/*
 *	We expect only RESPONSE for which SUCCESS or FAILURE is sent back
 */
NAC_PACKET *eapnac_extract(EAP_DS *eap_ds, int code_type)
{
	nac_packet_t	*data;
	NAC_PACKET	*packet;
	unsigned short	name_len;

	/*
	 *	We need a response, of type EAP-NAC, with at least
	 *	one byte of type data (EAP-NAC) following the 4-byte
	 *	EAP-Packet header.
	 */
	if (!eap_ds 					 ||
	    !eap_ds->response 				 ||
	    (eap_ds->response->code != PW_NAC_RESPONSE)	 ||
	    eap_ds->response->type.type != code_type/*PW_EAP_TNC*/	 ||
	    !eap_ds->response->type.data 		 ||
	    (eap_ds->response->length <= NAC_HEADER_LEN) ||
	    (eap_ds->response->type.data[0] < 0)) {
		radlog(L_ERR, "rlm_eap_nac: corrupted data");
		return NULL;
	}

	packet = eapnac_alloc();
	if (!packet) return NULL;

	/*
	 *	Code & id for MD5 & EAP are same
	 *
	 *	but md5_length = length of the EAP-NAC data, which
	 *	doesn't include the EAP header, or the octet saying
	 *	EAP-NAC.
	 */
	packet->code = eap_ds->response->code;
	packet->id = eap_ds->response->id;
	packet->length = eap_ds->response->length - (NAC_HEADER_LEN + 1);

	/*
	 *	Sanity check the EAP-NAC packet sent to us
	 *	by the client.
	 */
	data = (nac_packet_t *)eap_ds->response->type.data;

	/*
	 *	Already checked the size above.
	 */
	packet->value_size = data->value_size;

	/*
	 *	Allocate room for the data, and copy over the data.
	 */
	packet->value = malloc(packet->value_size);
	if (packet->value == NULL) {
		radlog(L_ERR, "rlm_eap_nac: out of memory");
		eapnac_free(&packet);
		return NULL;
	}
	memcpy(packet->value, data->value_name, packet->value_size);

	/*
	 *	Name is optional and is present after Value, but we
	 *	need to check for it, as eapnac_compose()
	 */
	name_len =  packet->length - (packet->value_size + 1);
	if (name_len) {
		packet->name = malloc(name_len + 1);
		if (!packet->name) {
			radlog(L_ERR, "rlm_eap_md5: out of memory");
			eapnac_free(&packet);
			return NULL;
		}
		memcpy(packet->name, data->value_name + packet->value_size,
		       name_len);
		packet->name[name_len] = 0;
	}

	return packet;
}


/*
 * verify = MD5(id+password+challenge_sent)
 */
int eapnac_verify(NAC_PACKET *packet, VALUE_PAIR* password,
		  uint8_t *challenge)
{
	char	*ptr;
	char	string[1 + MAX_STRING_LEN*2];
	unsigned char output[MAX_STRING_LEN];
	unsigned short len;

	/*
	 *	Sanity check it.
	 */
	if (packet->value_size != 16) {
		radlog(L_ERR, "rlm_eap_md5: Expected 16 bytes of response to challenge, got %d", packet->value_size);
		return 0;
	}

	len = 0;
	ptr = string;

	/*
	 *	This is really rad_chap_pwencode()...
	 */
	*ptr++ = packet->id;
	len++;
	memcpy(ptr, password->vp_strvalue, password->length);
	ptr += password->length;
	len += password->length;

	/*
	 *	The challenge size is hard-coded.
	 */
	memcpy(ptr, challenge, NAC_CHALLENGE_LEN);
	len += NAC_CHALLENGE_LEN;

	fr_md5_calc((u_char *)output, (u_char *)string, len);

	/*
	 *	The length of the response is always 16 for MD5.
	 */
	if (memcmp(output, packet->value, 16) != 0) {
		return 0;
	}
	return 1;
}



/*
 *	Compose the portions of the reply packet specific to the
 *	EAP-NAC protocol, in the EAP reply typedata
 */
int eapnac_compose(EAP_DS *eap_ds, NAC_PACKET *reply, uint8_t code_type)
{
	uint8_t *ptr;
	unsigned short name_len;

	/*
	 *	We really only send Challenge (EAP-Identity),
	 *	and EAP-Success, and EAP-Failure.
	 */
	if (reply->code < 3) {
		eap_ds->request->type.type = code_type; //PW_EAP_TNC;

		rad_assert(reply->length > 0);

		eap_ds->request->type.data = malloc(reply->length);
		if (eap_ds->request->type.data == NULL) {
			eapnac_free(&reply);
			radlog(L_ERR, "rlm_eap_md5: out of memory");
			return 0;
		}
		ptr = eap_ds->request->type.data;
		*ptr++ = (uint8_t)(reply->value_size & 0xFF);
		memcpy(ptr, reply->value, reply->value_size);

		/* Just the Challenge length */
		eap_ds->request->type.length = reply->value_size + 1;

		/*
		 *	Return the name, if necessary.
		 *
		 *	Don't see why this is *ever* necessary...
		 */
		name_len = reply->length - (reply->value_size + 1);
		if (name_len && reply->name) {
			ptr += reply->value_size;
			memcpy(ptr, reply->name, name_len);
			/* Challenge length + Name length */
			eap_ds->request->type.length += name_len;
		}
	} else {
		eap_ds->request->type.length = 0;
		/* TODO: In future we might add message here wrt rfc1994 */
	}
	eap_ds->request->code = reply->code;

	eapnac_free(&reply);

	return 1;
}


int eapnac_compose_appdata(EAP_DS *eap_ds, NAC_PACKET *reply, uint8_t code_type)
{
	uint8_t *ptr;
	
	if ((reply->code < 3)&&(reply->length>0)) {
		eap_ds->request->type.type = code_type;//PW_EAP_TNC;
		eap_ds->request->type.data = malloc(reply->length);
		if (eap_ds->request->type.data == NULL) {
			eapnac_free(&reply);
			radlog(L_ERR, "rlm_eap_nac: out of memory");
			return 0;
		}
		ptr = eap_ds->request->type.data;
		memcpy(ptr, reply->value, reply->length);

		/* Just the Challenge length */
		eap_ds->request->type.length = reply->length;

	} else {
		eap_ds->request->type.length = 0;
		/* TODO: In future we might add message here wrt rfc1994 */
	}
	eap_ds->request->code = reply->code;

	eapnac_free(&reply);

	return 1;
}


int init_rc4_key(VALUE_PAIR* password,nac_data *pdata)
{
	char	string[ MAX_STRING_LEN]="";
	unsigned char output[MAX_STRING_LEN]="";
	unsigned short len;

	len = 0;
	memcpy(string, password->vp_strvalue, password->length);
	len = password->length;

	fr_md5_calc((u_char *)output, (u_char *)string, len);
	
	RC4_set_key(&(pdata->rc4_key),16,output);
	memcpy(&(pdata->rc4_key_bk),&(pdata->rc4_key),sizeof(pdata->rc4_key));
	return 0;
}


int eapnac_get_mppe_key(uint8_t *challenge,char send_key[],char recv_key[])
{    
	char    *ptr_send;    
	char    *ptr_recv;    
    int     i;

	if(!challenge||!send_key||!recv_key)    {	
		return 1;    
	}        
	fr_md5_calc(send_key, challenge, NAC_CHALLENGE_LEN);    
	ptr_send=send_key+NAC_CHALLENGE_LEN;    
	fr_md5_calc(ptr_send, send_key, NAC_CHALLENGE_LEN);    
	fr_md5_calc(recv_key, ptr_send, NAC_CHALLENGE_LEN);    
	ptr_recv=recv_key+NAC_CHALLENGE_LEN;    
	fr_md5_calc(ptr_recv, recv_key, NAC_CHALLENGE_LEN);
    /****pairmake 中使用了strcpy，需要过滤'\0'*/
    for (i=0; i<32; i++){
        if(send_key[i]=='\0') {
            send_key[i]='0';                             
        }
        if(recv_key[i]=='\0') {
            recv_key[i]='0';
        }
    }
}	
