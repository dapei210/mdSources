﻿/*
 * rlm_eap_nac.c    Handles that are called from eap
 *
 * Version:     $Id: a8871603ae14994d05ec08d298f6c0f667ec2d83 $
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2001,2006  The FreeRADIUS server project
 * Copyright 2001  hereUare Communications, Inc. <raghud@hereuare.com>
 */

#include <freeradius-devel/ident.h>
RCSID("$Id: a8871603ae14994d05ec08d298f6c0f667ec2d83 $")

#include <freeradius-devel/autoconf.h>
#include <sys/types.h>  
#include <sys/socket.h>  
#include <sys/un.h>  

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <nac_common/auth_common.h>

#include "eap_nac.h"
#include "eap_md5.h"
#include <semaphore.h>

#include <freeradius-devel/rad_assert.h>
#include <rlm_auth_connection.h>
#include <auth_session.h>
#include <freeradius-devel/nac_attr.h>

#define UNIX_DOMAIN "/tmp/nac_server.sock"  

#define NAC_SNPRINTF(buf, format, ...) \
do { \
	offset = strlen(buf); \
	snprintf(buf+offset, sizeof(buf)-offset, format, ## __VA_ARGS__); \
} while(0)
#ifndef FREE_PTR
#define FREE_PTR(P) if(P) free(P); (P)=NULL;
#endif 

#define NAC_SSO 64
#define NAC_HEADER_LEN 		4


typedef struct rlm_eap_nac_t_ {    
	char	*vlan_access;    
	char	*vlan_isolate;    
	char    *policy_dir;
	char	*default_policy;
	char 	*acl_dir;
	char 	*isolate_acl;
	char 	*default_acl;
	char 	*heartbeat_conf;
	char	*modify_conf;
	char	*access_msg;
	char	*isolate_msg;
	char	*key_msg;
	char	*empty_msg;
	char	*null_msg;
	char	*limit_msg;
	char	*encrypt; 
	uint8_t code_type;
    rlm_auth_connection_t *auth_conn_inst;
} rlm_eap_nac_t;

VALUE_PAIR * pairfind_ascii(VALUE_PAIR *first, int attr);

void nac_send_login_event(EAP_HANDLER *handler)
{
	int len;
	int relen=0;
	int connect_fd;
	int ret;
	char snd_buf[1024]="";
	VALUE_PAIR *vp=NULL;
	DICT_ATTR *da=NULL;
	struct sockaddr_un srv_addr;


	/*获取事件属性*/

	nac_data *pdata=handler->opaque;

	snprintf(snd_buf,1024,"s_msg_type=dot1x&s_cmd_opt=login");
	len=strlen(snd_buf);


	/*获取终端MAC*/
	if((da=dict_attrbyname("Calling-Station-Id"))){
		if ((vp=pairfind_ascii(handler->request->packet->vps,  da->attr))) {
			snprintf(snd_buf+len,1024-len,"&s_mac=%s",vp->data.strvalue);		
		}
		else{
			return ;
		}
	}else{
		return ;
	}


	/*获取终端登陆用户名*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	if((da=dict_attrbyname("User-Name"))){
		if ((vp=pairfind(handler->request->packet->vps,  da->attr))) {
			snprintf(snd_buf+len,relen,"&s_account=%s",vp->data.strvalue);		
		}
		else{
			return ;
		}
	}else{
		return ;
	}

	/*获取接入交换机VLAN管理IP*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	if((da=dict_attrbyname("NAS-IP-Address"))){
		if ((vp=pairfind(handler->request->packet->vps,  da->attr))) {
			snprintf(snd_buf+len,relen,"&s_nas_ip=%s&i_nas_ip=%d",inet_ntoa(vp->data.ipaddr),vp->data.ipaddr.s_addr);		
		}
		else{
			snprintf(snd_buf+len,relen,"&s_nas_ip=''&i_nas_ip=0");   
		}
	}else{
		snprintf(snd_buf+len,relen,"&s_nas_ip=''&i_nas_ip=0");   
	}

	/*获取接入层交换机端口*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	if((da=dict_attrbyname("NAS-Port-Id"))){
		if ((vp=pairfind(handler->request->packet->vps,  da->attr))) {
			snprintf(snd_buf+len,relen,"&s_nas_port_id=%s",vp->data.strvalue);		
		}
		else{
			snprintf(snd_buf+len,relen,"&s_nas_port_id=''");  
		}
	}else{
		snprintf(snd_buf+len,relen,"&s_nas_port_id=''");  
	}

	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	if((da=dict_attrbyname("Cisco-NAS-Port"))){
		if ((vp=pairfind(handler->request->packet->vps,  da->attr))) {
			snprintf(snd_buf+len,relen,"&s_cisco_nas_port=%s",vp->data.strvalue);		
		}
		else{
			snprintf(snd_buf+len,relen,"&s_cisco_nas_port=0");  
		}
	}else{
		snprintf(snd_buf+len,relen,"&s_cico_nas_port=0");  
	}

	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	if((da=dict_attrbyname("NAS-Port"))){
		if ((vp=pairfind(handler->request->packet->vps,  da->attr))) {
			snprintf(snd_buf+len,relen,"&i_nas_port=%d",vp->lvalue);		
		}
		else{
			snprintf(snd_buf+len,relen,"&i_nas_port=0");  
		}
	}else{
		snprintf(snd_buf+len,relen,"&i_nas_port=0");  
	}

	/*获取网络接口类型*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	if((da=dict_attrbyname("NAS-Port-Type"))){
		if ((vp=pairfind(handler->request->packet->vps,  da->attr))) {
			snprintf(snd_buf+len,relen,"&s_nas_port_type=%s",vp->data.strvalue);		
		}
		else{
			snprintf(snd_buf+len,relen,"&s_nas_port_type=''");  
		}
	}else{
		snprintf(snd_buf+len,relen,"&s_nas_port_type=''");  
	}


	/*获取终端VLAN*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	if((da=dict_attrbyname("Tunnel-Private-Group-ID"))){
		if ((vp=pairfind(handler->request->reply->vps,  da->attr))) {
			snprintf(snd_buf+len,relen,"&i_vlan=%s",vp->data.strvalue);		
		}
		else{
			snprintf(snd_buf+len,relen,"&i_vlan=0");		
		}
	}else{
		snprintf(snd_buf+len,relen,"&i_vlan=0");		
	}

	/*获取终端得分*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	snprintf(snd_buf+len,relen,"&i_score=%d",pdata->total_score);		

	/*获取通过分数*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	snprintf(snd_buf+len,relen,"&i_pass=%d",pdata->pass_score);		

	/*获取终端得分*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	snprintf(snd_buf+len,relen,"&i_status=%d",pdata->parse_result);		

	/*获取健康检查结果*/
	len=strlen(snd_buf);
	relen=1024-len;
	if (relen<0) goto send;
	snprintf(snd_buf+len,relen,"&s_ret=%s",pdata->ret);		

	/*发送事件*/

send:
	connect_fd=socket(PF_UNIX,SOCK_STREAM,0);
	if(connect_fd<0)
	{
		DEBUG2("cannot create communication socket");
		return ;
	}
	srv_addr.sun_family=AF_UNIX;
	strcpy(srv_addr.sun_path,UNIX_DOMAIN);
	ret=connect(connect_fd,(struct sockaddr*)&srv_addr,sizeof(srv_addr));
	if(ret==-1)
	{
		DEBUG2("cannot connect to the server");
		close(connect_fd);
		return ;
	}
	DEBUG2("send_login event :%s",snd_buf);
	write(connect_fd,snd_buf,sizeof(snd_buf));
	close(connect_fd);
	return ;

}

void setMppeAttribute( EAP_HANDLER *handler)
{
	char send_key[33]="";    
	char recv_key[33]="";    
	nac_data *pdata=handler->opaque;

	eapnac_get_mppe_key((uint8_t*)pdata->opaque,send_key,recv_key);		
	pairadd(&handler->request->reply->vps,pairmake("MS-MPPE-Send-Key", send_key, T_OP_SET));		
	pairadd(&handler->request->reply->vps,pairmake("MS-MPPE-Recv-Key", recv_key, T_OP_SET));	    
	return ;
}

static int connect_server(const char *sk_name)                                                                
{
    int sockfd;
    struct sockaddr_un addr;

    sockfd = socket(AF_UNIX, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
		radlog(L_ERR, "connect_server: socket error");
        return -1; 
    }   

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, sk_name, sizeof(addr.sun_path) - 1); 

    if (connect(sockfd, (struct sockaddr *) &addr, sizeof(struct sockaddr_un)) == -1) { 
		radlog(L_ERR, "connect_server: connect error");
        close(sockfd);
        return -1; 
    }   
    return sockfd;
}


/**
 * @brief send authlog to skylar
 * @param result
 *			0: success
 *			1: fail
 * @param reject_code
 *			
 */
static int nac_send_log(EAP_HANDLER *handler, int result, int reject_code)
{
	int fd;
	int n = 0;
	char buf[1024] = "";
	int offset = 0;
	VALUE_PAIR *vp_nas_ip_addr = NULL;
	VALUE_PAIR *vp_nas_port = NULL;
	VALUE_PAIR *vp_nas_port_id = NULL;
	VALUE_PAIR *vp_mac = NULL;
	VALUE_PAIR *vp_user_name = NULL;
	VALUE_PAIR *vp_reason = NULL;
	DICT_ATTR *da = NULL;

	char *user_name = NULL;
	if((da = dict_attrbyname("User-Name"))) {
		if ((vp_user_name = pairfind(handler->request->packet->vps,  da->attr))) {
			user_name = vp_user_name->data.strvalue;
			NAC_SNPRINTF(buf, "user_name=%s", user_name);
		}
	}

	char *req_mac = NULL;
	if((da = dict_attrbyname("Calling-Station-Id"))) {
		if ((vp_mac = pairfind(handler->request->packet->vps,  da->attr))) {
			req_mac = vp_mac->data.strvalue;
			NAC_SNPRINTF(buf, "&mac=%s", req_mac);
		}
	}

	char* nas_ip_address = NULL;
	if((da = dict_attrbyname("NAS-IP-Address"))) {
		if ((vp_nas_ip_addr = pairfind(handler->request->packet->vps,  da->attr))) {
			nas_ip_address = inet_ntoa(vp_nas_ip_addr->data.ipaddr);
			NAC_SNPRINTF(buf, "&nas_ip=%s", nas_ip_address);
		}
	}

	int nas_port = 0;
	if((da = dict_attrbyname("NAS-Port"))) {
		if ((vp_nas_port = pairfind(handler->request->packet->vps,  da->attr))) {
			nas_port =vp_nas_port->lvalue;
			if (nas_port/10000 == 5) {
		    	nas_port = nas_port%50000;
	    	}
	    	else {
				if (nas_port >= 4096)
				{
					nas_port = (nas_port >> 12) & (0xff);
				}
	    	}
			NAC_SNPRINTF(buf, "&nas_port=%d", nas_port);
		}
	}

	char* nas_port_id =NULL;
	if((da = dict_attrbyname("NAS-Port-Id"))) {
		if ((vp_nas_port_id = pairfind(handler->request->packet->vps,  da->attr))) {
			nas_port_id = vp_nas_port_id->data.strvalue;
			NAC_SNPRINTF(buf, "&nas_port_id=%s", nas_port_id);
		}
	}

	NAC_SNPRINTF(buf, "&s_msg_type=naclog");
	NAC_SNPRINTF(buf, "&s_module=auth_log");
	NAC_SNPRINTF(buf, "&auth_source=0");
	//NAC_SNPRINTF(buf, "&auth_mode=9"); /* eap-tls mode=9 (sms后面) */
	NAC_SNPRINTF(buf, "&auth_result=%d", result);
	NAC_SNPRINTF(buf, "&reject_code=%d", reject_code);

	radlog(L_DBG, "send_log: buf=%s", buf);
	fd = connect_server(UNIX_DOMAIN);
	if (fd < 0) {
		radlog(L_ERR, "send_log: fd error");
		return -1;
	}
	n = write(fd, buf, strlen(buf));
	if (n != strlen(buf)) {
		radlog(L_ERR, "send_log: write %d bytes only", n);
	}
	close(fd);
	return n;
}
/*
 *	Initiate the EAP-NAC session by sending a challenge to the peer.
 */
static int nac_initiate(void *type_data, EAP_HANDLER *handler)
{	
	int		i;
	NAC_PACKET	*reply=NULL;
	DICT_ATTR *da = NULL;
	VALUE_PAIR *vp_user_name = NULL;
	VALUE_PAIR *vp_nas_ip_addr = NULL;
	VALUE_PAIR *vp_mac = NULL;
	VALUE_PAIR *vp_nas_ipv6_addr = NULL;
	VALUE_PAIR *vp_nas_port_type = NULL;
	char *user_name = NULL;
	char *req_mac = NULL;
	char *nas_ip_address = NULL;
	char *nas_ipv6_address = NULL;
    char *nas_port_type = NULL;
	int ret;	

	/*
	 *	Allocate an EAP-NAC packet.
	 */
	reply = eapnac_alloc();
	if (reply == NULL)  {
		radlog(L_ERR, "rlm_eap_nac: out of memory");
		return 0;
	}

	/*
	 *	Fill it with data.
	 */
	reply->code = PW_NAC_CHALLENGE;
	reply->length = 1 + NAC_CHALLENGE_LEN; /* one byte of value size */
	reply->value_size = NAC_CHALLENGE_LEN;

	/*
	 *	Allocate user data.
	 */
	reply->value = malloc(reply->value_size);
	if (reply->value == NULL) {
		radlog(L_ERR, "rlm_eap_nac: out of memory");
		eapnac_free(&reply);
		return 0;
	}

	/*
	 *	Get a random challenge.
	 */
	for (i = 0; i < reply->value_size; i++) {
		reply->value[i] = fr_rand();
	}
	DEBUG2("rlm_eap_nac: Issuing Challenge");
	if(g_multi_flag) {
		if((da=dict_attrbyname("User-Name"))){
			if ((vp_user_name=pairfind(handler->request->packet->vps,  da->attr))) {
				user_name=vp_user_name->data.strvalue;
			}
		}
		if((da=dict_attrbyname("Calling-Station-Id"))){
			if ((vp_mac=pairfind(handler->request->packet->vps,  da->attr))) {
				req_mac=vp_mac->data.strvalue;
			}
		}
		if((da=dict_attrbyname("NAS-IP-Address"))){
			if ((vp_nas_ip_addr=pairfind(handler->request->packet->vps,  da->attr))) {
				nas_ip_address=inet_ntoa(vp_nas_ip_addr->data.ipaddr);
			}
		}
		if((da=dict_attrbyname("NAS-IPv6-Address"))){
			if ((vp_nas_ipv6_addr=pairfind(handler->request->packet->vps,  da->attr))) {
				nas_ipv6_address=inet_ntoa(vp_nas_ipv6_addr->data.ipaddr);
			}
		}
    	if((da=dict_attrbyname("NAS-Port-Type"))){
    		if ((vp_nas_port_type = pairfind(handler->request->packet->vps, da->attr))) {
    			nas_port_type = vp_nas_port_type->data.strvalue;
    		}
    	}
		DEBUG2("username[%s] mac[%s] nasip[%s] nasipv6[%s]",user_name,req_mac,nas_ip_address,nas_ipv6_address);
		if(user_name != NULL && req_mac != NULL && (nas_ip_address != NULL || nas_ipv6_address != NULL)) {

			if(strstr(user_name,"REQAX") == NULL) {
				struct plugin_req plugreq;
				memset(&plugreq,0,sizeof(struct plugin_req));
				strlcpy(plugreq.username,user_name, sizeof(plugreq.username));
				strlcpy(plugreq.mac, req_mac, sizeof(plugreq.mac));
				if (nas_ip_address != NULL) {
					strlcpy(plugreq.swip, nas_ip_address, sizeof(plugreq.swip));
                }
				else {
					strlcpy(plugreq.swip, nas_ipv6_address, sizeof(plugreq.swip));
                }
                if ((nas_port_type != NULL) && (strlen(nas_port_type) > 0)) {
                    strlcpy(plugreq.nas_port_type, nas_port_type, sizeof(plugreq.nas_port_type));
                    DEBUG2("nas_port_type[%s]", plugreq.nas_port_type);
                }
				ret = plugin_query_policy(&plugreq);
				DEBUG2("plugin ret[%d]",ret);
				if(ret == 1){
					reply->length = NAC_CHALLENGE_LEN + PLUGIN_CODE_LEN +1 ;
					reply->name = malloc(PLUGIN_CODE_LEN);
					if(reply->name == NULL) {
						radlog(L_ERR, "rlm_eap_nac: out of memory");
						eapnac_free(&reply);
						return 0;

					}
					DEBUG2("plugin ret[%d]",ret);
					memset(reply->name, 0, sizeof(reply->name));
					reply->name[0] = 1;
				}
					
			}
			
		}
	
	}
	/*
	 *	Keep track of the challenge.
	 */
	handler->opaque = (nac_data*)calloc(sizeof(nac_data),1);
	rad_assert(handler->opaque != NULL);
	((nac_data*)(handler->opaque))->opaque= malloc(reply->value_size);
	memcpy(((nac_data*)(handler->opaque))->opaque, reply->value, reply->value_size);
	handler->free_opaque = nac_data_free;




	/*
	 *	Compose the EAP-NAC packet out of the data structure,
	 *	and free it.
	 */
	eapnac_compose(handler->eap_ds, reply, handler->eap_type);
	

	/*
	 *	We don't need to authorize the user at this point.
	 *
	 *	We also don't need to keep the challenge, as it's
	 *	stored in 'handler->eap_ds', which will be given back
	 *	to us...
	 */
	handler->stage = AUTHENTICATE;
	handler->count=0;

	/******************************************************/
	//nac_data_load(&(handler->opaque));
	/******************************************************/

	return 1;
}


int nac_initiate_ex(void *type_data, EAP_HANDLER *handler)
{
	return nac_initiate(type_data, handler);
}

static int fill_send_data(rlm_eap_nac_t *inst ,nac_data *pdata, int type,NAC_PACKET *reply)
{
	/*******test*****//*
			     memcpy(&(pdata->rc4_key),&(pdata->rc4_key_bk),sizeof(pdata->rc4_key));
			     RC4(&(pdata->rc4_key),pdata->data_length,pdata->user_data,pdata->user_data);

			     FILE *pf=fopen("/tmp/out.txt","w+");
			     fwrite(pdata->user_data,1,pdata->data_length,pf);
			     fclose(pf);

			     memcpy(&(pdata->rc4_key),&(pdata->rc4_key_bk),sizeof(pdata->rc4_key));
			     RC4(&(pdata->rc4_key),pdata->data_length,pdata->user_data,pdata->user_data);



			     DEBUG2("decode data:%s",pdata->user_data);
			   ****************/
	memcpy(&(pdata->rc4_key),&(pdata->rc4_key_bk),sizeof(pdata->rc4_key));


	if(pdata->cur_length>(NAC_DATA_LEN-1)){
		if(type==0){//第一次发送数据
			reply->value=(unsigned char*)calloc(NAC_DATA_LEN+1,1);
			memcpy(reply->value+4,pdata->p_send_data,NAC_DATA_LEN-4);

			pdata->cur_length-=(NAC_DATA_LEN-4);
			pdata->p_send_data+=(NAC_DATA_LEN-4);
			reply->value[0]=NAC_MORE+NAC_INCLUDE_LEN;
			/*if(strcmp(inst->encrypt,"1")==0){
			  reply->value[0]+=NAC_ENCRYPT;
			  }*/
			reply->value[1]=((pdata->data_length)&0x00ffffff)>>16;
			reply->value[2]=((pdata->data_length)&0x0000ff00)>>8;
			reply->value[3]=(pdata->data_length)&0x000000ff;
			reply->length=NAC_DATA_LEN;
		}else{ //响应ACK
			reply->value=(unsigned char*)calloc(NAC_DATA_LEN+1,1);						
			memcpy(reply->value+1,pdata->p_send_data,NAC_DATA_LEN-1);						
			pdata->cur_length-=(NAC_DATA_LEN-1);						
			pdata->p_send_data+=(NAC_DATA_LEN-1);						
			reply->code = PW_NAC_CHALLENGE;						
			reply->value[0]=NAC_MORE;						
			reply->length=NAC_DATA_LEN;
		}
	}else if(pdata->cur_length>0){
		reply->value=(unsigned char*)calloc(pdata->cur_length+2,1);
		memcpy(reply->value+1,pdata->p_send_data,pdata->cur_length);

		reply->value[0]=0;
		/*if(strcmp(inst->encrypt,"1")==0){
		  reply->value[0]+=NAC_ENCRYPT;
		  }*/
		reply->length=pdata->cur_length+1;
		pdata->cur_length=0;
		pdata->p_send_data=NULL;
	}else{
		return 1;
	}

	return 0;

}


int fill_result_data(rlm_eap_nac_t *inst, EAP_HANDLER *handler,int ret,int old_version)
{
	char acl_name[256]="";
	VALUE_PAIR *vp;
	DICT_ATTR *da=NULL;
	VALUE_PAIR *vp_group;
	DICT_ATTR *da_group=NULL;
	char *acl_data=NULL;
	char *hb_data=NULL;
	char *modify_data=NULL;
	int  acl_len=0;
	int  hb_len=0;
	int  modify_len=0;
	int ret_len=0;
	nac_data *pdata=handler->opaque;

	if(ret==0||ret==2){
		if((da_group=dict_attrbyname("QAX-User-Group"))&&
				(vp_group=pairfind(handler->request->reply->vps, da_group->attr))){
			snprintf(acl_name,256,"%s/%s.acl.%s",inst->acl_dir,
					inst->isolate_acl,vp_group->data.strvalue);
		}else{
			snprintf(acl_name,256,"%s/%s.acl.",inst->acl_dir,inst->isolate_acl);
		}
	}else{
		if((da=dict_attrbyname("QAX-User-Acl"))&&
				(vp=pairfind(handler->request->reply->vps, da->attr))&&
				(strcmp(vp->data.strvalue," ")!=0)){
			if((da_group=dict_attrbyname("QAX-User-Group"))&&
					(vp_group=pairfind(handler->request->reply->vps, da_group->attr))){
				snprintf(acl_name,256,"%s/%s.acl.%s",inst->acl_dir,
						vp->data.strvalue,vp_group->data.strvalue);
			}else{
				snprintf(acl_name,256,"%s/%s.acl.",inst->acl_dir,vp->data.strvalue);
			}
		}else if(inst->default_acl){
			if((da_group=dict_attrbyname("QAX-User-Group"))&&
					(vp_group=pairfind(handler->request->reply->vps, da_group->attr))){
				snprintf(acl_name,256,"%s/%s.acl.%s",inst->acl_dir,
						inst->default_acl,vp_group->data.strvalue);
			}else{
				snprintf(acl_name,256,"%s/%s.acl.",inst->acl_dir,inst->default_acl);
			}
		}
	}



	switch (ret){
		case 0: //隔离
			ret_len=128+strlen(inst->isolate_msg)+acl_len+hb_len;
			if (pdata->buf_length<ret_len){
				pdata->user_data=realloc(pdata->user_data,ret_len);
			}
			snprintf(pdata->user_data,ret_len,"{\"type\":10,\"ret\":2,\"total\":%d,\"msg\":\"%s\",\"acl_policy\":%s,\"heartbeat\":%s}",
					pdata->total_score,inst->isolate_msg,acl_data==NULL?"{}":acl_data,hb_data==NULL?"{}":hb_data);
			pdata->buf_length=ret_len;
			pdata->data_length=strlen(pdata->user_data);
			pdata->cur_length=pdata->data_length;
			pdata->p_send_data=pdata->user_data;
			pdata->p_recv_data=NULL;

			break;
		case 1: //通过
			ret_len=128+strlen(inst->access_msg)+acl_len+hb_len+modify_len;
			if (pdata->buf_length<ret_len){
				pdata->user_data=realloc(pdata->user_data,ret_len);
			}
			snprintf(pdata->user_data,ret_len,"{\"type\":10,\"ret\":1,\"total\":%d,\"msg\":\"%s\",\"acl_policy\":%s,\"heartbeat\":%s,\"modify_url\":\"%s\"}",
					pdata->total_score,inst->access_msg,acl_data==NULL?"{}":acl_data,hb_data==NULL?"{}":hb_data,modify_data==NULL?"":modify_data);
			pdata->buf_length=ret_len;
			pdata->data_length=strlen(pdata->user_data);
			pdata->cur_length=pdata->data_length;
			pdata->p_send_data=pdata->user_data;
			pdata->p_recv_data=NULL;
			break;
		case 2:	//关键项未通过
			ret_len=128+strlen(inst->key_msg)+acl_len+hb_len;
			if (pdata->buf_length<ret_len){
				pdata->user_data=realloc(pdata->user_data,ret_len);
			}
			snprintf(pdata->user_data,ret_len,"{\"type\":10,\"ret\":2,\"total\":%d,\"msg\":\"%s\",\"acl_policy\":%s,\"heartbeat\":%s}",
					pdata->total_score,inst->key_msg,acl_data==NULL?"{}":acl_data,hb_data==NULL?"{}":hb_data);
			pdata->buf_length=ret_len;
			pdata->data_length=strlen(pdata->user_data);
			pdata->cur_length=pdata->data_length;
			pdata->p_send_data=pdata->user_data;
			pdata->p_recv_data=NULL;
			break;
		case 3: //空策略
			ret_len=128+strlen(inst->empty_msg)+acl_len+hb_len;
			if (pdata->buf_length<ret_len){
				pdata->user_data=realloc(pdata->user_data,ret_len);
			}
			snprintf(pdata->user_data,ret_len,"{\"type\":10,\"ret\":1,\"msg\":\"%s\",\"acl_policy\":%s,\"heartbeat\":%s,\"modify_url\":\"%s\"}",
					inst->empty_msg,acl_data==NULL?"{}":acl_data,hb_data==NULL?"{}":hb_data,modify_data==NULL?"":modify_data);
			pdata->buf_length=ret_len;
			pdata->data_length=strlen(pdata->user_data);
			pdata->cur_length=pdata->data_length;
			pdata->p_send_data=pdata->user_data;
			pdata->p_recv_data=NULL;
			break;
		case 4: //用户数超上限
			ret_len=128+strlen(inst->limit_msg);
			if (pdata->buf_length<ret_len){
				pdata->user_data=realloc(pdata->user_data,ret_len);
			}
			snprintf(pdata->user_data,ret_len,"{\"type\":10,\"ret\":1,\"msg\":\"%s\"}",inst->limit_msg);
			pdata->buf_length=ret_len;
			pdata->data_length=strlen(pdata->user_data);
			pdata->cur_length=pdata->data_length;
			pdata->p_send_data=pdata->user_data;
			pdata->p_recv_data=NULL;
			break;
		case 5:        
			//	ret_len=128+strlen(inst->empty_msg)+acl_len+hb_len;
			ret_len=1024;
			if (pdata->buf_length<ret_len){
				pdata->user_data=realloc(pdata->user_data,ret_len);
			}
			if (pdata->is_roam == 1) {
				if (old_version) {
					snprintf(pdata->user_data, ret_len, "{\"type\":10,\"ret\":1,\"msg\":\"%s\",\"heartbeat\":\"%s\",\"modify_url\":\"%s\"}",
						inst->empty_msg, hb_data == NULL ? "{}" : hb_data, modify_data == NULL ? "" : modify_data);
				} else {
					snprintf(pdata->user_data, ret_len, "{\"type\":10,\"ret\":1,\"msg\":\"%s\",\"heartbeat\":\"%s\",\"modify_url\":\"%s\",\"isroam\":%d,\"aplist\":%s,\"reject_code\":%d, \"reject_code1\":%d, \"expire_day\":%d, \"tianqing_auth_flag\":%d}",
						inst->empty_msg, hb_data == NULL ? "{}" : hb_data, modify_data == NULL ? "" : modify_data, pdata->is_roam, pdata->ap_list == NULL ? "[]" : pdata->ap_list, pdata->reject_code, pdata->reject_code1, pdata->expire_day, pdata->tianqing_auth_flag);
				}
			}
			else {
				if (old_version) {
					snprintf(pdata->user_data, ret_len, "{\"type\":10,\"ret\":1,\"msg\":\"%s\",\"heartbeat\":\"%s\",\"modify_url\":\"%s\"}",
					inst->empty_msg, hb_data == NULL ? "{}" : hb_data, modify_data == NULL ? "" : modify_data);
				} else {
					snprintf(pdata->user_data, ret_len, "{\"type\":10,\"ret\":1,\"msg\":\"%s\",\"heartbeat\":\"%s\",\"modify_url\":\"%s\",\"reject_code\":%d, \"reject_code1\":%d, \"expire_day\":%d, \"tianqing_auth_flag\":%d}",
						inst->empty_msg, hb_data == NULL ? "{}" : hb_data, modify_data == NULL ? "" : modify_data, pdata->reject_code, pdata->reject_code1, pdata->expire_day, pdata->tianqing_auth_flag);
				}
			}
			pdata->buf_length=ret_len;
			pdata->data_length=strlen(pdata->user_data);
			pdata->cur_length=pdata->data_length;
			pdata->p_send_data=pdata->user_data;
			pdata->p_recv_data=NULL;			
			break;
		case 6:         
			//ret_len=128+strlen(inst->empty_msg)+20;
			ret_len=1024;

			if (pdata->buf_length<ret_len){
				pdata->user_data=realloc(pdata->user_data,ret_len);
			}
			if (strlen(pdata->error_msg) > 0) {
				snprintf(pdata->user_data,ret_len,"{\"type\":10,\"ret\":2,\"msg\":%s,\"reject_code\":%d, \"reject_code1\":%d, \"expire_day\":%d, \"tianqing_auth_flag\":%d}", pdata->error_msg, pdata->reject_code, pdata->reject_code1, pdata->expire_day, pdata->tianqing_auth_flag);
			}
			else {
				snprintf(pdata->user_data,ret_len,"{\"type\":10,\"ret\":2,\"msg\":\"\",\"reject_code\":%d, \"reject_code1\":%d, \"expire_day\":%d,\"tianqing_auth_flag\":%d}", pdata->reject_code, pdata->reject_code1, pdata->expire_day, pdata->tianqing_auth_flag);
			}
			pdata->buf_length=ret_len;
			pdata->data_length=strlen(pdata->user_data);
			pdata->cur_length=pdata->data_length;
			pdata->p_send_data=pdata->user_data;
			pdata->p_recv_data=NULL;	
			break;
	}
	if(acl_data){
		free(acl_data);
	}
	if(hb_data){
		free(hb_data);
	}
	DEBUG2("rlm_eap_nac: result: %s",pdata->user_data);

	/*if(strcmp(inst->encrypt,"1")==0){
	  memcpy(&(pdata->rc4_key),&(pdata->rc4_key_bk),sizeof(pdata->rc4_key));
	  RC4(&(pdata->rc4_key),pdata->cur_length,pdata->user_data,pdata->user_data);
	  }*/
	return 0;
}

static int handle_stage2(rlm_eap_nac_t *inst, EAP_HANDLER *handler)
{
	session_handle_t *sess = NULL;
	request_packet_t request_packet;
	nac_data *pdata=handler->opaque;
	char send_buf[4096] ={0};
	int i;
	
	memset(&request_packet, 0, sizeof(request_packet_t));
	package_request_stage2(handler, &request_packet);

	package_to_json(request_packet, send_buf);

	radlog(L_DBG, "[%s-%d-%s]: add session", __FILE__, __LINE__, __FUNCTION__);
	sess = auth_session_add(request_packet.session_id);
	if (!sess) {
		radlog(L_ERR, "[%s-%d-%s]: auth_session_add failed.", __FILE__, __LINE__, __FUNCTION__);
		pdata->result_code = 0;
		return -1;
	}
	if (!inst->auth_conn_inst->send) {
		radlog(L_ERR, "[%s-%d-%s]: send func null", __FILE__, __LINE__, __FUNCTION__);
		pdata->result_code = 0;
		auth_session_del(sess);
		return -1;
	}
	int send_ret = inst->auth_conn_inst->send(inst->auth_conn_inst, send_buf, strlen(send_buf)+1);
	if (send_ret < 0) {
		radlog(L_ERR, "[%s-%d-%s]: send to auth center failed.", __FILE__, __LINE__, __FUNCTION__);
		pdata->result_code = 0;
		auth_session_del(sess);
		return -1;
	}

	int timer = 0;
	while (!sess->resp_available){
		timer++;
		usleep(1000*10);  
		if (timer == 4000){   /*1秒*/
			break;
		}
	}

	if (sess->resp_available == 0) {
		radlog(L_ERR, "[%s-%d-%s]: Receive from authd center failed.", __FILE__, __LINE__, __FUNCTION__);
		pdata->result_code = 0;
		auth_session_del(sess);
		return -1;
	}

	response_packet_t response;
	memcpy(&response, &(sess->response), sizeof(response_packet_t));
	radlog(L_ERR, "[%s-%d-%s]: response.result=%d", __FILE__, __LINE__, __FUNCTION__, response.result);
	pdata->reject_code = response.reject_code;
	pdata->reject_code1 = response.reject_code1;
	pdata->expire_day = response.expire_day;
	pdata->tianqing_auth_flag = response.tianqing_auth_flag;
	if (response.result == 1) {
		pdata->result_code = 1;
		if (response.error_msg != NULL) {
			strlcpy(pdata->error_msg, response.error_msg, sizeof(pdata->error_msg));
		}
	} else {
		pdata->result_code = 0;
		pdata->is_roam = response.is_roam;
		if (response.ap_list != NULL) {
			strlcpy(pdata->ap_list, response.ap_list, sizeof(pdata->ap_list));
		}
	}

	pdata->session_timeout = response.session_timeout;
	if ((response.vlan_id != NULL) && (strlen(response.vlan_id) > 0) ) {
		strncpy(pdata->vlan_id, response.vlan_id, sizeof(pdata->vlan_id)-1);
		radlog(L_DBG, "[%s-%d-%s]: vlan_id=%s", __FILE__, __LINE__, __FUNCTION__, pdata->vlan_id);
	}
	if ((response.filter_id != NULL) && (strlen(response.filter_id) > 0) ) {
		strncpy(pdata->filter_id, response.filter_id, sizeof(pdata->filter_id)-1);
		radlog(L_DBG, "[%s-%d-%s]: filter_id=%s", __FILE__, __LINE__, __FUNCTION__, pdata->filter_id);
	}
	pdata->num_attr = response.num_attr;
	if (pdata->num_attr > 0) {
		for (i = 0; i < response.num_attr; i++) {
			pdata->attr_type[i] = response.attr_type[i];
			strlcpy(pdata->attr_val[i], response.attr_val[i], NAC_RADIUS_ATTR_MAX_SIZE-1);
		}
	}
	auth_session_del(sess);
	return 0;
}


/*
*/
static int nac_authenticate(void *type_arg, EAP_HANDLER *handler)
{	


	NAC_PACKET	*packet=NULL;
	NAC_PACKET	*reply=NULL;
	nac_data *pdata=handler->opaque;
	unsigned char *raw_data=NULL;
	/*
	 *	Get the Cleartext-Password for this user.
	 */
	rad_assert(handler->request != NULL);
	rlm_eap_nac_t *inst = type_arg;	

	//NAC_HANDLE_PACKET* nac_handle_pack = NULL;
    session_handle_t *sess = NULL;
    nac_attr_t *attr = NULL;
    int i;

	switch(handler->stage){
		case AUTHENTICATE:
			if (!(packet = eapnac_extract(handler->eap_ds, handler->eap_type))){
				return 0;
			}
			reply = eapnac_alloc();
			if (!reply) {
				eapnac_free(&packet);
				return 0;
			}
			reply->id = handler->eap_ds->request->id;
			reply->length = 0;

			uint8_t *resp_data = handler->eap_ds->response->type.data;

			request_packet_t request_packet;
			memset(&request_packet, 0, sizeof(request_packet_t));

            if (g_nac_bypass) {
    			handler->stage=EVALUATE;
    			reply->code = PW_NAC_CHALLENGE;
                pdata->result_code = 0;
			    pdata->session_timeout = 720000;
				fill_result_data(inst,handler,6,0);

				if(fill_send_data(inst ,pdata,0, reply)){
					DEBUG2("rlm_eap_nac: evaluate not have enougth data");
					reply->code =  PW_NAC_FAILURE;
					reply->id = handler->eap_ds->request->id;
					reply->value_size=0;
				}

				eapnac_free(&packet);

				break;
            }


			//Compatible with previous versions
			if ((resp_data[0] == 0x10 )){
				nac_package_request(MODE_COMP_NAC, handler, packet, &request_packet); 
			}
            else if ((resp_data[0] == 0x00)) {
                #if 0
                //move seccheck into auth_center
                if (resp_data[2] & 0x80) {
                      /* security check flag is set, need check its result */
                    if ((resp_data[2] & 0x7f) == 2) {
                        /* 0~no security check,
                         * 1~pass security check,
                         * 2~not passed
                         */
                        radlog(L_ERR, "[%s-%d-%s]: client security check failed", __FILE__, __LINE__, __FUNCTION__);
                        reply->code = PW_NAC_CHALLENGE;
                        pdata->reject_code = ERR_SECURITY_CHECK_FAILED;
                        pdata->result_code = 1;
                        handler->stage=EVALUATE;
                        fill_result_data(inst,handler,6,0);
                        if(fill_send_data(inst ,pdata,0, reply)){
                            DEBUG2("rlm_eap_nac: evaluate not have enougth data");
                            reply->code =  PW_NAC_FAILURE;
                            reply->id = handler->eap_ds->request->id;
                            reply->value_size=0;
                        }
                        nac_send_log(handler, 1, ERR_SECURITY_CHECK_FAILED);
                        eapnac_free(&packet);
                        break;
                    }
                }
                #endif
				nac_package_request(MODE_NAC, handler, packet, &request_packet);			

			}
            else {
				radlog(L_ERR, "[%s-%d-%s]: the data send by client is error.", __FILE__, __LINE__, __FUNCTION__);
				handler->count++;
				reply->code = PW_NAC_CHALLENGE;

				pdata->reject_code = ERR_CLINET_PACKET;
				pdata->result_code = 1;
				fill_result_data(inst,handler,6,0);

				if(fill_send_data(inst ,pdata,0, reply)){
					DEBUG2("rlm_eap_nac: evaluate not have enougth data");
					reply->code =  PW_NAC_FAILURE;
					reply->id = handler->eap_ds->request->id;
					reply->value_size=0;
				}

				eapnac_free(&packet);
				handler->stage=EVALUATE;

				break;
			}
			eapnac_free(&packet);
			if (pdata->auth_mode == 6) {
				radlog(L_DBG, "[%s-%d-%s]: big cert auth, stage one finished", __FILE__, __LINE__, __FUNCTION__);
				handler->stage=EVALUATE;
				reply->code = PW_NAC_CHALLENGE;
				pdata->result_code = 0;
				pdata->session_timeout = 720000;
				fill_result_data(inst,handler,6,0);
				if(fill_send_data(inst ,pdata,0, reply)){
					DEBUG2("rlm_eap_nac: evaluate not have enougth data");
					reply->code =  PW_NAC_FAILURE;
					reply->id = handler->eap_ds->request->id;
					reply->value_size=0;
				}
				break;
			}
			char send_buf[4096] ="";

			package_to_json(request_packet, send_buf);

			radlog(L_DBG, "[%s-%d-%s]: add session", __FILE__, __LINE__, __FUNCTION__);
            sess = auth_session_add(request_packet.session_id);
            if (!sess) {
				radlog(L_ERR, "[%s-%d-%s]: auth_session_add failed.", __FILE__, __LINE__, __FUNCTION__);
                eapnac_free(&reply);
                return 0;
            }
            if (!inst->auth_conn_inst->send) {
			    radlog(L_ERR, "[%s-%d-%s]: send func null", __FILE__, __LINE__, __FUNCTION__);
                auth_session_del(sess);
                eapnac_free(&reply);
                return 0;
            }
            int send_ret = inst->auth_conn_inst->send(inst->auth_conn_inst, send_buf, strlen(send_buf)+1);
            if (send_ret < 0) {
                radlog(L_ERR, "[%s-%d-%s]: send to auth center failed, then bypass", __FILE__, __LINE__, __FUNCTION__);
                reply->code = PW_NAC_CHALLENGE;
                pdata->result_code = 0;
                pdata->session_timeout = 720000;
                fill_result_data(inst,handler,6,0);
                if (fill_send_data(inst ,pdata,0, reply)) {
                    DEBUG2("rlm_eap_nac: evaluate not have enougth data");
                    reply->code =  PW_NAC_FAILURE;
                    reply->id = handler->eap_ds->request->id;
                    reply->value_size=0;
                }
                handler->stage=EVALUATE;
                break;
            }

			int timer = 0;
			while (!sess->resp_available){
				timer++;
				usleep(1000*10);  
				if (timer == 4000){   /*1秒*/
					break;
				}
			}

			if (sess->resp_available == 0)
			{
				radlog(L_ERR, "[%s-%d-%s]: Receive from authd center failed, then bypass", __FILE__, __LINE__, __FUNCTION__);
				//pdata->reject_code = ERR_AUTH_CENTER_PACKET;
				pdata->result_code = 0;
				pdata->session_timeout = 720000;
				fill_result_data(inst,handler,6,0);
				handler->stage=EVALUATE;

				reply->code = PW_NAC_CHALLENGE;

				if(fill_send_data(inst ,pdata,0, reply)){
					DEBUG2("rlm_eap_nac: evaluate not have enougth data");
					reply->code =  PW_NAC_FAILURE;
					reply->id = handler->eap_ds->request->id;
					reply->value_size=0;
				}

				break;
			}

			response_packet_t response;
			memcpy(&response, &(sess->response), sizeof(response_packet_t));

			pdata->reject_code = response.reject_code;
			pdata->reject_code1 = response.reject_code1;
			pdata->expire_day = response.expire_day;
			pdata->tianqing_auth_flag = response.tianqing_auth_flag;
			if (response.result == 1){
				pdata->result_code = 1;
                if (response.error_msg != NULL) {
                    strlcpy(pdata->error_msg, response.error_msg, sizeof(pdata->error_msg));
                }
				fill_result_data(inst,handler,6,0);
			}else{		
				pdata->result_code = 0;
				pdata->is_roam = response.is_roam;
				if (response.ap_list != NULL) {
					strlcpy(pdata->ap_list, response.ap_list, sizeof(pdata->ap_list));
				}
				if (strlen(request_packet.system_account) == 0 && strlen(request_packet.host_name) == 0) {
					fill_result_data(inst,handler,5,1);
				} else {
					fill_result_data(inst,handler,5,0);
				}
			}	
			handler->stage=EVALUATE;
			reply->code = PW_NAC_CHALLENGE;

			pdata->session_timeout = response.session_timeout;
			if ((response.vlan_id != NULL) && (strlen(response.vlan_id) > 0) ) {
				strncpy(pdata->vlan_id, response.vlan_id, sizeof(pdata->vlan_id)-1);
				radlog(L_DBG, "[%s-%d-%s]: vlan_id=%s", __FILE__, __LINE__, __FUNCTION__, pdata->vlan_id);
			}
			if ((response.filter_id != NULL) && (strlen(response.filter_id) > 0) ) {
				strncpy(pdata->filter_id, response.filter_id, sizeof(pdata->filter_id)-1);
				radlog(L_DBG, "[%s-%d-%s]: filter_id=%s", __FILE__, __LINE__, __FUNCTION__, pdata->filter_id);
			}
			pdata->num_attr = response.num_attr;
			if (pdata->num_attr > 0) {
				for (i = 0; i < response.num_attr; i++) {
					pdata->attr_type[i] = response.attr_type[i];
					strlcpy(pdata->attr_val[i], response.attr_val[i], NAC_RADIUS_ATTR_MAX_SIZE-1);
				}
			}
			if(fill_send_data(inst ,pdata,0, reply)){
				DEBUG2("rlm_eap_nac: evaluate not have enougth data");
				reply->code =  PW_NAC_FAILURE;
				reply->id = handler->eap_ds->request->id;
				reply->value_size=0;
			}

			//free_resp(&response);			
			break;

		case EVALUATE:

			raw_data=handler->eap_ds->response->type.data;
			reply = eapnac_alloc();
			if (!reply) {
				DEBUG2("rlm_eap_nac: eapnac_alloc error");
				return 0;
			}

			if(raw_data[0]&NAC_ACK){ 
				if(fill_send_data(inst ,pdata,1, reply)){
					DEBUG2("rlm_eap_nac: evaluate not have enougth data");
					reply->code =  PW_NAC_FAILURE;
					reply->id = handler->eap_ds->request->id;
					reply->value_size=0;
				}else{
					reply->code = PW_NAC_CHALLENGE;
					reply->id = handler->eap_ds->request->id++;
				}
			}else{ 
				reply->id = handler->eap_ds->request->id;
				if (pdata->auth_mode == 6) {
					radlog(L_ERR, "[%s-%d-%s]: big cert stage 2 start", __FILE__, __LINE__, __FUNCTION__);
					handle_stage2(inst, handler);
				}
				if (pdata->result_code == 0){ //success

					reply->length = 0;
					reply->code = PW_NAC_SUCCESS;
					//set vlan
					if ((strlen(pdata->vlan_id) > 0)){
						radius_set_attr_value(&handler->request->reply->vps, "Vlan-Type", PW_TYPE_STRING, pdata->vlan_id);
					}
					if ((handler->eap_type == PW_EAP_TNC) || (handler->eap_type == PW_EAP_ZONE)) {
						setMppeAttribute(handler);
					}
					//set session timeout
					if (pdata->session_timeout > 0) {
						if (g_term_action && pdata->session_timeout != 31536000) { 
							radius_set_attr_value(&handler->request->reply->vps, "Termination-Action", PW_TYPE_INTEGER, &g_term_action);
						}
						radius_set_attr_value(&handler->request->reply->vps, "Session-Timeout", PW_TYPE_INTEGER, &pdata->session_timeout);
					}
					if (strlen(pdata->filter_id) > 0) {
						radius_set_attr_value(&handler->request->reply->vps, "Filter-Id", PW_TYPE_STRING, pdata->filter_id);
					}
					for (i = 0; i < pdata->num_attr; i++) {
						attr = nac_attr_get(pdata->attr_type[i]);
						if (attr && attr->attr_handler) {
							radlog(L_DBG, "[%s-%d-%s]: attr %s", __FILE__, __LINE__, __FUNCTION__, attr);
							attr->attr_handler(&(handler->request->reply->vps), attr->name, pdata->attr_val[i]);
						} else {
							radlog(L_ERR, "[%s-%d-%s]: attr type=%d not found", __FILE__, __LINE__, __FUNCTION__, pdata->attr_type[i]);
						}
					}
				} else {	//failed
					reply->code = PW_NAC_FAILURE;
					reply->value_size=0;
				}	
			}
			break;
		default:
			return 0;
	}
    if (sess) {
        auth_session_del(sess);
    }
	/*
	 *	Compose the EAP-NAC packet out of the data structure,
	 *	and free it.
	 */
	eapnac_compose_appdata(handler->eap_ds, reply, handler->eap_type);

	//	eapnac_free(&packet);
	return 1;
}

int nac_authenticate_ex(void *type_arg, EAP_HANDLER *handler)
{
	return nac_authenticate(type_arg, handler);
}


static CONF_PARSER module_config[] = {
	{ "vlan_access", PW_TYPE_STRING_PTR,offsetof(rlm_eap_nac_t, vlan_access), NULL, NULL },
	{ "vlan_isolate", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, vlan_isolate), NULL, NULL },
	{ "policy_dir", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, policy_dir), NULL, NULL },
	{ "default_policy", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, default_policy), NULL, NULL },
	{ "acl_dir", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, acl_dir), NULL, NULL },
	{ "isolate_acl", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, isolate_acl), NULL, NULL },
	{ "default_acl", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, default_acl), NULL, NULL },
	{ "heartbeat_conf", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, heartbeat_conf), NULL, NULL },
	{ "modify_conf", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, modify_conf), NULL, NULL },
	{ "access_msg", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, access_msg), NULL, NULL },
	{ "isolate_msg", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, isolate_msg), NULL, NULL },
	{ "key_msg", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, key_msg), NULL, NULL },
	{ "empty_msg", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, empty_msg), NULL, NULL },
	{ "null_msg", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, null_msg), NULL, NULL },
	{ "limit_msg", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, limit_msg), NULL, NULL },
	{ "encrypt", PW_TYPE_STRING_PTR, offsetof(rlm_eap_nac_t, encrypt), NULL, NULL },
	{ NULL, -1, 0, NULL, NULL }           /* end the list */
};

static int nac_detach(void *arg)
{
	free(arg);
	return 0;
}


int nac_detach_ex(void *arg)
{
	return nac_detach(arg);
}


//PW_EAP_TNC
static int nac_attach_ex(CONF_SECTION *cs, void **instance, uint8_t code_type)
{
	rlm_eap_nac_t *inst;

	inst = malloc(sizeof(*inst));
	if (!inst) return -1;
	memset(inst, 0, sizeof(*inst));

	if (cf_section_parse(cs, inst, module_config) < 0) {
		nac_detach(inst);
		return -1;
	}

	inst->code_type = code_type;
	*instance = inst;

    radlog(L_INFO, "\n\nload rlm_auth_connection\n\n");
    module_instance_t *modinst;
    modinst = find_module_instance(cf_section_find("modules"), "auth_connection", 1);
    if (!modinst) {
        radlog(L_ERR, "[%s-%d-%s]: auth_connection module load failed",  __FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
    inst->auth_conn_inst = (rlm_auth_connection_t *) modinst->insthandle;
	return 0;
}


int nac_attach_ex_ex(CONF_SECTION *cs, void **instance, uint8_t code_type)
{
	return nac_attach_ex(cs, instance,  code_type);
}


static int nac_attach(CONF_SECTION *cs, void **instance)
{
	return nac_attach_ex(cs, instance, PW_EAP_TNC);
}



/*
 *	The module name should be the only globally exported symbol.
 *	That is, everything else should be 'static'.
 */

EAP_TYPE rlm_eap_nac = {
	"eap_nac",
	nac_attach,				/* attach */
	nac_initiate,			/* Start the initial request */
	NULL,				/* authorization */
	nac_authenticate,		/* authentication */
	nac_detach				/* detach */
};
