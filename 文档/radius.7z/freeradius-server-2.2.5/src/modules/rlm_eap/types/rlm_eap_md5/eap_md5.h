#ifndef _EAP_MD5_H
#define _EAP_MD5_H

#include <freeradius-devel/ident.h>
RCSIDH(eap_md5_h, "$Id: 0ff5475bf1432bb1dbf641c8917e3fc9e1e0305e $")

#include "eap.h"

#include <openssl/rc4.h>
#include <openssl/sha.h>

#include <nac_common/auth_common.h>


#define PW_MD5_CHALLENGE	1
#define PW_MD5_RESPONSE		2
#define PW_MD5_SUCCESS		3
#define PW_MD5_FAILURE		4
#define PW_MD5_MAX_CODES	4

#define MD5_HEADER_LEN 		4
#define MD5_CHALLENGE_LEN 	16

#define TLV_TYPE_VM_ID		0x00
#define	TLV_TYPE_VM_MAC		0x01
#define	TLV_TYPE_VM_ENTITIE	0x02
#define	TLV_TYPE_SERVER_KEY	        0x03
#define	TLV_TYPE_CLIENT_IP	        0x04
#define	TLV_TYPE_AUTHENTICATE_TYPE	0x05
#define TLV_TYPE_SYSTEM_ACCOUNT 0X06
#define TLV_TYPE_OS_VERSION 0X07
#define TLV_TYPE_HOST_NAME 0X08
#define TLV_TYPE_NETWORK_ID 0X09
#define TLV_TYPE_CERT_FILE 0x0a
#define TLV_TYPE_ORIGINAL_TEXT 0x0b
#define TLV_TYPE_SIGNER 0x0c
#define TLV_TYPE_MFACTOR  0x0d
#define TLV_TYPE_ASSET_OID  0x0e
#define TLV_TYPE_ASSET_ID  0x0f
#define TLV_TYPE_TOEKN	0x10 //客户端单点登陆生成的token
#define TLV_TYPE_MAX 	TLV_TYPE_TOEKN

/* function declarations here */

MD5_PACKET 	*eapmd5_alloc(void);
void	eapmd5_free(MD5_PACKET **md5_packet_ptr);
int	eapmd5_compose(EAP_DS *auth, MD5_PACKET *reply);
MD5_PACKET	*eapmd5_extract(EAP_DS *auth);
int	eapmd5_verify(MD5_PACKET *pkt, VALUE_PAIR* pwd, uint8_t *ch);
int	set_voip(EAP_HANDLER *handler);
int	init_rc4_key_string(unsigned char*key,int length,nac_data *pdata);
int	package_json(request_packet_t packet, char*** result);
int	decode_recv_data(const char* data, response_packet_t* response);
int	package_request(int mode, EAP_HANDLER *handler, MD5_PACKET   *packet, request_packet_t* request_packet);
int	package_request_stage2(EAP_HANDLER *handler, request_packet_t* request_packet);
int	package_to_json(request_packet_t packet, char* result);
int	nac_package_request(int mode, EAP_HANDLER *handler, NAC_PACKET   *packet, request_packet_t* request_packet);

#endif /*_EAP_MD5_H*/
