/*
 * rlm_eap_md5.c    Handles that are called from eap
 *
 * Version:     $Id: 76178fd5a993e2477b1e93a8759ae75c1d377300 $
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2001,2006  The FreeRADIUS server project
 * Copyright 2001  hereUare Communications, Inc. <raghud@hereuare.com>
 */

#include <freeradius-devel/ident.h>
RCSID("$Id: 76178fd5a993e2477b1e93a8759ae75c1d377300 $")

#include <freeradius-devel/autoconf.h>

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "eap_md5.h"
#include <nac_common/auth_common.h>
#include <sys/time.h>
#include <semaphore.h>

#include <freeradius-devel/rad_assert.h>
#include <rlm_auth_connection.h>
#include <auth_session.h>

#ifndef FREE_PTR
#define FREE_PTR(P) if(P) free(P); (P)=NULL;
#endif 

static rlm_auth_connection_t *auth_conn_inst = NULL;


extern  int nac_attach_ex_ex(CONF_SECTION *cs, void **instance, uint8_t code_type);

extern  int nac_initiate_ex(void *type_data, EAP_HANDLER *handler);

extern  int nac_authenticate_ex(void *type_arg, EAP_HANDLER *handler);

extern  int nac_detach_ex(void *arg);


/*
 *	Initiate the EAP-MD5 session by sending a challenge to the peer.
 */
static int md5_initiate(void *type_data, EAP_HANDLER *handler)
{
	return  nac_initiate_ex( type_data,  handler);
}

/*
 *	Authenticate a previously sent challenge.
 */
static int md5_authenticate(UNUSED void *arg, EAP_HANDLER *handler)
{
	session_handle_t *sess = NULL;
	
	if ( ((nac_data *)(handler->opaque))->flag == 1 ){
		return nac_authenticate_ex(arg,handler);
	}

	if (handler->eap_ds->response->type.data[0] == 0){
		((nac_data *)(handler->opaque))->flag = 1;
		return nac_authenticate_ex(arg,handler);
	}

	MD5_PACKET	*packet;
	MD5_PACKET	*reply;
	/*
	 *	Get the Cleartext-Password for this user.
	 */
	rad_assert(handler->request != NULL);
	rad_assert(handler->stage == AUTHENTICATE);

	/*
	 *	Extract the EAP-MD5 packet.
	 */
	if (!(packet = eapmd5_extract(handler->eap_ds)))
		return 0;

	/*
	 *	Create a reply, and initialize it.
	 */
	reply = eapmd5_alloc();
	if (!reply) {
		eapmd5_free(&packet);
		return 0;
	}
	reply->id = handler->eap_ds->request->id;
	reply->length = 0;

    if (g_nac_bypass) {
		reply->code = PW_MD5_SUCCESS;
        set_session_timeout(handler, 720000);
	    eapmd5_compose(handler->eap_ds, reply);
        return 1;
    }

	request_packet_t request_packet;
	memset(&request_packet, 0, sizeof(request_packet_t));
	package_request(MODE_MD5, handler, packet, &request_packet);

	char* send_buf  = (char*)malloc(4096*sizeof(char));
	memset(send_buf, 0, 4096);
	package_to_json(request_packet, send_buf);
	eapmd5_free(&packet);

	radlog(L_DBG, "[%s-%d-%s]: add session", __FILE__, __LINE__, __FUNCTION__);
    sess = auth_session_add(request_packet.session_id);
	if (!sess) {
		radlog(L_ERR, "[%s-%d-%s]: auth_session_add failed.", __FILE__, __LINE__, __FUNCTION__);
		reply->code = PW_MD5_FAILURE;
		goto fr;
	}
	if (!auth_conn_inst->send) {
		radlog(L_ERR, "[%s-%d-%s]: send func null", __FILE__, __LINE__, __FUNCTION__);
		reply->code = PW_MD5_FAILURE;
		goto fr;
	}
	int send_ret = auth_conn_inst->send(auth_conn_inst, send_buf, strlen(send_buf)+1);
	
	if (send_ret <0) {
		reply->code = PW_MD5_FAILURE;
		goto fr;
	}

	int timer = 0;
	while (!sess->resp_available) {
		timer++;
		usleep(1000*10);
		if (timer == 4000) {
			break;
		}
	}

	if (sess->resp_available == 0) {
		reply->code = PW_MD5_FAILURE;
		goto fr;
	}

	response_packet_t response;
	memcpy(&response, &(sess->response), sizeof(response_packet_t));
	if (response.result == 0) {
		//set vlan
		if ((response.vlan_id != NULL) && (strlen(response.vlan_id) > 0)) {
			set_vlan_id(handler, response.vlan_id);
		}
		if (response.device_type == 1) {

			VALUE_PAIR* vp = pairmake("Cisco-AVPair", "device-traffic-class=voice", T_OP_SET);
			pairadd(&handler->request->reply->vps, vp);

		}
		//set session timeout
		set_session_timeout(handler, response.session_timeout);		
        if ((handler->eap_type == PW_EAP_TNC) || (handler->eap_type == PW_EAP_ZONE)) {
		    setMppeAttribute(handler);
        }
		reply->code = PW_MD5_SUCCESS;
	}else{
		reply->code = PW_MD5_FAILURE;
	}

fr:
	FREE_PTR(send_buf);
	if (sess) {
		auth_session_del(sess);
	}

	/*
	 *	Compose the EAP-MD5 packet out of the data structure,
	 *	and free it.
	 */
	eapmd5_compose(handler->eap_ds, reply);

	return 1;

}

static int md5_detach(void *arg)
{
	//TODO call nac detach
	nac_detach_ex(arg);

	return 0;
}



static int md5_attach(CONF_SECTION *cs, void **instance)
{
	module_instance_t *modinst = NULL;
	//TODO call nac attach
	nac_attach_ex_ex(cs, instance, PW_EAP_MD5);
	modinst = find_module_instance(cf_section_find("modules"), "auth_connection", 1);
	if (!modinst) {
        radlog(L_ERR, "[%s-%d-%s]: auth_connection module load failed",  __FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
	auth_conn_inst = (rlm_auth_connection_t *) modinst->insthandle;
	return 0;
}


/*
 *	The module name should be the only globally exported symbol.
 *	That is, everything else should be 'static'.
 */
EAP_TYPE rlm_eap_md5 = {
	"eap_md5",
	md5_attach,				/* attach */
	md5_initiate,			/* Start the initial request */
	NULL,				/* authorization */
	md5_authenticate,		/* authentication */
	md5_detach				/* detach */
};
