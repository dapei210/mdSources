#ifndef _EAP_NAC_H
#define _EAP_NAC_H

#include <freeradius-devel/ident.h>
//RCSIDH(eap_md5_h, "$Id: fdbeddeb493af5c6f9b9ab47f1dbc734463baf1d $")
RCSIDH(eap_nac_h, "$Id: fdbeddeb493af5c6f9b9ab47f1dbc734463baf1d $")

#include <openssl/rc4.h>
#include <openssl/sha.h>
#include "eap.h"

#define PW_NAC_CHALLENGE	1
#define PW_NAC_RESPONSE		2
#define PW_NAC_SUCCESS		3
#define PW_NAC_FAILURE		4
#define PW_NAC_MAX_CODES	4

#define NAC_HEADER_LEN 		4
#define NAC_CHALLENGE_LEN 	16

#define NAC_DATA_LEN    1024
#define NAC_INCLUDE_LEN      4		/*包含长度*/
#define NAC_MORE		     8		/*分片标志*/
#define NAC_ACK				 16		/*响应标志*/
#define NAC_ENCRYPT			 32		/*加密标志*/

#define NAC_MAX_DATA		102400   /*最多10M数据*/
#define NAC_ACK_LEN			3	
#define NAC_ACK_DATA		"200"

#define VLAN_ISOLATE	0	/*隔离*/
#define VLAN_ACCESS		1	/*准入*/


/*
 ****
 * EAP - MD5 doesnot specify code, id & length but chap specifies them,
 *	for generalization purpose, complete header should be sent
 *	and not just value_size, value and name.
 *	future implementation.
 *
 *	Huh? What does that mean?
 */


/* eap packet structure */
typedef struct nac_packet_t {
/*
	uint8_t	code;
	uint8_t	id;
	uint16_t	length;
*/
	uint8_t	value_size;
	uint8_t	value_name[1];
} nac_packet_t;

/* function declarations here */

NAC_PACKET 	*eapnac_alloc(void);
void 		eapnac_free(NAC_PACKET **md5_packet_ptr);

int 		eapnac_compose(EAP_DS *auth, NAC_PACKET *reply, uint8_t code_type);
int 		eapnac_compose_appdata(EAP_DS *auth, NAC_PACKET *reply, uint8_t code_type);
NAC_PACKET 	*eapnac_extract(EAP_DS *auth, int code_type);
int 		eapnac_verify(NAC_PACKET *pkt, VALUE_PAIR* pwd, uint8_t *ch);
void  nac_data_free(void *pdata);
int   nac_policy_load(nac_data **pdata,char*policy_name);
int   nac_comm_load(char **out,int *length,char*file_name);
int   eapnac_get_mppe_key(uint8_t *challenge,char send_key[],char recv_key[]);

/*
static int nac_attach_ex(CONF_SECTION *cs, void **instance, uint8_t code_type);

static int nac_initiate(void *type_data, EAP_HANDLER *handler);

static int nac_authenticate(void *type_arg, EAP_HANDLER *handler);
	

static int nac_detach(void *arg);
*/

#endif /*_EAP_NAC_H*/
