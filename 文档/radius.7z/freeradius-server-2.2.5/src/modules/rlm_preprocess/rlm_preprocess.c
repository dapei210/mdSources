/*
 * rlm_preprocess.c
 *		Contains the functions for the "huntgroups" and "hints"
 *		files.
 *
 * Version:     $Id: f1d9c10683b3120f04c6e4ee13d98d9b1910c92f $
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2006  The FreeRADIUS server project
 * Copyright 2000  Alan DeKok <aland@ox.org>
 */

#include	<freeradius-devel/ident.h>
RCSID("$Id: f1d9c10683b3120f04c6e4ee13d98d9b1910c92f $")

#include	<freeradius-devel/radiusd.h>
#include	<freeradius-devel/modules.h>
#include	<freeradius-devel/rad_assert.h>
#include    <openssl/rc4.h>
#include	<ctype.h>

typedef struct rlm_preprocess_t {
	char		*huntgroup_file;
	char		*hints_file;
	PAIR_LIST	*huntgroups;
	PAIR_LIST	*hints;
	int		with_ascend_hack;
	int		ascend_channels_per_line;
	int		with_ntdomain_hack;
	int		with_specialix_jetstream_hack;
	int		with_cisco_vsa_hack;
	int		with_alvarion_vsa_hack;
    char    *nac_proxy_suffix;
} rlm_preprocess_t;

static const CONF_PARSER module_config[] = {
	{ "huntgroups",			PW_TYPE_FILENAME,
	  offsetof(rlm_preprocess_t,huntgroup_file), NULL, NULL },
	{ "hints",			PW_TYPE_FILENAME,
	  offsetof(rlm_preprocess_t,hints_file), NULL, NULL },
	{ "with_ascend_hack",		PW_TYPE_BOOLEAN,
	  offsetof(rlm_preprocess_t,with_ascend_hack), NULL, "no" },
	{ "ascend_channels_per_line",   PW_TYPE_INTEGER,
	  offsetof(rlm_preprocess_t,ascend_channels_per_line), NULL, "23" },

	{ "with_ntdomain_hack",		PW_TYPE_BOOLEAN,
	  offsetof(rlm_preprocess_t,with_ntdomain_hack), NULL, "no" },
	{ "with_specialix_jetstream_hack",  PW_TYPE_BOOLEAN,
	  offsetof(rlm_preprocess_t,with_specialix_jetstream_hack), NULL,
	  "no" },
	{ "with_cisco_vsa_hack",        PW_TYPE_BOOLEAN,
	  offsetof(rlm_preprocess_t,with_cisco_vsa_hack), NULL, "no" },
	{ "with_alvarion_vsa_hack",        PW_TYPE_BOOLEAN,
	  offsetof(rlm_preprocess_t,with_alvarion_vsa_hack), NULL, "no" },
    { "nac_proxy_suffix",        PW_TYPE_STRING_PTR,
      offsetof(rlm_preprocess_t,nac_proxy_suffix), NULL, NULL },
	{ NULL, -1, 0, NULL, NULL }
};

/*
 *     See if a VALUE_PAIR list contains Fall-Through = Yes
 */
static int fallthrough(VALUE_PAIR *vp)
{
	VALUE_PAIR *tmp;
	tmp = pairfind(vp, PW_FALL_THROUGH);

	return tmp ? tmp->lvalue : 0;
}

/*
 *	dgreer --
 *	This hack changes Ascend's wierd port numberings
 *	to standard 0-??? port numbers so that the "+" works
 *	for IP address assignments.
 */
static void ascend_nasport_hack(VALUE_PAIR *nas_port, int channels_per_line)
{
	int service;
	int line;
	int channel;

	if (!nas_port) {
		return;
	}

	if (nas_port->vp_integer > 9999) {
		service = nas_port->vp_integer/10000; /* 1=digital 2=analog */
		line = (nas_port->vp_integer - (10000 * service)) / 100;
		channel = nas_port->vp_integer-((10000 * service)+(100 * line));
		nas_port->vp_integer =
			(channel - 1) + (line - 1) * channels_per_line;
	}
}

/*
 *	ThomasJ --
 *	This hack strips out Cisco's VSA duplicities in lines
 *	(Cisco not implemented VSA's in standard way.
 *
 *	Cisco sends it's VSA attributes with the attribute name *again*
 *	in the string, like:  H323-Attribute = "h323-attribute=value".
 *	This sort of behaviour is nonsense.
 */
static void cisco_vsa_hack(VALUE_PAIR *vp)
{
	int		vendorcode;
	char		*ptr;
	char		newattr[MAX_STRING_LEN];

	for ( ; vp != NULL; vp = vp->next) {
		vendorcode = VENDOR(vp->attribute);
		if (!((vendorcode == 9) || (vendorcode == 6618))) continue; /* not a Cisco or Quintum VSA, continue */

		if (vp->type != PW_TYPE_STRING) continue;

		/*
		 *  No weird packing.  Ignore it.
		 */
		ptr = strchr(vp->vp_strvalue, '='); /* find an '=' */
		if (!ptr) continue;

		/*
		 *	Cisco-AVPair's get packed as:
		 *
		 *	Cisco-AVPair = "h323-foo-bar = baz"
		 *	Cisco-AVPair = "h323-foo-bar=baz"
		 *
		 *	which makes sense only if you're a lunatic.
		 *	This code looks for the attribute named inside
		 *	of the string, and if it exists, adds it as a new
		 *	attribute.
		 */
		if ((vp->attribute & 0xffff) == 1) {
			const char *p;
			DICT_ATTR	*dattr;

			p = vp->vp_strvalue;
			gettoken(&p, newattr, sizeof(newattr));

			if ((dattr = dict_attrbyname(newattr)) != NULL) {
				VALUE_PAIR *newvp;

				/*
				 *  Make a new attribute.
				 */
				newvp = pairmake(newattr, ptr + 1, T_OP_EQ);
				if (newvp) {
					pairadd(&vp, newvp);
				}
			}
		} else {	/* h322-foo-bar = "h323-foo-bar = baz" */
			/*
			 *	We strip out the duplicity from the
			 *	value field, we use only the value on
			 *	the right side of the '=' character.
			 */
			strlcpy(newattr, ptr + 1, sizeof(newattr));
			strlcpy((char *)vp->vp_strvalue, newattr,
				sizeof(vp->vp_strvalue));
			vp->length = strlen((char *)vp->vp_strvalue);
		}
	}
}


/*
 *	Don't even ask what this is doing...
 */
static void alvarion_vsa_hack(VALUE_PAIR *vp)
{
	int		vendorcode;
	int		number = 1;

	for ( ; vp != NULL; vp = vp->next) {
		DICT_ATTR *da;

		vendorcode = VENDOR(vp->attribute);
		if (vendorcode != 12394) continue;
		if (vp->type != PW_TYPE_STRING) continue;

		da = dict_attrbyvalue(number | (12394 << 16));
		if (!da) continue;

		vp->attribute = da->attr;
		vp->name = da->name;

		number++;
	}
}

/*
 *	Mangle username if needed, IN PLACE.
 */
static void rad_mangle(rlm_preprocess_t *data, REQUEST *request)
{
	int		num_proxy_state;
	VALUE_PAIR	*namepair;
	VALUE_PAIR	*request_pairs;
	VALUE_PAIR	*tmp;

	/*
	 *	Get the username from the request
	 *	If it isn't there, then we can't mangle the request.
	 */
	request_pairs = request->packet->vps;
	namepair = pairfind(request_pairs, PW_USER_NAME);
	if ((namepair == NULL) ||
	    (namepair->length <= 0)) {
	  return;
	}

	if (data->with_ntdomain_hack) {
		char		*ptr;
		char		newname[MAX_STRING_LEN];

		/*
		 *	Windows NT machines often authenticate themselves as
		 *	NT_DOMAIN\username. Try to be smart about this.
		 *
		 *	FIXME: should we handle this as a REALM ?
		 */
		if ((ptr = strchr(namepair->vp_strvalue, '\\')) != NULL) {
			strlcpy(newname, ptr + 1, sizeof(newname));
			/* Same size */
			strcpy(namepair->vp_strvalue, newname);
			namepair->length = strlen(newname);
		}
	}

	if (data->with_specialix_jetstream_hack) {
		char		*ptr;

		/*
		 *	Specialix Jetstream 8500 24 port access server.
		 *	If the user name is 10 characters or longer, a "/"
		 *	and the excess characters after the 10th are
		 *	appended to the user name.
		 *
		 *	Reported by Lucas Heise <root@laonet.net>
		 */
		if ((strlen((char *)namepair->vp_strvalue) > 10) &&
		    (namepair->vp_strvalue[10] == '/')) {
			for (ptr = (char *)namepair->vp_strvalue + 11; *ptr; ptr++)
				*(ptr - 1) = *ptr;
			*(ptr - 1) = 0;
			namepair->length = strlen((char *)namepair->vp_strvalue);
		}
	}

	/*
	 *	Small check: if Framed-Protocol present but Service-Type
	 *	is missing, add Service-Type = Framed-User.
	 */
	if (pairfind(request_pairs, PW_FRAMED_PROTOCOL) != NULL &&
	    pairfind(request_pairs, PW_SERVICE_TYPE) == NULL) {
		tmp = radius_paircreate(request, &request->packet->vps,
					PW_SERVICE_TYPE, PW_TYPE_INTEGER);
		tmp->vp_integer = PW_FRAMED_USER;
	}

	num_proxy_state = 0;
	for (tmp = request->packet->vps; tmp != NULL; tmp = tmp->next) {
		if (tmp->vendor != 0) continue;
		if (tmp->attribute != PW_PROXY_STATE) continue;

		num_proxy_state++;
	}

	if (num_proxy_state > 10) {
		DEBUG("WARNING: There are more than 10 Proxy-State attributes in the request.");
		DEBUG("WARNING: You have likely configured an infinite proxy loop.");
	}
}

/*
 *	Compare the request with the "reply" part in the
 *	huntgroup, which normally only contains username or group.
 *	At least one of the "reply" items has to match.
 */
static int hunt_paircmp(REQUEST *req, VALUE_PAIR *request, VALUE_PAIR *check)
{
	VALUE_PAIR	*check_item = check;
	VALUE_PAIR	*tmp;
	int		result = -1;

	if (check == NULL) return 0;

	while (result != 0 && check_item != NULL) {

		tmp = check_item->next;
		check_item->next = NULL;

		result = paircompare(req, request, check_item, NULL);

		check_item->next = tmp;
		check_item = check_item->next;
	}

	return result;
}


/*
 *	Add hints to the info sent by the terminal server
 *	based on the pattern of the username, and other attributes.
 */
static int hints_setup(PAIR_LIST *hints, REQUEST *request)
{
	char		*name;
	VALUE_PAIR	*add;
	VALUE_PAIR	*tmp;
	PAIR_LIST	*i;
	VALUE_PAIR *request_pairs;
	int		updated = 0, ft;


	request_pairs = request->packet->vps;

	if (hints == NULL || request_pairs == NULL)
		return RLM_MODULE_NOOP;

	/*
	 *	Check for valid input, zero length names not permitted
	 */
	if ((tmp = pairfind(request_pairs, PW_USER_NAME)) == NULL)
		name = NULL;
	else
		name = (char *)tmp->vp_strvalue;

	if (name == NULL || name[0] == 0)
		/*
		 *	No name, nothing to do.
		 */
		return RLM_MODULE_NOOP;

	for (i = hints; i; i = i->next) {
		/*
		 *	Use "paircompare", which is a little more general...
		 */
		if (((strcmp(i->name, "DEFAULT") == 0) ||
		     (strcmp(i->name, name) == 0)) &&
		    (paircompare(request, request_pairs, i->check, NULL) == 0)) {
			RDEBUG2("  hints: Matched %s at %d",
			       i->name, i->lineno);
			/*
			 *	Now add all attributes to the request list,
			 *	except PW_STRIP_USER_NAME and PW_FALL_THROUGH
			 *	and xlat them.
			 */
			add = paircopy(i->reply);
			ft = fallthrough(add);
			pairdelete(&add, PW_STRIP_USER_NAME);
			pairdelete(&add, PW_FALL_THROUGH);
			pairxlatmove(request, &request->packet->vps, &add);
			pairfree(&add);
			updated = 1;
			if (!ft) break;
		}
	}

	if (updated == 0) return RLM_MODULE_NOOP;

	return RLM_MODULE_UPDATED;
}

/*
 *	See if we have access to the huntgroup.
 */
static int huntgroup_access(REQUEST *request, PAIR_LIST *huntgroups)
{
	PAIR_LIST	*i;
	int		r = RLM_MODULE_OK;
	VALUE_PAIR	*request_pairs = request->packet->vps;

	/*
	 *	We're not controlling access by huntgroups:
	 *	Allow them in.
	 */
	if (huntgroups == NULL)
		return RLM_MODULE_OK;

	for(i = huntgroups; i; i = i->next) {
		/*
		 *	See if this entry matches.
		 */
		if (paircompare(request, request_pairs, i->check, NULL) != 0)
			continue;

		/*
		 *	Now check for access.
		 */
		r = RLM_MODULE_REJECT;
		if (hunt_paircmp(request, request_pairs, i->reply) == 0) {
			VALUE_PAIR *vp;

			/*
			 *  We've matched the huntgroup, so add it in
			 *  to the list of request pairs.
			 */
			vp = pairfind(request_pairs, PW_HUNTGROUP_NAME);
			if (!vp) {
				vp = radius_paircreate(request,
						       &request->packet->vps,
						       PW_HUNTGROUP_NAME,
						       PW_TYPE_STRING);
				strlcpy(vp->vp_strvalue, i->name,
					sizeof(vp->vp_strvalue));
				vp->length = strlen(vp->vp_strvalue);
			}
			r = RLM_MODULE_OK;
		}
		break;
	}

	return r;
}

#define MAX_LINE  76 /* size of encoded lines */

static char basis_64[] =
   "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

#define XX      255	/* illegal base64 char */
#define EQ      254	/* padding */
#define INVALID XX

static unsigned char index_64[256] = {
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,62, XX,XX,XX,63,
    52,53,54,55, 56,57,58,59, 60,61,XX,XX, XX,EQ,XX,XX,
    XX, 0, 1, 2,  3, 4, 5, 6,  7, 8, 9,10, 11,12,13,14,
    15,16,17,18, 19,20,21,22, 23,24,25,XX, XX,XX,XX,XX,
    XX,26,27,28, 29,30,31,32, 33,34,35,36, 37,38,39,40,
    41,42,43,44, 45,46,47,48, 49,50,51,XX, XX,XX,XX,XX,

    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
    XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX, XX,XX,XX,XX,
};

// Always NUL terminates the result
// Returns the length of the result (not counting the NUL termination)
// *result must be freed
size_t
decode_base64(
    /*in*/  char* str, 
    /*out*/ unsigned char**result)
{
    size_t               len = strlen(str);
    unsigned char*       r;
    size_t               rlen = ((len * 3) / 4) + 1; // always enough
    char*                end = str + len;
    size_t                  rindex = 0;
    unsigned char        c[4];

    r = malloc(rlen);
    while (str < end) 
    {
	int i = 0;
	do {
	    unsigned char uc = index_64[*str++];
	    if (uc != INVALID)
		c[i++] = uc;

	    if (str == end) {
		if (i < 4) {
		    // Premature end of base64 data if i
		    if (i < 2) goto finished;
		    if (i == 2) c[2] = EQ;
		    c[3] = EQ;
		}
		break;
	    }
	} while (i < 4);
	
	if (c[0] == EQ || c[1] == EQ) {
	    // Premature padding of base64 data
	    break;
	}
	/* printf("c0=%d,c1=%d,c2=%d,c3=%d\n", c[0],c[1],c[2],c[3]);/**/
	
	r[rindex++] = (c[0] << 2) | ((c[1] & 0x30) >> 4);
	
	if (c[2] == EQ)
	    break;
	r[rindex++] = ((c[1] & 0x0F) << 4) | ((c[2] & 0x3C) >> 2);
	
	if (c[3] == EQ)
	    break;
	r[rindex++] = ((c[2] & 0x03) << 6) | c[3];
    }
    
 finished:
    r[rindex] = '\0'; // Make sure its null terminated
    *result = r;
    return rindex;
}
/*
 *	If the NAS wasn't smart enought to add a NAS-IP-Address
 *	to the request, then add it ourselves.
 */
static int add_nas_attr(rlm_preprocess_t *data, REQUEST *request)
{
	VALUE_PAIR *nas;
	int count = 0;
	nas = pairfind(request->packet->vps, PW_USER_NAME);
	if(nas) {
		char *pvalue=nas->vp_strvalue;
		char *sub = NULL;
        if ((data != NULL) && (data->nac_proxy_suffix != NULL) && (strlen(data->nac_proxy_suffix) > 0) && 
                            ((sub = strcasestr(pvalue, data->nac_proxy_suffix)) != NULL)) {
			*sub = '@';
			radlog(L_DBG, "nac-rlm_process: found %s, replace it with -> %s", data->nac_proxy_suffix, nas->vp_strvalue);
			VALUE_PAIR *new_pair = pairmake("User-Name", nas->vp_strvalue, T_OP_EQ);
			pairreplace(&(request->packet->vps),new_pair);
			request->username=new_pair;
		}
		while (*pvalue) {
			if (*pvalue == '|') {
				count++;
			}
			pvalue++;
		}
	}
	/* tian ji app format: ver|encrypted|username, where encrypted=base64(rc4(secur_check and timestamp)) */
	radlog(L_DBG, "[%s-%d-%s]-nac: preprocess\n", __FILE__, __LINE__, __FUNCTION__);
	if (count == 2) {
		radlog(L_DBG, "[%s-%d-%s]-nac: is app client\n", __FILE__, __LINE__, __FUNCTION__);
		nas = pairfind(request->packet->vps, PW_USER_NAME);
		if(nas) { 
			char *pvalue=nas->vp_strvalue;
			char *enctypted = NULL;
			char *username = NULL;
			if (strncmp(pvalue, "1|", 2) == 0) {
				enctypted = strchr(pvalue, '|');
				if (enctypted) {
					*enctypted = 0;
					enctypted++;
					username = strchr(enctypted, '|');
					if (username) {
						char *out = NULL;
						size_t out_len = 0;
						char decrypted[256] = {0};
						*username = 0;
						username++;
						radlog(L_DBG, "[%s-%d-%s]-nac: username=%s, enctypted=%s\n", __FILE__, __LINE__, __FUNCTION__, username, enctypted);
	                    out_len = decode_base64(enctypted, &out);
						radlog(L_DBG, "[%s-%d-%s]-nac: base64 decode:out=%s,out_len=%d,inlen=%d, strlen=%d\n", __FILE__, __LINE__, 
	                                        __FUNCTION__, out, out_len, strlen(enctypted), strlen(out));
						if (out_len > 0) {
							radlog(L_DBG, "[%s-%d-%s]-nac: base64 decode success:out=%s,out_len=%d,inlen=%d, strlen=%d\n", __FILE__, __LINE__, 
	                                        __FUNCTION__, out, out_len, strlen(enctypted), strlen(out));
	                        RC4_KEY rc4_key;
	                        RC4_set_key(&rc4_key, strlen(username), username); 
							RC4(&rc4_key, strlen(out), out, decrypted);
							radlog(L_DBG, "[%s-%d-%s]-nac: decrypted_pwd=%s\n", __FILE__, __LINE__, __FUNCTION__, decrypted);
							pvalue = strchr(decrypted, '|');
							if (pvalue) {
								int securiy_code = 0;
								*pvalue = 0;
								radlog(L_DBG, "[%s-%d-%s]-nac: check_code=%s\n", __FILE__, __LINE__, __FUNCTION__, decrypted);
								securiy_code = atoi(decrypted);
								if (securiy_code == 2) {
									radlog(L_ERR, "APP securiyt check failed\n");
									return -1;
								}
							}
								
							free(out);
						}
	                    else {
						    radlog(L_ERR, "base64 decode fail\n");
	                    }
						VALUE_PAIR *new_pair=pairmake("User-Name", username, T_OP_EQ);
						pairreplace(&(request->packet->vps), new_pair);
						request->username=new_pair;

#if 0
						vp = pairmake("Module-Failure-Message", passwd, T_OP_EQ);
						if (vp) {
							radlog(L_DBG, "[%s-%d-%s]-nac: add NAC-APP-PWD success\n", __FILE__, __LINE__, __FUNCTION__);
							pairadd(&request->packet->vps, vp);
						}
						else {
							radlog(L_DBG, "[%s-%d-%s]-nac: add NAC-APP-PWD fail\n", __FILE__, __LINE__, __FUNCTION__);
						}
#endif
					}
				}
			} else { 
				radlog(L_DBG, "[%s-%d-%s]-nac: username=%s\n", __FILE__, __LINE__, __FUNCTION__, pvalue);
			}
		}
	}

	switch (request->packet->src_ipaddr.af) {
	case AF_INET:
		nas = pairfind(request->packet->vps, PW_NAS_IP_ADDRESS);
		if (!nas) {
			nas = radius_paircreate(request, &request->packet->vps,
						PW_NAS_IP_ADDRESS,
						PW_TYPE_IPADDR);
			nas->vp_ipaddr = request->packet->src_ipaddr.ipaddr.ip4addr.s_addr;
		}
		break;

	case AF_INET6:
		nas = pairfind(request->packet->vps, PW_NAS_IPV6_ADDRESS);
		if (!nas) {
			nas = radius_paircreate(request, &request->packet->vps,
						PW_NAS_IPV6_ADDRESS,
						PW_TYPE_IPV6ADDR);
			memcpy(nas->vp_strvalue,
			       &request->packet->src_ipaddr.ipaddr,
			       sizeof(request->packet->src_ipaddr.ipaddr));
		}
		break;

	default:
		radlog(L_ERR, "Unknown address family for packet");
		return -1;
	}

	return 0;
}


/*
 *	Initialize.
 */
static int preprocess_instantiate(CONF_SECTION *conf, void **instance)
{
	int	rcode;
	rlm_preprocess_t *data;

	/*
	 *	Allocate room to put the module's instantiation data.
	 */
	data = (rlm_preprocess_t *) rad_malloc(sizeof(*data));
	memset(data, 0, sizeof(*data));

	/*
	 *	Read this modules configuration data.
	 */
        if (cf_section_parse(conf, data, module_config) < 0) {
		free(data);
                return -1;
        }

	data->huntgroups = NULL;
	data->hints = NULL;

	/*
	 *	Read the huntgroups file.
	 */
	if (data->huntgroup_file) {
		rcode = pairlist_read(data->huntgroup_file,
				      &(data->huntgroups), 0);
		if (rcode < 0) {
			radlog(L_ERR|L_CONS, "rlm_preprocess: Error reading %s",
			       data->huntgroup_file);
			return -1;
		}
	}

	/*
	 *	Read the hints file.
	 */
	if (data->hints_file) {
		rcode = pairlist_read(data->hints_file, &(data->hints), 0);
		if (rcode < 0) {
			radlog(L_ERR|L_CONS, "rlm_preprocess: Error reading %s",
			       data->hints_file);
			return -1;
		}
	}

    if (data->nac_proxy_suffix) {
        radlog(L_DBG, "rlm_preprocess: nac proxy suffix = %s",
                   data->nac_proxy_suffix);
    }
	/*
	 *	Save the instantiation data for later.
	 */
	*instance = data;

	return 0;
}

/*
 *	Preprocess a request.
 */
static int preprocess_authorize(void *instance, REQUEST *request)
{
	int r;
	rlm_preprocess_t *data = (rlm_preprocess_t *) instance;

	/*
	 *	Mangle the username, to get rid of stupid implementation
	 *	bugs.
	 */
	rad_mangle(data, request);

	if (data->with_ascend_hack) {
		/*
		 *	If we're using Ascend systems, hack the NAS-Port-Id
		 *	in place, to go from Ascend's weird values to something
		 *	approaching rationality.
		 */
		ascend_nasport_hack(pairfind(request->packet->vps,
					     PW_NAS_PORT),
				    data->ascend_channels_per_line);
	}

	if (data->with_cisco_vsa_hack) {
	 	/*
		 *	We need to run this hack because the h323-conf-id
		 *	attribute should be used.
		 */
		cisco_vsa_hack(request->packet->vps);
	}

	if (data->with_alvarion_vsa_hack) {
	 	/*
		 *	We need to run this hack because the Alvarion
		 *	people are crazy.
		 */
		alvarion_vsa_hack(request->packet->vps);
	}

	/*
	 *	Note that we add the Request-Src-IP-Address to the request
	 *	structure BEFORE checking huntgroup access.  This allows
	 *	the Request-Src-IP-Address to be used for huntgroup
	 *	comparisons.
	 */
	if (add_nas_attr(data, request) < 0) {
		return RLM_MODULE_FAIL;
	}

	hints_setup(data->hints, request);

	/*
	 *      If there is a PW_CHAP_PASSWORD attribute but there
	 *      is PW_CHAP_CHALLENGE we need to add it so that other
	 *	modules can use it as a normal attribute.
	 */
	if (pairfind(request->packet->vps, PW_CHAP_PASSWORD) &&
	    pairfind(request->packet->vps, PW_CHAP_CHALLENGE) == NULL) {
		VALUE_PAIR *vp;

		vp = radius_paircreate(request, &request->packet->vps,
				       PW_CHAP_CHALLENGE, PW_TYPE_OCTETS);
		vp->length = AUTH_VECTOR_LEN;
		memcpy(vp->vp_strvalue, request->packet->vector, AUTH_VECTOR_LEN);
	}

	if ((r = huntgroup_access(request,
				  data->huntgroups)) != RLM_MODULE_OK) {
		char buf[1024];
		radlog_request(L_AUTH, 0, request, "No huntgroup access: [%s] (%s)",
		       request->username ? request->username->vp_strvalue : "<NO User-Name>",
		       auth_name(buf, sizeof(buf), request, 1));
		return r;
	}

	return RLM_MODULE_OK; /* Meaning: try next authorization module */
}

/*
 *	Preprocess a request before accounting
 */
static int preprocess_preaccounting(void *instance, REQUEST *request)
{
	int r;
	rlm_preprocess_t *data = (rlm_preprocess_t *) instance;

	/*
	 *  Ensure that we have the SAME user name for both
	 *  authentication && accounting.
	 */
	rad_mangle(data, request);

	if (data->with_cisco_vsa_hack) {
	 	/*
		 *	We need to run this hack because the h323-conf-id
		 *	attribute should be used.
		 */
		cisco_vsa_hack(request->packet->vps);
	}

	if (data->with_alvarion_vsa_hack) {
	 	/*
		 *	We need to run this hack because the Alvarion
		 *	people are crazy.
		 */
		alvarion_vsa_hack(request->packet->vps);
	}

	/*
	 *  Ensure that we log the NAS IP Address in the packet.
	 */
	if (add_nas_attr(data, request) < 0) {
		return RLM_MODULE_FAIL;
	}

	hints_setup(data->hints, request);

	if ((r = huntgroup_access(request,
				  data->huntgroups)) != RLM_MODULE_OK) {
		char buf[1024];
		radlog_request(L_INFO, 0, request, "No huntgroup access: [%s] (%s)",
		       request->username ? request->username->vp_strvalue : "<NO User-Name>",
		       auth_name(buf, sizeof(buf), request, 1));
		return r;
	}

	return r;
}

/*
 *      Clean up the module's instance.
 */
static int preprocess_detach(void *instance)
{
	rlm_preprocess_t *data = (rlm_preprocess_t *) instance;

	pairlist_free(&(data->huntgroups));
	pairlist_free(&(data->hints));

	free(data);

	return 0;
}

/* globally exported name */
module_t rlm_preprocess = {
	RLM_MODULE_INIT,
	"preprocess",
	RLM_TYPE_CHECK_CONFIG_SAFE,   	/* type */
	preprocess_instantiate,	/* instantiation */
	preprocess_detach,	/* detach */
	{
		NULL,			/* authentication */
		preprocess_authorize,	/* authorization */
		preprocess_preaccounting, /* pre-accounting */
		NULL,			/* accounting */
		NULL,			/* checksimul */
		NULL,			/* pre-proxy */
		NULL,			/* post-proxy */
		NULL			/* post-auth */
	},
};

