/*
 * session.h: nac session manager
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2006  The FreeRADIUS server project
 */
#ifndef AUTH_SESSION_H
#define AUTH_SESSION_H

#include <freeradius-devel/ident.h>
RCSIDH(rlm_auth_session_h, "$Id: 245b341f72987e48d965044b73db4f33c1f0716e $")

#include <freeradius-devel/radiusd.h>
#include <freeradius-devel/modules.h>
#include <freeradius-devel/modpriv.h>
#include <nac_common/auth_common.h>
#include <nacstd/nac_rbtree.h>

#define AUTH_SESSION_ID_LENGTH  37

typedef struct session_handle_s {
    char session_id[AUTH_SESSION_ID_LENGTH];
    int resp_available;
    response_packet_t response;
} session_handle_t;


void session_handle_init(session_handle_t* sess, char* session_id);
int session_handle_cmp(const void* pdata1, const void* pdata2);
int session_handle_dup(void* new, void* old);
void session_handle_free(void* pdata);
int auth_session_init(void);
int auth_session_destroy(void);
session_handle_t *auth_session_add(char *session_id);
int auth_session_del(session_handle_t *sess);
int auth_session_update(session_handle_t *new_sess);
void dump_session_tree(void);

#endif
