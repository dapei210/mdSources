/*
 * rlm_auth_connection.c: create and maintain a conntion pool to auth_center.
 * The motivation of this module is to separate I/O ops from eap/pap/.. authentication layer.
 * Add "auth_connection" into radiusd.conf before using this module.
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2006  The FreeRADIUS server project
 */

#include <freeradius-devel/ident.h>
RCSID("$Id: a0a0008b90fa089c89b6ea6190ffe166e9e5f472 $")

#include <freeradius-devel/radiusd.h>
#include <freeradius-devel/modules.h>

#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/epoll.h>
#include <pthread.h>
#include <netinet/tcp.h>
#include <nacstd/c_json.h>
#include "rlm_auth_connection.h"
#include "auth_session.h"


static const CONF_PARSER module_config[] = {
	{ "hostname", PW_TYPE_STRING_PTR, offsetof(rlm_auth_connection_t, hostname), NULL, "127.0.0.1"},
	{ "port", PW_TYPE_INTEGER, offsetof(rlm_auth_connection_t, port), NULL, "1100"},
	{ "num_connections",  PW_TYPE_INTEGER, offsetof(rlm_auth_connection_t, num_connections), NULL, "2"},
	{ NULL, -1, 0, NULL, NULL }    /* end the list */
};


static int auth_connection_detach(void *instance);
static void *auth_connection_receiver(void *arg);
static int parse_data(const char *buf, size_t len);
static int auth_send(void *instance, const void *buf, size_t len);
static int socket_init(const char *host, int port);

//#define TEST_AUTH_CONNECTION 1
#ifdef TEST_AUTH_CONNECTION
static void *run_test(void *arg);
#endif



/* epoll event handler */
static int epoll_add_event(int epfd, auth_conn_t *conn, int event)
{
	struct epoll_event ev;

	ev.events = event;
	ev.data.ptr = conn;
	return epoll_ctl(epfd, EPOLL_CTL_ADD, conn->sockfd, &ev);
}

static int epoll_del_event(int epfd, auth_conn_t *conn)
{
	return epoll_ctl(epfd, EPOLL_CTL_DEL, conn->sockfd, NULL);
}


static int epoll_mod_event(int epfd, auth_conn_t *conn, int event)
{
	struct epoll_event ev;

	ev.events = event;
	ev.data.ptr = conn;
	return epoll_ctl(epfd, EPOLL_CTL_MOD, conn->sockfd, &ev);
}


void epoll_handle_read(rlm_auth_connection_t *inst, auth_conn_t *conn)
{
	int nread;

	memset(conn->rbuf, 0, sizeof(conn->rbuf)); 
	nread = recv(conn->sockfd, conn->rbuf, READ_BUF_SIZE-1, 0);
	if (nread > 0) {
		parse_data(conn->rbuf, nread);
	}
	else if (nread <= 0) {
		/* peer close conn, reconnect */
		radlog(L_ERR, "[%s-%d-%s]: connection %d nread=%d", __FILE__, __LINE__, __FUNCTION__,conn->id, nread);
		if (pthread_mutex_lock(&conn->lock) != 0) {
			radlog(L_ERR, "[%s-%d-%s]: pthread_mutex_lock failed", __FILE__, __LINE__, __FUNCTION__);
			return;
		}
		if (conn->sockfd < 0) {
			/* it may be closed by auth_send already */
			pthread_mutex_unlock(&conn->lock);
			return;
		}
		epoll_del_event(inst->epoll_fd, conn);
		close(conn->sockfd);
		conn->sockfd = socket_init(inst->hostname, inst->port);
		if (conn->sockfd < 0) {
			pthread_mutex_unlock(&conn->lock);
			radlog(L_ERR, "[%s-%d-%s]: conn->id=%d reconnect failed", __FILE__, __LINE__, __FUNCTION__,conn->id);
			return;
		}
		if (epoll_add_event(inst->epoll_fd, conn, EPOLLIN) < 0) {
			radlog(L_ERR, "[%s-%d-%s]: conn->id=%d epoll_add_event failed (%s)", __FILE__, __LINE__, __FUNCTION__,conn->id, strerror(errno));
			close(conn->sockfd);
			conn->sockfd = -1;
		}
		pthread_mutex_unlock(&conn->lock);
	}
}


void epoll_handle_events(rlm_auth_connection_t *inst, struct epoll_event *events, int num)
{
	auth_conn_t *conn;
	int i;

	for (i = 0; i < num; i++) {
		conn = (auth_conn_t *)events[i].data.ptr;
		if (!conn) {
			radlog(L_ERR, "[%s-%d-%s]:epoll_handle_events: socket error (%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
			continue;
		}
		if (events[i].events & (EPOLLHUP | EPOLLERR)) {
			radlog(L_DBG, "[%s-%d-%s]:epoll_handle_events: EPOLLHUP(%d) or EPOLLERR(%d) happened", __FILE__, __LINE__, __FUNCTION__,
											events[i].events & EPOLLHUP, events[i].events & EPOLLERR);
			events[i].events |= EPOLLIN;
		}
		if (events[i].events & EPOLLIN) {
			epoll_handle_read(inst, conn);
		}
	}
}


static int decode_packet(const char *buf, response_packet_t *response)
{
	cJSON *json = NULL;
	cJSON *tmp = NULL;
	cJSON *array = NULL;
	int array_size = 0;
	int i = 0;
	
	if (!buf || (buf[0] != '{')) {
		radlog(L_ERR, "[%s-%d-%s]: buf format error.", __FILE__, __LINE__, __FUNCTION__);
		return -1;
	}
	json = cJSON_Parse(buf);
	if (!json) {
		radlog(L_ERR, "[%s-%d-%s]: invalid json format: %s", __FILE__, __LINE__, __FUNCTION__, buf);
		return -1;
	}

	tmp = cJSON_GetObjectItem(json, "acl");
	if ((tmp != NULL) && (tmp->valuestring != NULL)) {
		response->acl = strdup(tmp->valuestring);
	}
	char* error_code = cJSON_Print(cJSON_GetObjectItem(json, "error_code"));
	if (error_code) {
		response->error_code = atoi(error_code);
		free(error_code);
		error_code = NULL;
	}
	else {
		response->error_code = 0;
	}
	response->error_msg = cJSON_Print(cJSON_GetObjectItem(json, "error_msg"));
	response->msresponse = cJSON_Print(cJSON_GetObjectItem(json, "msresponse"));
	response->chappwd = cJSON_Print(cJSON_GetObjectItem(json, "chappwd"));

	tmp = cJSON_GetObjectItem(json, "filter_id");
	if ((tmp != NULL) && (tmp->valuestring != NULL)) {
		response->filter_id = strdup(tmp->valuestring);
	}
	
	char* reject_code = cJSON_Print(cJSON_GetObjectItem(json, "reject_code"));
	if (reject_code) {
		response->reject_code = atoi(reject_code);
		free(reject_code);
		reject_code = NULL;
	}
	else {
		response->reject_code = 0;
	}

	char* reject_code1 = cJSON_Print(cJSON_GetObjectItem(json, "reject_code1"));
	if (reject_code1) {
		response->reject_code1 = atoi(reject_code1);
		free(reject_code1);
		reject_code1 = NULL;
	}
	else {
		response->reject_code1 = 0;
	}

	char* expire_day = cJSON_Print(cJSON_GetObjectItem(json, "expire_day"));
	if (expire_day) {
		response->expire_day = atoi(expire_day);
		free(expire_day);
		expire_day = NULL;
	} else {
		response->expire_day = 0;
	}

	char* is_roam = cJSON_Print(cJSON_GetObjectItem(json, "is_roam"));
	if (is_roam) {
		response->is_roam = atoi(is_roam);
		free(is_roam);
		is_roam = NULL;
	}
	else {
		response->is_roam = 0;
	}

	response->ap_list = cJSON_Print(cJSON_GetObjectItem(json, "ap_list"));
	
	char* response_type = cJSON_Print(cJSON_GetObjectItem(json, "response_type"));
	if (response_type) {
		response->response_type = atoi(response_type);
		free(response_type);
		response_type = NULL;
	}
	else {
		response->response_type = 0;
	}

	char* result = cJSON_Print(cJSON_GetObjectItem(json, "result"));
	if (result) {
		response->result = atoi(result);
		free(result);
		result = NULL;
	}
	else {
		response->result = 0;
	}

	char* sess = cJSON_GetObjectItem(json, "session_id")->valuestring;
	response->session_id = strdup(sess);

	char* session_timeout = cJSON_Print(cJSON_GetObjectItem(json, "session_timeout"));
	if (session_timeout) {
		response->session_timeout = atoi(session_timeout);
		free(session_timeout);
		session_timeout = NULL;
	}
	else {
		response->session_timeout = 0;
	}

	tmp = cJSON_GetObjectItem(json, "vlan_id");
	if ((tmp != NULL) && (tmp->valuestring != NULL)) {
		response->vlan_id = strdup(tmp->valuestring);
	}
	
	char* device_type = cJSON_Print(cJSON_GetObjectItem(json, "voice_flag"));
	if (device_type) {
		response->device_type = atoi(device_type);
		free(device_type);
		device_type = NULL;
	}
	else {
		response->device_type = 0;
	}

	char* macbind_cfg_id = cJSON_Print(cJSON_GetObjectItem(json, "macbind_cfg_id"));
	if (macbind_cfg_id) {
		response->macbind_cfg_id = atoi(macbind_cfg_id);
		radlog(L_DBG, "[%s-%d-%s]: macbind_cfg_id=%s (%d)", __FILE__, __LINE__, __FUNCTION__, macbind_cfg_id, response->macbind_cfg_id);
		free(macbind_cfg_id);
		macbind_cfg_id = NULL;
	}
	else {
		response->macbind_cfg_id = 0;
	}

	char* tianqing_auth_flag = cJSON_Print(cJSON_GetObjectItem(json, "tianqing_auth_flag"));
        if (tianqing_auth_flag) {
                response->tianqing_auth_flag = atoi(tianqing_auth_flag);
                free(tianqing_auth_flag);
                tianqing_auth_flag = NULL;
        }
        else {
                response->tianqing_auth_flag = 0;
        }

	array = cJSON_GetObjectItem(json, "attr_type");
	array_size = cJSON_GetArraySize(array);
	if (array != NULL) {
		response->num_attr = array_size;
		for (i = 0; i < array_size; i++) {
			tmp = cJSON_GetArrayItem(array, i);
			if (tmp != NULL) {
				response->attr_type[i] = tmp->valueint;
				radlog(L_DBG, "[%s-%d-%s]: attr_type[%d]=%d, array_size=%d", __FILE__, __LINE__, __FUNCTION__, i, response->attr_type[i], array_size);
			} else {
				radlog(L_ERR, "[%s-%d-%s]: get attr_type %d element error", __FILE__, __LINE__, __FUNCTION__, i);
			}
		}
	} else {
		radlog(L_ERR, "[%s-%d-%s]: attr_type field not found", __FILE__, __LINE__, __FUNCTION__);
	}

	array = cJSON_GetObjectItem(json, "attr_val");
	array_size = cJSON_GetArraySize(array);
	if ((array != NULL) &&  (array_size == response->num_attr)) {
		for (i = 0; i < array_size; i++) {
			tmp = cJSON_GetArrayItem(array, i);
			if ((tmp != NULL) && (tmp->valuestring != NULL)) {
				strlcpy(response->attr_val[i], tmp->valuestring, NAC_RADIUS_ATTR_MAX_SIZE-1);
				radlog(L_DBG, "[%s-%d-%s]: attr_val[%d]=%s", __FILE__, __LINE__, __FUNCTION__, i, response->attr_val[i]);
			} else {
				radlog(L_ERR, "[%s-%d-%s]: get attr_val %d element error", __FILE__, __LINE__, __FUNCTION__, i);
			}
		}
	} else {
		if (array == NULL) {
			radlog(L_ERR, "[%s-%d-%s]: attr_val field not found", __FILE__, __LINE__, __FUNCTION__);
		} else {
			radlog(L_ERR, "[%s-%d-%s]: num of attr_type not equal to num of attr_val, check!!!", __FILE__, __LINE__, __FUNCTION__);
		}
	}
	cJSON_Delete(json);
	return 0;
}


static int  parse_data(const char *buf, size_t len)
{
	char *end = (char *)buf + len;
	char *pos = (char *)buf;
	session_handle_t sess;

	while ((pos < end) && (strlen(pos) > 0)) {
		memset(&sess, 0, sizeof(session_handle_t));
		if (decode_packet(pos, &sess.response) != 0) {
			radlog(L_ERR, "[%s-%d-%s]: decode resp packet error!", __FILE__, __LINE__, __FUNCTION__);
			free_resp(&sess.response);
		}
		else {
			strncpy(sess.session_id, sess.response.session_id, AUTH_SESSION_ID_LENGTH);
			auth_session_update(&sess);
		}

		pos += strlen(pos) + 1;
	}
	return 0;
}

static int socket_init(const char *host, int port)
{
	int fd;
	struct sockaddr_in server_addr;

	fd = socket(AF_INET, SOCK_STREAM, 0);
	if (fd < 0) {
		radlog(L_ERR, "[%s-%d-%s]: socket error (%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
		return SOCKET_UNINITIALIZED;
	}
	memset(&server_addr, 0, sizeof(struct sockaddr_in));
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = inet_addr(host);
	server_addr.sin_port = htons(port);

#if 1
	int disable_nagle = 1;
	if (setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &disable_nagle, sizeof(disable_nagle)) < 0) {
		radlog(L_ERR, "[%s-%d-%s]: setsockopt TCP_NODELAY (%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
		close(fd);
		return SOCKET_UNINITIALIZED;
	}
#endif

	if (connect(fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
		radlog(L_ERR, "[%s-%d-%s]: connect error(%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
		close(fd);
		return SOCKET_UNINITIALIZED;
	}
#if 0
	int flags;
	if ((flags = fcntl(fd, F_GETFL, NULL)) < 0)  {
		radlog(L_ERR, "Failure getting socket flags: %s",
								strerror(errno));
		close(fd);
		return SOCKET_UNINITIALIZED;
	}
	flags |= O_NONBLOCK;
	if( fcntl(fd, F_SETFL, flags) < 0) {
		radlog(L_ERR, "Failure setting socket flags: %s",
								strerror(errno));
		close(fd);
		return SOCKET_UNINITIALIZED;
	}
#endif
	return fd;
}


static int connection_pool_init(rlm_auth_connection_t *inst)
{
	auth_conn_t *conn = NULL;
	int i;

	inst->conn_pool = rad_malloc(sizeof(auth_conn_t *) * inst->num_connections);
	if (!inst->conn_pool) {
		radlog(L_ERR, "[%s-%d-%s]: rad_malloc conn_pool failed",__FILE__, __LINE__, __FUNCTION__);
		return -1;
	}
	memset(inst->conn_pool, 0, sizeof(auth_conn_t *) * inst->num_connections);
	for (i = 0; i < inst->num_connections; i++) {
		conn = rad_malloc(sizeof(auth_conn_t));
		if (!conn) {
			radlog(L_ERR, "[%s-%d-%s]: rad_malloc conn_pool[i] failed",__FILE__, __LINE__, __FUNCTION__);
			return -1;
		}
		conn->id = i;
		conn->sockfd = SOCKET_UNINITIALIZED;
		conn->state = DISCONNECTED;
		pthread_mutex_init(&conn->lock, NULL);
		inst->conn_pool[i] = conn;
	}

	/* init socket */
	for (i = 0; i < inst->num_connections; i++) {
		conn = inst->conn_pool[i];
		conn->sockfd = socket_init(inst->hostname, inst->port);
		if (conn->sockfd < 0) {
			//return -1;
			/* it doesnt matter now, we will reconnect on arrival of requests, 
			 * this occurs when auth_center not running */
			radlog(L_ERR, "[%s-%d-%s]: socket_init failed",  __FILE__, __LINE__, __FUNCTION__);
		}
		else {
			conn->state = CONNECTED;
		}
	}
	/* init receiver epoll event engine */
	inst->epoll_fd = epoll_create(EPOLL_EVENT_SIZE);
	if (inst->epoll_fd < 0) {
		radlog(L_ERR, "[%s-%d-%s]: epoll_create error (%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
		return -1;
	}
	return 0;
}


static void dump_all_connections(rlm_auth_connection_t *inst)
{
	auth_conn_t *conn;
	int i;

	radlog(L_DBG, "---------------all conn----------------");
	radlog(L_DBG, "| hostname: %s", inst->hostname);
	radlog(L_DBG, "| port: %d", inst->port);
	radlog(L_DBG, "| num: %d", inst->num_connections);
	radlog(L_DBG, "| epoll_fd: %d", inst->epoll_fd);
	radlog(L_DBG, "| recver_tid: %lu", inst->recver_tid);
	for (i = 0; i < inst->num_connections; i++) {
		conn = inst->conn_pool[i];
		radlog(L_DBG, "| id: %d", conn->id);
		radlog(L_DBG, "| sockfd: %d", conn->sockfd);
		radlog(L_DBG, "| state: %d", conn->state);
	}
	radlog(L_DBG, "------------------end------------------");
}


static int auth_connection_instantiate(CONF_SECTION *conf, void **instance)
{
	rlm_auth_connection_t *inst;

	inst = rad_malloc(sizeof(rlm_auth_connection_t));
	if (!inst) {
		radlog(L_ERR, "[%s-%d-%s]: rad_malloc failed", __FILE__, __LINE__, __FUNCTION__);
		return -1;
	}
	memset(inst, 0, sizeof(rlm_auth_connection_t));
	if (cf_section_parse(conf, inst, module_config) < 0) {
		free(inst);
		return -1;
	}

	if (connection_pool_init(inst) < 0) {
		radlog(L_ERR, "[%s-%d-%s]: connection_pool_init failed", __FILE__, __LINE__, __FUNCTION__);
		auth_connection_detach(inst);
		return -1;
	}
	inst->send = auth_send;
	inst->recver_running = 1;
	/* initialize session tree */
	if (auth_session_init() != 0) {
		radlog(L_ERR, "[%s-%d-%s]: auth_session_init failed", __FILE__, __LINE__, __FUNCTION__);
		auth_connection_detach(inst);
		return -1;
	}
	if (pthread_create(&inst->recver_tid, NULL, auth_connection_receiver, inst) != 0) {
		radlog(L_ERR, "[%s-%d-%s]: pthread_create failed",__FILE__, __LINE__, __FUNCTION__);
		inst->recver_running = 0;
		auth_connection_detach(inst);
		return -1;
	}
	dump_all_connections(inst);
#ifdef TEST_AUTH_CONNECTION
	radlog(L_ERR, "[%s-%d-%s]: test thread", __FILE__, __LINE__, __FUNCTION__);
	pthread_t test_tid;
	if (pthread_create(&test_tid, NULL, run_test, inst) != 0) {
		radlog(L_ERR, "[%s-%d-%s]: test thread create error (%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
	}
#if 0
	if (pthread_create(&test_tid, NULL, run_test, inst) != 0) {
		radlog(L_ERR, "[%s-%d-%s]: test thread create error (%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
	}
	if (pthread_create(&test_tid, NULL, run_test, inst) != 0) {
		radlog(L_ERR, "[%s-%d-%s]: test thread create error (%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
	}
#endif
#endif 
	*instance = inst;
	return 0;
}


/*
 * @brief: thread to receive results from auth_center
 * @param arg: instance
 * @return
 */
static void *auth_connection_receiver(void *arg)
{
	rlm_auth_connection_t *inst = (rlm_auth_connection_t *) arg;
	struct epoll_event events[EPOLL_EVENT_SIZE];
	int i;
	int nready;

	for (i = 0; i < inst->num_connections; i++) {
		if (inst->conn_pool[i]->sockfd < 0) {
			continue;
		}
		if (epoll_add_event(inst->epoll_fd, inst->conn_pool[i], EPOLLIN) < 0) {
			radlog(L_ERR, "[%s-%d-%s]: epoll_add_event failed (id=%d, fd=%d) (%s)", __FILE__, __LINE__, __FUNCTION__,
							 inst->conn_pool[i]->id, inst->conn_pool[i]->sockfd, strerror(errno));
		}
	}

	while (inst->recver_running) {
		//radlog(L_DBG, "[%s-%d-%s]: epoll waitting ...", __FILE__, __LINE__, __FUNCTION__);
		nready = epoll_wait(inst->epoll_fd, events, EPOLL_EVENT_SIZE, -1);
		if (nready < 0) {
			if (errno == EINTR) {
				continue;
			}
			radlog(L_ERR, "[%s-%d-%s]: epoll_wait error (%s)", __FILE__, __LINE__, __FUNCTION__, strerror(errno));
			abort();
		}
		//radlog(L_DBG, "[%s-%d-%s]: %d events ready", __FILE__, __LINE__, __FUNCTION__,nready);
		epoll_handle_events(inst, events, nready);
	}
	return NULL;
}


static int auth_connection_detach(void *instance)
{
	rlm_auth_connection_t *inst = (rlm_auth_connection_t *)instance;
	int i;

	if (inst->recver_running) {
		/* wait receiver to finish, as conns may be in use */
		pthread_join(inst->recver_tid, NULL);
	}
	if (inst) {
		if (inst->conn_pool) {
			for (i = 0; i < inst->num_connections; i++) {
				auth_conn_t *conn = inst->conn_pool[i];
				if (conn) {
					if (conn->sockfd != SOCKET_UNINITIALIZED) {
						close(conn->sockfd);
						conn->sockfd = -1;
					}
					pthread_mutex_destroy(&conn->lock);
					free(conn);
					inst->conn_pool[i] = NULL;
				}
			}
			free(inst->conn_pool);
			inst->conn_pool = NULL;
		}
		close(inst->epoll_fd);
		free(inst);
	}
	auth_session_destroy();
	return 0;
}


static ssize_t write_fix_bytes(int fd, const void *buf, size_t len)
{
	int nleft = len;
	int nwritten = 0;
	int n;

	do {
		n = write(fd, buf+nwritten, nleft);
		if (n < 0) {
			if (errno == EINTR) {
				continue;
			}
			radlog(L_ERR, "[%s-%d-%s]: send error n=%d (%s)", __FILE__, __LINE__, __FUNCTION__,n, strerror(errno)); 
			return -1;
		}
		else if (n == 0) {
			/* for block mode, cant get here... */
			radlog(L_ERR, "[%s-%d-%s]: send 0 bytes (%s)", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
			return 0;
		}
		nwritten += n;
		nleft -= n;
	} while (nleft > 0);
	return nwritten;
}


/* folowing APIs exposed to other modules */
//TODO: who repair those broken conn? may use another thread to maintain
static int auth_send(void *instance, const void *buf, size_t len)
{
	rlm_auth_connection_t *inst = (rlm_auth_connection_t *)instance;
	auth_conn_t *conn;
	int i;
	int ret = 0;

	for (i = 0; i < inst->num_connections; i++) {
		conn = inst->conn_pool[i];
		if (!conn) {
			radlog(L_ERR, "[%s-%d-%s]: conn is null!", __FILE__, __LINE__, __FUNCTION__);
			continue;
		}
		if (pthread_mutex_trylock(&conn->lock) != 0) {
			if (i == (inst->num_connections-1)) {
				/* 
				 * here means no idle conn is available,
				 * so just wait on the first conn
				 */
				conn = inst->conn_pool[0];
				pthread_mutex_lock(&conn->lock);
			}
			else {
				/* conn unavailable, catch next conn */
				continue;
			}
		}
		//radlog(L_DBG, "[%s-%d-%s]: grab connection %d for send", __FILE__, __LINE__, __FUNCTION__,conn->id); 
		/* now we own the lock */
		if (conn->sockfd < 0) {
			radlog(L_ERR, "[%s-%d-%s]: conn->id=%d fd broken, reconnect...", __FILE__, __LINE__, __FUNCTION__,conn->id);
			conn->sockfd = socket_init(inst->hostname, inst->port);
			if (conn->sockfd < 0) {
				pthread_mutex_unlock(&conn->lock);
				radlog(L_ERR, "[%s-%d-%s]: conn->id=%d reconnect failed", __FILE__, __LINE__, __FUNCTION__,conn->id);
				return -1;
			}
			if (epoll_add_event(inst->epoll_fd, conn, EPOLLIN) < 0) {
				radlog(L_ERR, "[%s-%d-%s]: conn->id=%d epoll_add_event failed (%s)", __FILE__, __LINE__, __FUNCTION__,conn->id, strerror(errno));
				close(conn->sockfd);
				conn->sockfd = -1;
				pthread_mutex_unlock(&conn->lock);
				return -1;
			}
		}
		ret = write_fix_bytes(conn->sockfd, buf, len); 
		if (ret < 0) {
			radlog(L_ERR, "[%s-%d-%s]: conn->id=%d send failed, close connection", __FILE__, __LINE__, __FUNCTION__,conn->id);
			epoll_del_event(inst->epoll_fd, conn);
			close(conn->sockfd);
			conn->sockfd = -1;
		}
		pthread_mutex_unlock(&conn->lock);
		break;
	}
	return ret;
}


/* globally exported name */
module_t rlm_auth_connection = {
	RLM_MODULE_INIT,
	"Auth Connection Pool",
	RLM_TYPE_THREAD_UNSAFE,   	/* type */
	auth_connection_instantiate,		/* instantiation */
	auth_connection_detach,		/* detach */
	{
		NULL,			/* authentication */
		NULL,	/* authorization */
		NULL,	/* preaccounting */
		NULL,	/* accounting */
		NULL,			/* checksimul */
		NULL,			/* pre-proxy */
		NULL,			/* post-proxy */
		NULL			/* post-auth */
	},
};


#ifdef TEST_AUTH_CONNECTION

static int build_packet(char *out_buf, int pkt_id, char *sid)
{
	cJSON *root = cJSON_CreateObject();
	cJSON_AddNumberToObject(root, "packet_id", pkt_id);
	cJSON_AddStringToObject(root, "session_id", sid);
	cJSON_AddNumberToObject(root, "version", 1);
	cJSON_AddNumberToObject(root, "request_type", 0);
	cJSON_AddNumberToObject(root, "source_type", 0);
	cJSON_AddStringToObject(root, "user_name", "yj");

	cJSON *pass_word = NULL;
	cJSON_AddItemToObject(root, "pass_word", pass_word=cJSON_CreateObject());
	cJSON_AddNumberToObject(pass_word, "type", 0);
	cJSON_AddStringToObject(pass_word, "challenge", "00064");
	cJSON_AddStringToObject(pass_word, "content", "yj");
	cJSON_AddStringToObject(root, "nas_ip_addr", "172.27.181.136");

	cJSON_AddNumberToObject(root, "nas_port",        0);  
	cJSON_AddStringToObject(root, "nas_port_id",     "fastethernet0");
	cJSON_AddStringToObject(root, "nas_port_type",   "Ethernet");
	cJSON_AddStringToObject(root, "nas_identifier",  "H3C");
	cJSON_AddStringToObject(root, "service_type",    "Framed-User");
	cJSON_AddNumberToObject(root, "framed_protocol", 1);
	cJSON_AddNumberToObject(root, "auth_mode",       2);
	cJSON_AddStringToObject(root, "mid",             "aaaaa");
	cJSON_AddStringToObject(root, "mac",             "52:54:00:78:40:d1");
	char* res = cJSON_PrintUnformatted(root);
	memcpy(out_buf, res, strlen(res));
	free(res);  
	cJSON_Delete(root);
	return 0;
}


static void *run_test(void *arg)
{
	int i;
	rlm_auth_connection_t *inst = (rlm_auth_connection_t *) arg;
	session_handle_t *sess;
	char buf[4096] = {0};
	char sid[128] = "";

	sleep(60);
	radlog(L_ERR, "\n\n----------Run test now-----------\n");
	for (i=0; i<20; i++) {
		snprintf(sid, 128, "c3b96912-af15-4eb5-9a38-13b43438-%d", i);
		memset(buf, 0, sizeof(buf));
		build_packet(buf, i, sid);
		sess = auth_session_add(sid);
		auth_send(inst, buf, strlen(buf)+1);
	}
	dump_session_tree();
#if 0
	session_handle_t new_sess;
	for (i=0; i<20; i++) {
		snprintf(sid, 128, "c3b96912-af15-4eb5-9a38-13b43438-%d", i);
		strncpy(new_sess.session_id, sid, AUTH_SESSION_ID_LENGTH);
		session_handle_t *tmp_sess = NULL;
		if((tmp_sess = nac_rbtree_finddata(auth_session_tree, (void*)&new_sess))){ 
			radlog(L_DBG, "[%s-%d-%s]: check %s in tree: passed", __FILE__, __LINE__, __FUNCTION__, tmp_sess->session_id);
		}
		else {
		radlog(L_DBG, "[%s-%d-%s]: check %s in tree: failed", __FILE__, __LINE__, __FUNCTION__, new_sess.session_id);
		}
	}
#endif
	radlog(L_ERR, "----------test end-----------\n");
	while (1) {
		sleep(1);
	}
}
#endif
