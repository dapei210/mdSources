/*
 * rlm_auth_connection.c: create and maintain a conntion pool to auth_center.
 * Add "auth_connection" into radiusd.conf before using this module.
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2006  The FreeRADIUS server project
 */
#ifndef RLM_AUTH_CONNECTION_H
#define RLM_AUTH_CONNECTION_H

#include <freeradius-devel/ident.h>
RCSIDH(rlm_auth_connection_h, "$Id: 7816c63f676d5c2fad55531c5b2139a5acf3363f $")

#include <freeradius-devel/radiusd.h>
#include <freeradius-devel/modules.h>
#include <freeradius-devel/modpriv.h>


#define SOCKET_UNINITIALIZED    -1
#define EPOLL_EVENT_SIZE        1024
#define READ_BUF_SIZE           (1024 * 40)

typedef enum conn_state_s {
    DISCONNECTED,
    CONNECTED,
} conn_state_t;

typedef struct auth_conn_s {
    int id;
    int sockfd;
    conn_state_t state;
    pthread_mutex_t lock;
    char rbuf[READ_BUF_SIZE];
} auth_conn_t;


typedef struct rlm_auth_connection_s {
    char *hostname;
    int port;
    int num_connections;
    auth_conn_t **conn_pool;
    pthread_t recver_tid;
    int recver_running; /*1: running, 0: exited*/
    int epoll_fd;
    /* APIs used by other modules */
    int (*send)(void *instance, const void *buf, size_t len);
} rlm_auth_connection_t;


#endif
