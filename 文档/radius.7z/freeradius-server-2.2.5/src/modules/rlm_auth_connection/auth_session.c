/*
 * auth_session.c: create and maintain a session rbtree to auth_center.
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2000,2006  The FreeRADIUS server project
 */

#include <freeradius-devel/ident.h>
RCSID("$Id: ce126a3649c7c23d03f7002f947f43d2b9719e6a $")

#include <freeradius-devel/radiusd.h>
#include <freeradius-devel/modules.h>

#include <unistd.h>
#include <string.h>
#include "auth_session.h"

static nac_rbtree_t *auth_session_tree = NULL;
static pthread_mutex_t auth_session_lock;


void session_handle_init(session_handle_t* sess, char* session_id)
{
	memset(sess, 0, sizeof(session_handle_t));

	strncpy(sess->session_id, session_id, AUTH_SESSION_ID_LENGTH);
	sess->resp_available = 0;
	memset(&(sess->response), 0, sizeof(response_packet_t));
}


int session_handle_cmp(const void* pdata1, const void* pdata2)
{
	return strncmp(((session_handle_t*)pdata1)->session_id, ((session_handle_t*)pdata2)->session_id, AUTH_SESSION_ID_LENGTH);
}


int session_handle_dup(void* new, void* old)
{	
	/*节点重复,正常流程中会删除旧节点的,一般是认证异常造成的*/
	session_handle_t* pnew = (session_handle_t*)new;
	session_handle_t* pold = (session_handle_t*)old;

	/*用新节点数据覆盖纠结点数据*/
	strncpy(pold->session_id, pnew->session_id, AUTH_SESSION_ID_LENGTH);
	pold->resp_available = pnew->resp_available;

	/*拷贝response中数据*/
	free_resp(&(pold->response));
	memcpy(&(pold->response), &(pnew->response), sizeof(pnew->response));

	/*释放pnew中内存,指针内容已经直接赋给pold中了,这里设置为NLL*/
	pnew->response.acl=NULL;
	pnew->response.error_msg=NULL;
	pnew->response.msresponse=NULL;
	pnew->response.filter_id=NULL;
	pnew->response.session_id=NULL;
	pnew->response.vlan_id=NULL;
	pnew->response.ap_list=NULL;
	pnew->response.chappwd=NULL;
	free(pnew);
	pnew=NULL;

	return 0;
}

void session_handle_free(void* pdata)
{
	session_handle_t* sess = (session_handle_t *)pdata;

	if (sess){
		sess->session_id[0] = '\0';
		sess->resp_available = 0;
		free_resp(&sess->response);
		memset(&sess->response, 0, sizeof(response_packet_t));
		free(sess);
		sess = NULL;
	}
}


int auth_session_init(void)
{
    auth_session_tree = nac_rbtree_create(session_handle_cmp, session_handle_free, session_handle_dup);

    if (!auth_session_tree) {
		radlog(L_ERR, "[%s-%d-%s]: nac_rbtree_create faild", __FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
    pthread_mutex_init(&auth_session_lock, NULL);
    return 0;
}


int auth_session_destroy(void)
{
    if (!auth_session_tree) {
        return 0;
    }
    if (pthread_mutex_lock(&auth_session_lock) != 0) {
		radlog(L_ERR, "[%s-%d-%s]: pthread_mutex_lock faild", __FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
    nac_rbtree_free(auth_session_tree);
    auth_session_tree = NULL;
    pthread_mutex_unlock(&auth_session_lock);
    pthread_mutex_destroy(&auth_session_lock);
    return 0;
}

session_handle_t *auth_session_add(char *session_id)
{
    session_handle_t *sess;

    if (!session_id) {
		radlog(L_ERR, "[%s-%d-%s]: session_id null", __FILE__, __LINE__, __FUNCTION__);
        return NULL;
    }
    sess = malloc(sizeof(session_handle_t));
    if (!sess) {
		radlog(L_ERR, "[%s-%d-%s]: malloc failed (%s)", __FILE__, __LINE__, __FUNCTION__, strerror(errno));
        return NULL;
    }
    session_handle_init(sess, session_id);
    if (pthread_mutex_lock(&auth_session_lock) != 0) {
		radlog(L_ERR, "[%s-%d-%s]: pthread_mutex_lock faild", __FILE__, __LINE__, __FUNCTION__);
        free(sess);
        return NULL;
    }
    nac_rbtree_insert(auth_session_tree, sess);
    pthread_mutex_unlock(&auth_session_lock);
    return sess;
}


int auth_session_del(session_handle_t *sess)
{

    if (!sess) {
		radlog(L_ERR, "[%s-%d-%s]: session null", __FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
    if (pthread_mutex_lock(&auth_session_lock) != 0) {
		radlog(L_ERR, "[%s-%d-%s]: pthread_mutex_lock faild", __FILE__, __LINE__, __FUNCTION__);
        free(sess);
        return -1;
    }
    nac_rbtree_deletebydata(auth_session_tree, (const void*)sess);
    pthread_mutex_unlock(&auth_session_lock);
    return 0;
}

int auth_session_update(session_handle_t *new_sess)
{
    session_handle_t *sess;

    if (pthread_mutex_lock(&auth_session_lock) != 0) {
		radlog(L_ERR, "[%s-%d-%s]: pthread_mutex_lock faild", __FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
    if((sess = nac_rbtree_finddata(auth_session_tree, (void*)new_sess))) {
        sess->resp_available = 1;
        free_resp(&sess->response);
        memcpy(&sess->response, &new_sess->response, sizeof(response_packet_t));
        new_sess->response.acl = NULL;
        new_sess->response.error_msg=NULL;
        new_sess->response.filter_id = NULL;
        new_sess->response.session_id = NULL;
	new_sess->response.vlan_id=NULL;
        new_sess->response.ap_list=NULL;
	new_sess->response.chappwd=NULL;
	new_sess->response.msresponse=NULL;
    }
    pthread_mutex_unlock(&auth_session_lock);
    return 0;
}

static int print_node(void *pnode, void *arg)
{
    session_handle_t *sess = (session_handle_t *)pnode;
    radlog(L_DBG, "node->sid=%s, resp_avai=%d", sess->session_id, sess->resp_available);
    return 0;
}

void dump_session_tree(void)
{
    radlog(L_DBG, "--------------dump tree------------"); 
    radlog(L_DBG, "total: %d", auth_session_tree->num_elements);
    nac_rbtree_walk(auth_session_tree, nac_InOrder, print_node, NULL); 
    radlog(L_DBG, "--------------end of dump tree------------"); 
}

