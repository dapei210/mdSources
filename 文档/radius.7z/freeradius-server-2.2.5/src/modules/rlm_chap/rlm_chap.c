/*
 * rlm_chap.c
 *
 * Version:  $Id: c2f3f99a8bed3bcb364355da003d6e74a037d2d0 $
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * Copyright 2001,2006  The FreeRADIUS server project
 * Copyright 2001  Kostas Kalevras <kkalev@noc.ntua.gr>
 *
 * Nov 03 2001, Kostas Kalevras <kkalev@noc.ntua.gr>
 * - Added authorize() function to set Auth-Type if Chap-Password exists
 * - Added module messages when rejecting user
 */

#include <freeradius-devel/ident.h>
RCSID("$Id: c2f3f99a8bed3bcb364355da003d6e74a037d2d0 $")

#include <freeradius-devel/radiusd.h>
#include <freeradius-devel/modules.h>
#include <nac_common/auth_socket.h>
#include <nacstd/c_json.h>
#include <uuid/uuid.h>
#include <rlm_auth_connection.h>
#include <auth_session.h>

#ifndef FREE_PTR
#define FREE_PTR(P) if(P) free(P); (P)=NULL;
#endif 


typedef struct rlm_chap_t {
	rlm_auth_connection_t *auth_conn_inst;
} rlm_chap_t;


static int chap_authorize(void *instance, REQUEST *request)
{

	/* quiet the compiler */
	instance = instance;
	request = request;

	if (!pairfind(request->packet->vps, PW_CHAP_PASSWORD)) {
		return RLM_MODULE_NOOP;
	}

	if (pairfind(request->config_items, PW_AUTHTYPE) != NULL) {
		RDEBUG2("WARNING: Auth-Type already set.  Not setting to CHAP");
		return RLM_MODULE_NOOP;
	}

	RDEBUG("Setting 'Auth-Type := CHAP'");
	pairadd(&request->config_items,
		pairmake("Auth-Type", "CHAP", T_OP_EQ));
	return RLM_MODULE_OK;
}

static char* remove_char(const char* src)
{
	if (src == NULL)
		return "";

	char* result = (char*)malloc(strlen(src)-1);
	memset(result, 0, strlen(src)-1);
	strncpy(result,  src+1, strlen(src)-2);
	return result;
}

/*
 *	Find the named user in this modules database.  Create the set
 *	of attribute-value pairs to check and reply with for this user
 *	from the database. The authentication code only needs to check
 *	the password, the rest is done here.
 */
static int chap_authenticate(void *instance, REQUEST *request)
{
	rlm_chap_t *inst = (rlm_chap_t *) instance;
	VALUE_PAIR *passwd_item, *chap;
	uint8_t pass_str[MAX_STRING_LEN];
	VALUE_PAIR *module_fmsg_vp;
	char module_fmsg[MAX_STRING_LEN];
	VALUE_PAIR *vp_nas_ip_addr = NULL;
	VALUE_PAIR *vp_nas_port = NULL;
	VALUE_PAIR *vp_nas_port_id = NULL;
	VALUE_PAIR *vp_nas_port_type = NULL;
	VALUE_PAIR *vp_nas_identifier = NULL;
	VALUE_PAIR *vp_service_type = NULL;
	VALUE_PAIR *vp_mac = NULL;
	VALUE_PAIR *vp_user_name = NULL;
	VALUE_PAIR *vp_nas_ipv6_addr = NULL;
	VALUE_PAIR *vp_ip = NULL;
	VALUE_PAIR *vp_ipv6 = NULL;
	VALUE_PAIR *vp_ssid = NULL;
	DICT_ATTR *da = NULL;
	session_handle_t *sess = NULL;
	char vlan[32] = {0};
	char filter_id[256] = {0};
	int is_mab_auth = 0;
	/* quiet the compiler */
	instance = instance;
	request = request;

	if (!request->username) {
		radlog_request(L_AUTH, 0, request, "rlm_chap: Attribute \"User-Name\" is required for authentication.\n");
		return RLM_MODULE_INVALID;
	}

	chap = pairfind(request->packet->vps, PW_CHAP_PASSWORD);
	if (!chap) {
		RDEBUG("ERROR: You set 'Auth-Type = CHAP' for a request that does not contain a CHAP-Password attribute!");
		return RLM_MODULE_INVALID;
	}

	if (chap->length == 0) {
		RDEBUG("ERROR: CHAP-Password is empty");
		return RLM_MODULE_INVALID;
	}

	if (chap->length != CHAP_VALUE_LENGTH + 1) {
		RDEBUG("ERROR: CHAP-Password has invalid length");
		return RLM_MODULE_INVALID;
	}

	//add by yangjin
	char *user_name = NULL;
	if((da=dict_attrbyname("User-Name"))){
		//if ((vp_user_name=pairfind(request->parent->packet->vps,  da->attr))) {
		if ((vp_user_name=pairfind(request->packet->vps,  da->attr))) {
			user_name=vp_user_name->data.strvalue;
		}
	}
	
	char* nas_ip_address = NULL;
	char ipv4_buf[64] = {0};
	if((da=dict_attrbyname("NAS-IP-Address"))){
		if ((vp_nas_ip_addr=pairfind(request->packet->vps,  da->attr))) {
			nas_ip_address=inet_ntop(AF_INET, &vp_nas_ip_addr->data.ipaddr,ipv4_buf, sizeof(ipv4_buf));
			if (NULL == nas_ip_address || strncmp(nas_ip_address, "0.0.0.0", 7) == 0) {
				nas_ip_address = inet_ntop(AF_INET, &request->packet->src_ipaddr.ipaddr, ipv4_buf, sizeof(ipv4_buf));
			}

		} else {
			if (request->packet->src_ipaddr.af == AF_INET)
				nas_ip_address = inet_ntop(AF_INET, &request->packet->src_ipaddr.ipaddr, ipv4_buf, sizeof(ipv4_buf));
		}
	}

	char *nas_ipv6_address = NULL;
	char ipv6_buf[48] = {0};
	if((da=dict_attrbyname("NAS-IPv6-Address"))){
		if ((vp_nas_ipv6_addr= pairfind(request->packet->vps,  da->attr))) {
			nas_ipv6_address = inet_ntop(AF_INET6, (void *)&vp_nas_ipv6_addr->data.ipv6addr, ipv6_buf ,INET6_ADDRSTRLEN );
		} else {
			if (request->packet->src_ipaddr.af == AF_INET6)
				nas_ipv6_address = inet_ntop(AF_INET6, &request->packet->src_ipaddr.ipaddr, ipv6_buf, sizeof(ipv6_buf));
		}
	} 
	//NAS-Port
	int nas_port = 0;
	if((da=dict_attrbyname("NAS-Port"))){
		if ((vp_nas_port=pairfind(request->packet->vps,  da->attr))) {
			nas_port=vp_nas_port->lvalue;
		}
	}
		//NAS-Port-Id
	char* nas_port_id =NULL;
	if((da=dict_attrbyname("NAS-Port-Id"))){
		if ((vp_nas_port_id=pairfind(request->packet->vps,  da->attr))) {
			nas_port_id=vp_nas_port_id->data.strvalue;
		}
	}

	//NAS-Port-Type
	char* nas_port_type = NULL;
	if((da=dict_attrbyname("NAS-Port-Type"))){
		if ((vp_nas_port_type=pairfind(request->packet->vps,  da->attr))) {
			nas_port_type=vp_nas_port_type->data.strvalue;
		}
	}
	
	//NAS-Identifier
	char* nas_identifier = NULL;
	if((da=dict_attrbyname("NAS-Identifier"))){
		if ((vp_nas_identifier=pairfind(request->packet->vps,  da->attr))) {
			nas_identifier=vp_nas_identifier->data.strvalue;
		}
	}
	
	//Service-Type
	char* service_type = NULL;
	if((da=dict_attrbyname("Service-Type"))){
		if ((vp_service_type=pairfind(request->packet->vps,  da->attr))) {
			service_type=vp_service_type->data.strvalue;
		}
	}
	
	//Framed-Protocol 1 PPP
	int framed_protocol = 1; //if 1, PPP
	//request_packet.framed_protocol = framed_protocol;
	
	//MAC
	char *req_mac = NULL;
	if((da=dict_attrbyname("Calling-Station-Id"))){
		if ((vp_mac=pairfind(request->packet->vps,  da->attr))) {
			req_mac=vp_mac->data.strvalue;
		}
	}

	//Framed-IP-Address
        char *framed_ip = NULL;
        char client_ip[64] = {0};
        if((da=dict_attrbyname("Framed-IP-Address"))){
                if ((vp_ip=pairfind(request->packet->vps,  da->attr))) {
                        framed_ip=inet_ntop(AF_INET, &vp_ip->data.ipaddr,client_ip, sizeof(client_ip));
                        if (NULL == framed_ip || strncmp(framed_ip, "0.0.0.0", 7) == 0) {
                                framed_ip = inet_ntop(AF_INET, &request->packet->src_ipaddr.ipaddr, client_ip, sizeof(client_ip));
                        }

                } else {
                        if (request->packet->src_ipaddr.af == AF_INET)
                                framed_ip = inet_ntop(AF_INET, &request->packet->src_ipaddr.ipaddr, client_ip, sizeof(client_ip));
                }
        }

        //Framed-IPv6-Address
        char *framed_ipv6 = NULL;
        char client_ipv6[64] = {0};
        if((da=dict_attrbyname("Framed-IPv6-Address"))){
                if ((vp_ipv6=pairfind(request->packet->vps,  da->attr))) {
                        framed_ipv6=inet_ntoa(vp_ipv6->data.ipaddr);
                        if (NULL == framed_ipv6 || strncmp(framed_ipv6, "0.0.0.0", 7) == 0) {
                                framed_ipv6 = inet_ntop(AF_INET, &request->packet->src_ipaddr.ipaddr, client_ipv6, sizeof(client_ipv6));
                        }

                } else {
                        if (request->packet->src_ipaddr.af == AF_INET)
                                framed_ipv6 = inet_ntop(AF_INET, &request->packet->src_ipaddr.ipaddr, client_ipv6, sizeof(client_ipv6));
                }
        }
	DEBUG("nas_ip_address=[%s], client_ip=[%s]\n", nas_ip_address, framed_ip);
	char* ssid = NULL;
	if ((da = dict_attrbyname("Called-Station-Id"))) {
		if ((vp_ssid = pairfind(request->packet->vps, da->attr))) {
			ssid = vp_ssid->data.strvalue;
			radlog(L_DBG, "[%s-%d-%s]: ssid=%s", __FILE__, __LINE__, __FUNCTION__, ssid);
		}
	}
	char tmpName[256] = {0};
	char tmpMac[256] = {0};
	char userName[256] = {0};
	char mac[256] = {0};
	replace(user_name, ':', tmpName);
	replace(tmpName, '-', userName);
	if (req_mac != NULL) {
		replace(req_mac, ':', tmpMac);
		replace(tmpMac, '-', mac);
	} 
	DEBUG("user_name=[%s], len=[%d]\n", userName, strlen(userName));
	DEBUG("mac=[%s], len=[%d]\n", mac, strlen(mac));
	
	cJSON *root = cJSON_CreateObject();
	cJSON_AddNumberToObject(root, "packet_id", 0);
	char session_id[37] = {0};
	gen_uuid(session_id);
	cJSON_AddStringToObject(root, "session_id", session_id);
	cJSON_AddNumberToObject(root, "version", 1);
	cJSON_AddNumberToObject(root, "request_type",0);

	if ((nas_ip_address  != NULL) && (strncmp(nas_ip_address, "127.0.0.1", 9) != 0)) {
		cJSON_AddStringToObject(root, "nas_ip_addr", nas_ip_address);
	}

	if (nas_ipv6_address != NULL) {
		cJSON_AddStringToObject(root, "nas_ipv6_addr", nas_ipv6_address);

	}
	if(nas_port/10000==5){
		nas_port = nas_port % 50000;
	}else{ 
		if (nas_port >= 4096)
		{
			nas_port = (nas_port >> 12) & (0xff);
		}
	}
	
	cJSON_AddNumberToObject(root, "nas_port", nas_port);
	if (nas_port_id != NULL)
	{	
		cJSON_AddStringToObject(root, "nas_port_id", nas_port_id);
	}
	else
	{
		cJSON_AddStringToObject(root, "nas_port_id", "");
	}

	if (nas_port_type != NULL)
	{
		cJSON_AddStringToObject(root, "nas_port_type", nas_port_type);
	}
	else
	{
		cJSON_AddStringToObject(root, "nas_port_type", "");
	}
	//cJSON_AddNumberToObject(root, "auth_mode", 11); //chap auth mode: 11

	if (framed_ip != NULL)
                cJSON_AddStringToObject(root, "client_ip", framed_ip);
	else if (framed_ipv6 != NULL)
		cJSON_AddStringToObject(root, "client_ip", framed_ipv6);
	
	if (0 == strncasecmp(userName, mac, 12)) {
		is_mab_auth = 1;
		radlog(L_DBG, "[%s-%d-%s]: mac base auth with chap", __FILE__, __LINE__, __FUNCTION__);
		cJSON_AddNumberToObject(root, "source_type", 0); // see auth_center SW_PORTAL
		cJSON_AddNumberToObject(root, "auth_mode", MAC_BASE); //MAC_BASE mac base认证时用户名是mac地址
		cJSON_AddStringToObject(root, "user_name", userName);
	} else {
		is_mab_auth = 0;
		radlog(L_DBG, "[%s-%d-%s]: chap username-pwd auth", __FILE__, __LINE__, __FUNCTION__);
		cJSON_AddNumberToObject(root, "source_type", 3); // see auth_center SW_PORTAL
		cJSON_AddNumberToObject(root, "auth_mode", CHAP_AUTH); //chap auth
		cJSON_AddStringToObject(root, "user_name", user_name);
		if ((ssid != NULL) && (strlen(ssid) > 0)) {
                        cJSON_AddStringToObject(root, "ssid", ssid);
                }
	}
	
	if (req_mac != NULL) {
		cJSON_AddStringToObject(root, "mac", req_mac);
	}
	char *result = cJSON_PrintUnformatted(root);
	cJSON_Delete(root);

	radlog(L_DBG, "[%s-%d-%s]: add session", __FILE__, __LINE__, __FUNCTION__);
	sess = auth_session_add(session_id);
	if (!sess) {
		radlog(L_ERR, "[%s-%d-%s]: auth_session_add failed, then bypass", __FILE__, __LINE__, __FUNCTION__);
		return RLM_MODULE_OK;
	}
	if (!inst->auth_conn_inst->send) {
		radlog(L_ERR, "[%s-%d-%s]: send func null, then bypass", __FILE__, __LINE__, __FUNCTION__);
		auth_session_del(sess);
		return RLM_MODULE_OK;
	}
	int send_ret = inst->auth_conn_inst->send(inst->auth_conn_inst, result, strlen(result)+1);

	if (send_ret <0) {
		FREE_PTR(result);
		auth_session_del(sess);
		return RLM_MODULE_OK;
	}

	FREE_PTR(result);

	int timer = 0;
	while (!sess->resp_available) {
		timer++;
		usleep(1000*10);
		if (timer == 4000) {
			break;
		}
	}

	if (sess->resp_available == 0){
		radlog(L_ERR, "[%s-%d-%s]: Receive error, bypass", __FILE__, __LINE__, __FUNCTION__);	
		auth_session_del(sess);
		return RLM_MODULE_OK;
	}

	response_packet_t response_packet;
	memset(&response_packet, 0, sizeof(response_packet));
	memcpy(&response_packet, &(sess->response), sizeof(response_packet_t));
	if ((response_packet.vlan_id != NULL) && (strlen(response_packet.vlan_id) > 0)) {
		strncpy(vlan, response_packet.vlan_id, sizeof(vlan));
	}
	if ((response_packet.filter_id != NULL) && (strlen(response_packet.filter_id) > 0)) {
		strncpy(filter_id, response_packet.filter_id, sizeof(filter_id));
	}

	if (is_mab_auth) {
		auth_session_del(sess);
		if (response_packet.result == 0) {
			radlog(L_DBG, "[%s-%d-%s]: mab auth with chap success", __FILE__, __LINE__, __FUNCTION__);
			if ((strlen(vlan) > 0) ){
				radlog(L_DBG, "[%s-%d-%s]: nac set vlan %s", __FILE__, __LINE__, __FUNCTION__, vlan);
				radius_set_attr_value(&request->reply->vps, "Vlan-Type", PW_TYPE_STRING, vlan);
			}
			if (strlen(filter_id) > 0) {
				radius_set_attr_value(&request->reply->vps, "Filter-Id", PW_TYPE_STRING, filter_id);
			}
			if (response_packet.session_timeout > 0) {
				if (g_term_action && response_packet.session_timeout != 31536000) { 
					radius_set_attr_value(&request->reply->vps, "Termination-Action", PW_TYPE_INTEGER, &g_term_action);
				}
				radius_set_attr_value(&request->reply->vps, "Session-Timeout", PW_TYPE_INTEGER, &response_packet.session_timeout);

			}
			return RLM_MODULE_OK;
		} else {
			radlog(L_DBG, "[%s-%d-%s]: mab auth with chap failed", __FILE__, __LINE__, __FUNCTION__);
			return RLM_MODULE_REJECT;
		}
	}
	//now must be chap auth with username & pwd
	if ((response_packet.result == 0) &&(strlen(response_packet.chappwd) > 2))
	{
		radlog(L_DBG, "[%s-%d-%s]: nac add pwd msg", __FILE__, __LINE__, __FUNCTION__);
		char* password = remove_char(response_packet.chappwd);
		radius_pairmake(request, &request->config_items,
					  "Cleartext-Password",  password, T_OP_CMP_EQ);
		FREE_PTR(password);
	}
	else
	{
		radius_pairmake(request, &request->config_items,
					  "Cleartext-Password",  "", T_OP_CMP_EQ);
	}
	auth_session_del(sess);
	/*
	 *	Don't print out the CHAP password here.  It's binary crap.
	 */
	RDEBUG("login attempt by \"%s\" with CHAP password",
		request->username->vp_strvalue);

	if ((passwd_item = pairfind(request->config_items, PW_CLEARTEXT_PASSWORD)) == NULL){
	  RDEBUG("Cleartext-Password is required for authentication");
		snprintf(module_fmsg, sizeof(module_fmsg),
			 "rlm_chap: Clear text password not available");
		module_fmsg_vp = pairmake("Module-Failure-Message",
					  module_fmsg, T_OP_EQ);
		pairadd(&request->packet->vps, module_fmsg_vp);
		return RLM_MODULE_INVALID;
	}

	RDEBUG("Using clear text password \"%s\" for user %s authentication.",
		  passwd_item->vp_strvalue, request->username->vp_strvalue);

	rad_chap_encode(request->packet,pass_str,
			chap->vp_octets[0],passwd_item);

	if (rad_digest_cmp(pass_str + 1, chap->vp_octets + 1,
			   CHAP_VALUE_LENGTH) != 0) {
		RDEBUG("Password check failed");
		snprintf(module_fmsg, sizeof(module_fmsg),
			 "rlm_chap: Wrong user password");
		module_fmsg_vp = pairmake("Module-Failure-Message",
					  module_fmsg, T_OP_EQ);
		pairadd(&request->packet->vps, module_fmsg_vp);
		return RLM_MODULE_REJECT;
	}

	RDEBUG("chap user %s authenticated succesfully",
		  request->username->vp_strvalue);
	if ((strlen(vlan) > 0)){
		radlog(L_DBG, "[%s-%d-%s]: nac set vlan %s", __FILE__, __LINE__, __FUNCTION__, vlan);
		radius_set_attr_value(&request->reply->vps, "Vlan-Type", PW_TYPE_STRING, vlan);
	}
	if (strlen(filter_id) > 0) {
		radius_set_attr_value(&request->reply->vps, "Filter-Id", PW_TYPE_STRING, filter_id);
	}
	if (response_packet.session_timeout > 0) {
		RDEBUG("chap user %s timeout %d",request->username->vp_strvalue,response_packet.session_timeout);
		if (g_term_action && response_packet.session_timeout != 31536000) {
			radius_set_attr_value(&request->reply->vps, "Termination-Action", PW_TYPE_INTEGER, &g_term_action);
		}
		radius_set_attr_value(&request->reply->vps, "Session-Timeout", PW_TYPE_INTEGER, &response_packet.session_timeout);
	}
	return RLM_MODULE_OK;
}


static int chap_instantiate(CONF_SECTION *conf, void **instance)
{
	rlm_chap_t *inst;

	/*
	 *      Set up a storage area for instance data
	 */
	inst = rad_malloc(sizeof(*inst));
	if (!inst) {
		return -1;
	}
	memset(inst, 0, sizeof(*inst));

	radlog(L_INFO, "\n\nrlm_chap: load rlm_auth_connection\n\n");
	module_instance_t *modinst;
	modinst = find_module_instance(cf_section_find("modules"), "auth_connection", 1);
	if (!modinst) {
		radlog(L_ERR, "[%s-%d-%s]: auth_connection module load failed",  __FILE__, __LINE__, __FUNCTION__);
		return -1;
	}
	inst->auth_conn_inst = (rlm_auth_connection_t *) modinst->insthandle;
	*instance = inst;
	return 0;
}

static int chap_detach(void *instance)
{
	rlm_chap_t *inst = (rlm_chap_t *) instance;

	free(inst);
	return 0;
}


/*
 *	The module name should be the only globally exported symbol.
 *	That is, everything else should be 'static'.
 *
 *	If the module needs to temporarily modify it's instantiation
 *	data, the type should be changed to RLM_TYPE_THREAD_UNSAFE.
 *	The server will then take care of ensuring that the module
 *	is single-threaded.
 */
module_t rlm_chap = {
	 RLM_MODULE_INIT,
	"CHAP",
	RLM_TYPE_CHECK_CONFIG_SAFE,   	/* type */
	chap_instantiate,				/* instantiation */
	chap_detach,				/* detach */
	{
		chap_authenticate,	/* authentication */
		chap_authorize,	 	/* authorization */
		NULL,			/* preaccounting */
		NULL,			/* accounting */
		NULL,			/* checksimul */
		NULL,			/* pre-proxy */
		NULL,			/* post-proxy */
		NULL			/* post-auth */
	},
};
