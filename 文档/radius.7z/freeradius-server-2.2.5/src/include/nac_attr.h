#ifndef _NAC_ATTR_H
#define _NAC_ATTR_H
#include <freeradius-devel/ident.h>
#include <freeradius-devel/libradius.h>

#define NAC_ATTR_MAX_TYPE   256
#define NAC_ATTR_MAX_NAME_SIZE  128
#define PLUGIN_CODE_LEN		6

typedef struct nac_attr_s {
    const char *name;
    int type;
    int (*attr_handler)(VALUE_PAIR **vps, const char *name, const char *val);
} nac_attr_t;

struct plugin_req {
	char swip[64];
	char mac[32];
	char username[64];
	char nas_port_type[64];
}; 

nac_attr_t *nac_attr_get(int type);
int nac_copy_common_attr(VALUE_PAIR *src_vps, VALUE_PAIR **dst_vps);
int nac_get_common_attr(VALUE_PAIR *vps, const char *name, char *out, int len);
int nac_set_common_attr(VALUE_PAIR **vps, const char *name, const char *val);
int plugin_query_policy(const struct plugin_req *plugreq);

#endif /* _NAC_ATTR_H */
