#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <uuid/uuid.h>
#include <freeradius-devel/libradius.h>
#include <nacstd/c_json.h>
#include <curl/curl.h>


#define NAC_SERVER_ADDR "/tmp/nac_server.sock"
#define NSQ_ADDR "127.0.0.1"
#define NSQ_PORT 4151
#define NSQ_TOPIC "radius_swith_log"

static CURL *g_curl = NULL;
static int g_curl_inited = 0;

#define NAC_SNPRINTF(buf, format, ...) \
do { \
	offset = strlen(buf); \
	snprintf(buf+offset, sizeof(buf)-offset, format, ## __VA_ARGS__); \
} while(0)


static int connect_server(const char *sk_name)                                                                
{
    int sockfd;
    struct sockaddr_un addr;

    sockfd = socket(AF_UNIX, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
        fr_strerror_printf("connect_server: socket error: %s", strerror(errno));
        return -1; 
    }   

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, sk_name, sizeof(addr.sun_path) - 1); 

    if (connect(sockfd, (struct sockaddr *) &addr, sizeof(struct sockaddr_un)) == -1) { 
        fr_strerror_printf("connect_server: connect error: %s", strerror(errno));
        close(sockfd);
        return -1; 
    }   
    return sockfd;
}

static size_t write_data(void *buffer, size_t size, size_t nmemb, void *userp) {
    return size * nmemb;
}

static int nsq_post_msg(const char *topic, const char *buf)
{
    char url[256] = {0};
    CURLcode ret;

    if (g_curl_inited == 0) {
        g_curl = curl_easy_init();
        g_curl_inited = 1;
    }
    if (!g_curl || !topic || !buf) {
        fr_strerror_printf("nsq_post_msg: param null\n");
        return -1;
    }
    snprintf(url, sizeof(url), "http://%s:%d/pub?topic=%s", NSQ_ADDR, NSQ_PORT, topic);
    curl_easy_reset(g_curl);
    curl_easy_setopt(g_curl, CURLOPT_TIMEOUT, 5);
    curl_easy_setopt(g_curl, CURLOPT_URL, url);
    curl_easy_setopt(g_curl, CURLOPT_WRITEFUNCTION, write_data);
    curl_easy_setopt(g_curl, CURLOPT_POSTFIELDS, buf);
    ret = curl_easy_perform(g_curl);
    if (CURLE_OK != ret) {
        fr_strerror_printf("nsq_post_msg: post failed, ret=%d", ret);
        return -1;
    }
    printf("nsq_post_msg: post success, buf=%s", buf);
    return 0;
}


/**
 * @brief send log to skylar
 * @param type
 	0: 接入点未添加
 	1: 接入点秘钥错误
 */
int nac_log(int type, char *nas_ip)
{
    cJSON *root = NULL;
    char *out = NULL;
    time_t now;

    if ((nas_ip == NULL) ||(strlen(nas_ip) == 0)) {
        return -1;
    }
    root = cJSON_CreateObject();
    if (root == NULL) {
        fr_strerror_printf("nac_log: cJSON_CreateObject error\n");
        return -1;
    }
    now = time(NULL);
    cJSON_AddStringToObject(root, "topic", NSQ_TOPIC);
    if (type == 0) {
        cJSON_AddStringToObject(root, "reason", "交换机不存在");
    } else if (type == 1) {
        cJSON_AddStringToObject(root, "reason", "交换机密钥错误");
    }
    cJSON_AddStringToObject(root, "nas_ip", nas_ip);
    cJSON_AddNumberToObject(root, "login_time", now);
    cJSON_AddNumberToObject(root, "auth_result", 1);
    cJSON_AddNumberToObject(root, "auth_source", 0);

    out = cJSON_PrintUnformatted(root);
    if (out != NULL) {
        nsq_post_msg(NSQ_TOPIC, out);
        free(out);
    } else {
        fr_strerror_printf("nac_log: cJSON_PrintUnformatted error\n");
    }
    cJSON_Delete(root);
    return 0;
}
