#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/un.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <freeradius-devel/nac_attr.h>


const char *UnixDomainPath =  "/var/run/mfactor.sock";



static int replace(char *p,char c, char* result)
{
    int len=strlen(p);
    char *rtn=result;
    while(*p!='\0')
    {
        if(*p!=c)
            *rtn++=*p++;
        else
            *p++;
    }
    *rtn='\0';
    return 0;
}

static int connect_server(const char *sk_name) {
    int sockfd;
    struct sockaddr_un addr;

    if (sk_name == NULL) return -1;

    sockfd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sockfd == -1) {
        fr_strerror_printf("[%s-%d-%s]: nac-connect_server: socket error %s",__FILE__, __LINE__, __FUNCTION__, strerror(errno));   
        return -1;
    }

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, sk_name, sizeof(addr.sun_path) - 1);

    if (connect(sockfd, (struct sockaddr *)&addr, sizeof(struct sockaddr_un)) ==
        -1) {
        fr_strerror_printf("[%s-%d-%s]: nac-connect_server: connect error %s",__FILE__, __LINE__, __FUNCTION__, strerror(errno));
        close(sockfd);
        return -1;
    }
    return sockfd;
}


static int process_response(int fd) {
    fd_set rfds;
    struct timeval timeout;
    int ret;
    char buf[32] = {0};
    ssize_t nread = 0;

    FD_ZERO(&rfds);
    FD_SET(fd, &rfds);
    timeout.tv_sec = 3;
    timeout.tv_usec = 0;
    ret = select(fd + 1, &rfds, NULL, NULL, &timeout);
    if (ret <= 0) {
        fr_strerror_printf("[%s-%d-%s]: nac-process_response:read time out %s",__FILE__, __LINE__, __FUNCTION__, strerror(errno));
        return -1;
    }
    if (!FD_ISSET(fd, &rfds)) {
        fr_strerror_printf("[%s-%d-%s]: nac-process_response:read event not ready",__FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
    if ((nread = read(fd, buf, 1) <= 0)) {
        fr_strerror_printf("[%s-%d-%s]: nac-process_response: read error %s, nread=%d\n",__FILE__, __LINE__, __FUNCTION__, strerror(errno), (int)nread);
        return -1;
    }
    fr_strerror_printf("[%s-%d-%s]: nac-process_response: read buf=%s, nread=%d",__FILE__, __LINE__, __FUNCTION__, buf, (int)nread);  
    ret = atoi(buf);
    return ret;
} 

int plugin_query_policy(const struct plugin_req *plugreq) 
{
    int fd = 0;
    char buf[128] = {0};
    int n, size;
    int ret;
 
    fd = connect_server(UnixDomainPath);
    if (fd < 0) {
        fr_strerror_printf("[%s-%d-%s]: nac-query_policy: connect_server failed.", __FILE__, __LINE__, __FUNCTION__);
        
        return -1;
    }
    snprintf(buf, sizeof(buf), "mac=%s&swip=%s&username=%s&nas_port_type=%s", plugreq->mac, plugreq->swip, 
                plugreq->username, plugreq->nas_port_type);
    fr_strerror_printf("nac-query_policy: send buf=%s", buf);
    
    size = strlen(buf);
    n = write(fd, buf, size);
    if (n < 0) {
        fr_strerror_printf("[%s-%d-%s]: nac-query_policy: write error %s.", __FILE__, __LINE__, __FUNCTION__,strerror(errno));
        close(fd);
        return -1;
    } else if (n < size) {
        fr_strerror_printf("[%s-%d-%s]: nac-query_policy: write less bytes(%s), n=%d, size=%d",__FILE__, __LINE__, __FUNCTION__, strerror(errno), n, size);
       
        close(fd);
        return -1;
    }
    ret = process_response(fd);
    close(fd);
    return ret;
}




