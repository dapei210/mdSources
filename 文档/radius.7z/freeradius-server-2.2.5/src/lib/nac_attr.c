#include <freeradius-devel/ident.h>
#include <stdio.h>
#include <stdlib.h>
#include <uuid/uuid.h>
#include <freeradius-devel/nac_attr.h>



static int set_common_attr(VALUE_PAIR **vps, const char *name, const char *val);

nac_attr_t g_attr_array[] = {
    {"HW-Input-Peak-Information-Rate", 1, set_common_attr},
    {"HW-Input-Committed-Information-Rate", 2, set_common_attr},
    {"HW-Input-Committed-Burst-Size", 3, set_common_attr},
    {"HW-Output-Peak-Information-Rate", 4, set_common_attr},
    {"HW-Output-Committed-Information-Rate", 5, set_common_attr},
    {"HW-Output-Committed-Burst-Size", 6, set_common_attr},
    {"HW-Remanent-Volume", 15, set_common_attr},
    {"HW-Subscriber-QoS-Profile", 17, set_common_attr},
    {"HW-UserName-Access-Limit", 18, set_common_attr},
    {"HW-Connect-ID", 26, set_common_attr},
    {"HW-FTP-Directory", 28, set_common_attr},
    {"HW-Exec-Privilege", 29, set_common_attr},
    {"HW-Qos-Data", 31, set_common_attr},
    {"HW-VoiceVlan", 33, set_common_attr},
    {"HW-ProxyRdsPkt", 35, set_common_attr},
    {"HW-NAS-Startup-Time-Stamp", 59, set_common_attr},
    {"HW-IP-Host-Address", 60, set_common_attr},
    {"HW-Up-Priority", 61, set_common_attr},
    {"HW-Down-Priority", 62, set_common_attr},
    {"HW-Primary-WINS", 75, set_common_attr},
    {"HW-Second-WINS", 76, set_common_attr},
    {"HW-Input-Peak-Burst-Size", 77, set_common_attr},
    {"HW-Output-Peak-Burst-Size", 78, set_common_attr},
    {"HW-Data-Filter", 82, set_common_attr},
    {"HW-Client-Primary-DNS", 135, set_common_attr},
    {"HW-Client-Secondary-DNS", 136, set_common_attr},
    {"HW-Domain-Name", 138, set_common_attr},
    {"HW-AP-Information", 141, set_common_attr},
    {"HW-User-Information", 142, set_common_attr},
    {"HW-User-Policy", 146, set_common_attr},
    {"HW-Access-Type", 153, set_common_attr},
    {"HW-URL-Flag", 155, set_common_attr},
    {"HW-Portal-URL", 156, set_common_attr},
    {"HW-Terminal-Type", 157, set_common_attr},
    {"HW-DHCP-Option", 158, set_common_attr},
    {"HW-HTTP-UA", 159, set_common_attr},
    {"HW-UCL-Group", 160, set_common_attr},
    {"HW-Forwarding-VLAN", 161, set_common_attr},
    {"HW-Forwarding-Interface", 162, set_common_attr},
    {"HW-LLDP", 163, set_common_attr},
    {"HW-Acct-ipv6-Input-Octets", 166, set_common_attr},
    {"HW-Acct-ipv6-Output-Octets", 167, set_common_attr},
    {"HW-Acct-ipv6-Input-Packets", 168, set_common_attr},
    {"HW-Acct-ipv6-Output-Packets", 169, set_common_attr},
    {"HW-Acct-ipv6-Input-Gigawords", 170, set_common_attr},
    {"HW-Acct-ipv6-Output-Gigawords", 171, set_common_attr},
    {"HW-Redirect-ACL", 173, set_common_attr},
    {"HW-IPv6-Redirect-ACL", 178, set_common_attr},
    {"HW-User-Extend-Info", 201, set_common_attr},
    {"HW-Web-Authen-Info", 237, set_common_attr},
    {"HW-Ext-Specific", 238, set_common_attr},
    {"HW-User-Access-Info", 239, set_common_attr},
    {"HW-Access-Device-Info", 240, set_common_attr},
    {"HW-Reachable-Detect", 244, set_common_attr},
    {"HW-Tariff-Input-Octets", 247, set_common_attr},
    {"HW-Tariff-Output-Octets", 248, set_common_attr},
    {"HW-Tariff-Input-Gigawords", 249, set_common_attr},
    {"HW-Tariff-Output-Gigawords", 250, set_common_attr},
    {"HW-IPv6-Filter-ID", 251, set_common_attr},
    {"HW-Framed-IPv6-Address", 253, set_common_attr},
    {"HW-Version", 254, set_common_attr},
    {"HW-Product-ID", 255, set_common_attr},
    {"Cisco-AVPair", 1001, set_common_attr},
    {"H3C-Input-Peak-Rate", 2001, set_common_attr},
    {"H3C-Output-Peak-Rate", 2004, set_common_attr},
    {NULL, -1, NULL}
};

static int set_common_attr(VALUE_PAIR **vps, const char *name, const char *val)
{
    DICT_ATTR *da=NULL;

    if (!name || !val) {
        fr_strerror_printf("[%s-%d-%s]: name or val is null\n", __FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
    if ((da = dict_attrbyname(name))) {
        DEBUG("[%s-%d-%s]: add name=%s val=%s\n", __FILE__, __LINE__, __FUNCTION__, name, val);
        pairadd(vps, pairmake(name, val, T_OP_SET));
       
    } else {
        fr_strerror_printf("[%s-%d-%s]: name=%s da not found\n", __FILE__, __LINE__, __FUNCTION__, name);
        return -1;
    }
	return 0;
}

static int get_common_attr(VALUE_PAIR *vps, const char *name, char *out, int len)
{
    DICT_ATTR *da = NULL;
    VALUE_PAIR * attr = NULL;

    if (!vps || !name || !out) {
        fr_strerror_printf("[%s-%d-%s]: vps or name or out is null\n", __FILE__, __LINE__, __FUNCTION__);
        return 0;
    }
    if ((da = dict_attrbyname(name))) {
    	attr = pairfind(vps, da->attr);
        if (attr) {
            DEBUG("[%s-%d-%s]: get name=%s, val=%s\n", __FILE__, __LINE__, __FUNCTION__, name, attr->vp_strvalue);
            strncpy(out, attr->vp_strvalue, len);
            return 1;
        }
    }
    return 0;
}

nac_attr_t *nac_attr_get(int type)
{
    nac_attr_t * attr = NULL;
    
    for (attr = g_attr_array; attr->name != NULL; attr++) {
        if (attr->type == type) {
            return attr;
        }
    }
    return NULL;
}

int nac_set_filter_id(VALUE_PAIR **vps, char *filter_id)
{
    DICT_ATTR *da=NULL;
    char *pf = strtok(filter_id, ",");
    while (pf != NULL) {
        set_common_attr(vps, "Filter-Id", pf);
        pf = strtok(NULL, ",");
    }
    return 0;
}

int set_ms_filter_id(VALUE_PAIR **vps, char *filter_id)
{
    return set_common_attr(vps, "Filter-Id", filter_id);
}

int nac_get_common_attr(VALUE_PAIR *vps, const char *name, char *out, int len) 
{
    return get_common_attr(vps, name, out, len);
}

int nac_set_common_attr(VALUE_PAIR **vps, const char *name, const char *val)
{
    return set_common_attr(vps, name, val);
}

/**
 * @brief copy huawei attrbutes in src_vps to dst_vps
 * @param
 */
int nac_copy_common_attr(VALUE_PAIR *src_vps, VALUE_PAIR **dst_vps)
{
    nac_attr_t * attr = NULL;
    char val[64] = {0};

    if (!src_vps || !dst_vps) {
        fr_strerror_printf("[%s-%d-%s]: src_vps or dst_vps is null\n", __FILE__, __LINE__, __FUNCTION__);
        return -1;
    }
    DEBUG("[%s-%d-%s]: copy huawei attr\n", __FILE__, __LINE__, __FUNCTION__);
    for (attr = g_attr_array; attr->name != NULL; attr++) {
        memset(val, 0, sizeof(val));
        if (get_common_attr(src_vps, attr->name, val, sizeof(val)) == 1) {
            attr->attr_handler(dst_vps, attr->name, val);
        }
    }
    return 0;
}
