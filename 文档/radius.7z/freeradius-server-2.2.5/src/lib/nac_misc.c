#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <uuid/uuid.h>
#include <freeradius-devel/libradius.h>


#define NAC_SERVER_ADDR "/tmp/nac_server.sock"

#define NAC_SNPRINTF(buf, format, ...) \
do { \
	offset = strlen(buf); \
	snprintf(buf+offset, sizeof(buf)-offset, format, ## __VA_ARGS__); \
} while(0)


static int connect_server(const char *sk_name)                                                                
{
    int sockfd;
    struct sockaddr_un addr;

    sockfd = socket(AF_UNIX, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
		fr_strerror_printf("connect_server: socket error: %s", strerror(errno));
        return -1; 
    }   

    memset(&addr, 0, sizeof(struct sockaddr_un));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, sk_name, sizeof(addr.sun_path) - 1); 

    if (connect(sockfd, (struct sockaddr *) &addr, sizeof(struct sockaddr_un)) == -1) { 
		fr_strerror_printf("connect_server: connect error: %s", strerror(errno));
        close(sockfd);
        return -1; 
    }   
    return sockfd;
}


/**
 * @brief send log to skylar
 * @param type
 	0: 接入点未添加
 	1: 接入点秘钥错误
 */
int nac_log(int type, char *nas_ip)
{
	int fd = -1;
	int n = 0;
	char buf[1024] = "";
	int offset = 0;
	int log_type = 40;

	if ((nas_ip == NULL) ||(strlen(nas_ip) == 0)) {
		return -1;
	}
	NAC_SNPRINTF(buf, "s_msg_type=naclog");
	NAC_SNPRINTF(buf, "&s_module=auth_log");
	NAC_SNPRINTF(buf, "&log_type=%d", log_type);
	NAC_SNPRINTF(buf, "&type=%d", type);
	NAC_SNPRINTF(buf, "&nas_ip=%s", nas_ip); //交换机ip地址

	fprintf(stderr, "send_log: buf=%s\n", buf);
	fd = connect_server(NAC_SERVER_ADDR);
	if (fd < 0) {
		fr_strerror_printf("send_log: fd error...");
		return -1;
	}
	n = write(fd, buf, strlen(buf));
	if (n != strlen(buf)) {
		fr_strerror_printf("send_log: write %d bytes only", n);
	}
	close(fd);
	return n;
}
